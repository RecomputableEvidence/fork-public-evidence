# FPCF-002 — Public prospective evidence preservation v0.1

This is a **preservation and external-observation release**, not an admission of forecast accuracy, method efficacy, historical Stage-1 chronology, independent model identities, data completeness, compliance, or institutional authority.

## Exact originals

The `originals/` folder contains the original submitted Arm A, Arm B, and Arm C ZIP bytes, the prior unadmitted 25-case catalogue, the separately time-witnessed MKT-01 candidate packet, original experiment protocol/dispatch, original A/B intake reconciliation, and both the erroneous chronology report and its explicit correction. Nothing inside those source originals has been rewritten for publication. SHA-256 and byte lengths are in `MANIFEST.json`.

**Arm A** was given a neutral forecasting task. **Arm B** received the same task plus candidate Lens methodology. **Arm C** was the original analyst's fresh but *previously exposed* method-equipped run. Each independently selected six forecasts. The original 25-case catalogue and MKT-01 are historical predecessors, not participants or extra independent trials. Shared model lineage, self-selection and non-identical event sets limit comparative inference.

`FORECASTS_INDEX_ARCHIVAL.json` is a convenience projection of 18 submitted records; authoritative question, YES/NO/UNRESOLVED rules, probabilities, sources, and recorded reasoning remain the exact files inside each original ZIP. Index projection is not a new forecast or a change to one. Public resolution must use the original records.

## Chronology and admission constraints

A and B returned archives were present in a ChatGPT conversation by its recorded upload time `2026-10-27T00:06:37.426Z`, a platform metadata observation, not an RFC3161 certification or a witness to internal ordering. The user clarified that app timestamps around 16:47 PDT (A) and 17:05 PDT (B) were completion times, not dispatch timestamps. The older report treating them as assignment times is withdrawn **only on that inference**, but preserved verbatim with the correction. Participant-declared Stage-1 timestamps are exactly 1800s apart: causal explanation unresolved. Distinct predecision and final records exist, with internal hashes, but independent predecision ordering is **not** established. Each participant forecast retains its `UNADMITTED_CANDIDATE` status. The previously public MKT-01 GitHub PR #199 is also an unadmitted candidate with a bounded public time witness.

The GitHub server-time for this release witnesses a fixed commitment to these published archive hashes by the publication event. It does not independently authenticate the model execution sequence or the truth of linked external sources. A Git object hash and SHA-256 manifest demonstrate only their respective fixed-byte/integrity properties.

## Independent verifier

Download this ZIP file and its publicly pinned GitHub commit. Use Python 3.11+ (stdlib only) and run `python verify_public_release.py FPCF_002_PUBLIC_PRESERVATION_BUNDLE_v0.1.zip` from the extracted public-release folder. The script verifies exact member SHA-256 digests and lengths against the included manifest and performs structural/duplicate/path checks. **Also** compare the whole bundle's SHA-256 against the value recorded in the GitHub commit README, which is outside the bundle. A modified bundle and a rewritten internal manifest can still be mutually consistent.

## Append-only outcome reveal protocol

Keep original archives, public index, original manifest, and original public witness commit unchanged. When each event becomes resolvable, create a separate dated `outcomes/<arm>-<case>-<date>.json` referencing the original SHA-256 and fixed commit, original YES/NO/UNRESOLVED rule, independently identified outcome sources and retrieval method/time, primary source content/URL/digest where legitimately available, determination (`YES`,`NO`,`UNRESOLVED`,`INVALID`), independent adjudicator and dissent when present, and the Brier/log score only for resolvable eligible entries. If a forecast contract proves ambiguous or its prior-art date is defective, preserve `INVALID` or `UNRESOLVED`, never silently tighten its meaning. Later forecasting revisions are separate successor claims, not edited originals.

Publish neutral and Lens-arm comparisons only with population sizes, matched events, observation deadlines, source differences, and explicit confounding analysis. Shared model family, methodological leakage, unequal evidence and differing event selection prevent attributing any observed advantage solely to Lens methods without further matched/randomized tests.

## Reviewer stance

- Prediction correctness remains **PENDING** until outcome windows close.
- Structural verification is **not** source truth or historical time attestation.
- Public preservation is **not** research admission or approval.
- Corrections always point to preserved predecessors and explain their precise effect.
- No forecast probabilities or texts in these source originals are retrospectively revised.
