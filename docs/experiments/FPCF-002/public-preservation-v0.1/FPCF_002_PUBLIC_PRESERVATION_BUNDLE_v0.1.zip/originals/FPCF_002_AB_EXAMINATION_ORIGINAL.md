# FPCF-002 — Arms A and B: independent intake, integrity audit and comparative examination v0.1

**Examined objects:** exact uploaded Participant A and Participant B ZIP files; separately retained original dispatch archives; Arm C predecessor candidate ZIP for contextual comparison only.  
**Upload service observation:** `2026-10-27T00:06:37.426Z` for each return, as surfaced by the conversation-files listing.  
**Examination status:** `PACKAGE_INTEGRITY_CHECKED / CONTEMPORANEOUS_SUBMISSION_OBSERVED / STAGE1_CHRONOLOGY_NOT_EXTERNALLY_WITNESSED / METHOD_EFFECT_UNESTABLISHED / FUTURE_OUTCOMES_NOT_DUE`.  
**Publication/admission status:** no GitHub writes, no public or RFC 3161 timestamp issued for either return, no promotion into project standing.  
**Scope:** read-only structural and comparative examination; not a verification of publisher's original source bytes, independent chronology inside either return, forecasting accuracy, internal model cognition, or causal Lens advantage.

## 1. Receipt and integrity

| Field | Arm A — neutral | Arm B — methods |
|---|---|---|
| Submitted SHA-256 (entire ZIP) | `d970edc0821ca88a5950c1af5083160e546513917825412d5adff85ef952ac18` | `6641f5bebc5736c351a96da7106a72bb8e4d36d6074418880664b536b58ac34e` |
| Size (bytes) | 74624 | 70619 |
| Independent stdlib audit | **93/93 PASS** | **108/108 PASS** |
| Manifest entries | 33 | 30 |
| Forecasts / source / predecision / final | 6 / 6 / 6 / 6 | 6 / 6 / 6 / 6 |
| Dispatch reproduction | Exact original input members + nested A dispatch ZIP | Exact original input members |
| Declared start UTC | `2026-10-26T23:23:27Z` | `2026-10-26T23:51:26Z` |
| Declared Stage 1 local timestamp | `2026-10-26T23:33:33Z` | `2026-10-27T00:03:33Z` |
| Independent Stage 1 witness | **NONE** | **NONE** |
| Later platform receipt of whole submitted ZIP | `2026-10-27T00:06:37.426Z` | `2026-10-27T00:06:37.426Z` |
| External *public* anchor | **NONE** | **NONE** |
| Program admission | **WITHHELD** | **WITHHELD** |

The platform receipt is evidence that an archive with these bytes was present by the recorded upload time in this chat. It does **not** independently establish the earlier order of stages within the archive. The fixed archive SHA-256 is an external-to-submission comparison root **only where the observer independently retains or witnesses this examination/receipt**; it is not automatically a public timestamp or immutable transparency record.

### Corrective examiner finding

First attempt: 91/92 checks for A, 108/108 for B. The A failure was produced by *our* intake script incorrectly counting its checksum sidecar as extra dispatch content. The original finding and repair are preserved in `FPCF_002_AUDIT_ATTEMPT001_DEFECT.md`. Revised script: A 93/93 and B 108/108, including explicit digest verification for A's dispatch sidecar. No originals were altered. This is an examiner false positive, not a defect silently attributed to A.

### Coordinated re-sealing pressure

A scratch-only adversarial test altered the first predecision record and regenerated the local manifest. In **both** archives, the rewritten scratch manifest checked successfully against the rewritten scratch content. Nevertheless, the independently held SHA-256 of the originally received ZIP detects a different archive. This demonstrates why a valid internal manifest cannot authenticate historical originality. `FPCF_002_NEGATIVE_RESEAL_PROBES_20261026.json` records the two actual tests; this does not establish an attack-proof chain of custody.

## 2. Independent forecast populations

All probability numbers below are exactly the participant-reported probabilities, not adjusted assessments.

### Arm A — no Lens-method supplement

| ID | Binary forecast's YES outcome | P(YES) | Expected event/observation |
|---|---|---:|---|
| A-001 | Andrea Kimi Antonelli wins Mexico City F1 main race | 0.44 | 2026-11-01 |
| A-002 | Troy Jackson wins Maine U.S. Senate election | 0.50 | 2026-11-03; official final count later |
| A-003 | Max Verstappen is in top three at São Paulo F1 race | 0.52 | 2026-11-08 |
| A-004 | NHC first names Atlantic cyclone during 2026-10-30–11-30 window | 0.27 | 2026-11-30 |
| A-005 | Initial November U.S. CPI release reports unadjusted all-items 12-month change >=4.0% | 0.57 | 2026-12-10 |
| A-006 | Bank of England December MPC Bank Rate is >=4.00% immediately afterward | 0.43 | 2026-12-17 |

### Arm B — candidate Lens-method supplement

| ID | Binary forecast's YES outcome | P(YES) | Expected event/observation |
|---|---|---:|---|
| B-001 | Apple fiscal Q4 2026 consolidated revenue >=$115bn in initial release | 0.69 | 2026-11-02 |
| B-002 | Troy Jackson wins Maine U.S. Senate election | 0.61 | 2026-11-03; official final count later |
| B-003 | Kimi Antonelli places top three at São Paulo F1 main race | 0.76 | 2026-11-08 |
| B-004 | November U.S. U-3 unemployment rate initially reported >=4.3% | 0.44 | 2026-12-04 |
| B-005 | December 9 FOMC *raises* its target range relative to immediately preceding setting | 0.48 | 2026-12-09 |
| B-006 | *Avengers: Doomsday* domestic Dec 18–20 opening gross >=$250m | 0.57 | 2026-12-20 |

The full final records govern exact YES, NO, invalid/unresolved rules and deadlines; these tables are not substitute commitment artifacts.

## 3. Method-content findings

- **A** provides substantial source and competing-scenario reasoning without the method supplement. Its 6 predecision records use independent verbal uncertainty assessments, observed-source limitations, and explicit separation of official result versus prediction. The neutral dispatch and predecision records pass this audit's limited check against explicit Lens-method names. That does **not** establish the model's complete prior non-exposure to methods.
- **B** explicitly documents Lens Removal, Reliance, Lens Shift, Consequence Weaving and neutral integration, in that order, in **all six** predecision records. The content connects method headings with candidate reframing, source dependence, alternative hypothesis, and hypothetical consequence. The method packet itself warns that no causal effect or calibrated probability can be inferred merely by applying the method.
- **B's claimed candidate reforms**, as documented by B, include moving Apple from a vague quarter-strength claim to a first-release revenue threshold; Maine from first-choice poll interpretation to official final/RCV; São Paulo from possible race-winner to top-three classification; jobs from vague labor strength to initial U-3; FOMC from rates-higher-at-year-end to a single meeting decision; and film release from a relatively easy scheduled-release claim to a high opening gross threshold. These are **participant-reported within-case construction deltas**, not independently witnessed before/after controlled comparisons.
- **Neither arm** externally witnessed the predecision files before final probabilities were produced. Internal digests establish byte-consistency relative to the returned ledger, not the historically true decision sequence or exhaustiveness of model deliberation.
- **B chronology precision defect:** the final forecast files and outcome catalogue reuse `2026-10-27T00:03:33Z` as their “created”/recorded time, the same value as the Stage 1 local ledger. The stated *ordering* can be checked through the package's internal relationships, but distinct elapsed Stage 2 clock time is not demonstrated. This is a reporting weakness, not proof that sequencing was dishonest.
- **A preserves a defect transparently:** its CASE-005 predecision arithmetic wording was corrected by a separately hashed post-Stage-1 addendum, with the original preserved. This is appropriate additive correction behavior, although the original Stage 1 did not have an independent witness.

## 4. One genuinely comparable object: Maine Senate

Both participants chose the **same binary outcome**: Troy Jackson wins the official Maine Senate result on November 3. A estimates **0.50** and B estimates **0.61**; probability delta B−A = **+0.11**.

- A chiefly anchored to the more recent October 22 Fox/Beacon-Shaw **49–49** likely-voter poll and represented the race as a toss-up.
- B gave primary weight to October 6 Marist **51–47** registered-voter and October 9 GMU/Washington Post **50–46** likely-voter polls, while acknowledging uncertainty and incumbency.
- Independent public checks confirm those earlier polls existed, but both polls predate the Fox tie emphasized by A. B's source set is *not* an unambiguously superior or chronologically fresher evidence basis. Thus the 11-point difference is confounded by source selection, weighting, sampling frames, analyst judgment and possible response differences, not isolated Lens effects.
- A has a December 23 resolution deadline; B has January 10, 2027. They are not identical *adjudication contracts* even when they concern the same event. Before scoring, the analysis must define treatment if the official outcome is delayed into this gap.

A and B also both forecast São Paulo F1 performance, but they choose **different drivers** and different propositions; they must not be treated as matched forecasts.

## 5. Source checks, limited independent observation

The examiner independently checked the following primary-schedule/source context while outcomes remained future:

- Apple investor relations schedules FY2026 Q4 call on **November 2**: https://investor.apple.com/investor-relations/ .
- Formula One's calendar places Mexico on **October 30–November 1** and São Paulo on **November 6–8**: https://www.formula1.com/en/racing/2026 .
- BLS schedules November Employment Situation for **December 4** and November CPI for **December 10**: https://www.bls.gov/schedule/2026/ .
- Disney lists *Avengers: Doomsday* U.S. release on **December 18**: https://movies.disney.com/avengers-doomsday .
- George Mason reported a **50–46** Maine Senate poll October 9: https://content.gmu.edu/news/2026-10/washington-post-schar-school-poll-finds-tight-senate-contest-maine . Marist recorded **51–47** October 6: https://maristpoll.marist.edu/polls/midterm-elections-in-maine-october-2026/ .

These spot checks verify selected public claims, not all source citations, issuer byte integrity, cut-off historical web states, or later realized outcomes.

## 6. Four independent questions, four different current answers

| Proposition | Disposition as of this examination |
|---|---|
| Were the submitted record bytes internally coherent and tied to dispatch inputs? | **YES — bounded PASS of independent checks** |
| Were the final forecast ZIPs received by the chat platform before the scheduled event outcomes? | **YES — platform-scoped upload receipt observed** |
| Can a third party independently establish Stage 1 existed before Stage 2 in either participant? | **NO — not from the available evidence** |
| Did applying Lens methods improve prediction accuracy or decision quality? | **UNDETERMINED — no outcomes or controlled counterfactual** |

Arm C from the previous workflow is explicitly non-blind and has a separately disclosed local-only method record. Its six candidates may be retained for a broader exploratory cohort but should **not** be pooled as if independent random samples of one treatment effect. The historical 25-forecast predecessor and MKT-01 public candidate commitment remain separate populations.

## 7. Required controls before inference or public presentation

1. Preserve the uploaded original A and B ZIP bytes, hashes, observed upload metadata and all checker receipts without rewriting participants' contents. Use a separately named successor for any repair.
2. For prospective **final-forecast** standing, assess whether the platform-observed submission can serve as the programme's declared bounded Stage 2 custody witness; if public independent inspection is required, secure an independently published commitment **prospectively**, without claiming it retrospectively proves Stage 1.
3. Develop a blinded pre-outcome evaluation of operationalized outcome definitions, evidence diversity, counterfactual treatment, source recency, clarity of unresolved rules, and forecast calibration method. Hide treatment labels from evaluators wherever possible; distinguish mechanical scoring from interpretive judgments.
4. Predeclare outcome resolution and missingness handling before the earliest event, and decide whether the differing Maine final-count deadlines create incompatible units. Keep all original individual deadlines unchanged.
5. Track all 12 candidate forecasts through their predeclared deadlines. When scorable, calculate Brier scores, calibration bins where counts justify them, resolution coverage and domain-dependent sensitivity. A six-event arm is substantially underpowered for a robust conclusion; self-selection adds confounding.
6. To test **method effect** rather than arm differences, add a later genuinely controlled cohort with the **same frozen event set and source snapshot** assigned blindly to the neutral and Lens conditions, comparable compute/time/browse budgets, and replicated independent participants. Preserve original self-selected cohort as exploratory data, not as a failed experiment.
7. Never use a successful public prediction as a proxy for reliable method attribution; never use a passing hash check as validation of decision truth, institutional authority, or completeness.

## 8. Examiner conclusion

**Disposition: BOTH RETURNS ACCEPTED AS BOUNDED, INTERNALLY VERIFIED RESEARCH SUBMISSIONS; FULL METHOD-ATTRIBUTION ADMISSION WITHHELD.**

Their differences already identify researchable hypotheses concerning source selection, handling of uncertainty, resolution design and treatment-induced elaboration. Their future accuracy remains unknown. The user's central demand — evidence of how a decision was formed rather than retrofitted explanation — remains only partially satisfied because both Stage 1 checkpoints were local-only. Treat that gap as an actual experimental limitation, not something a later narrative or timestamp can repair.
