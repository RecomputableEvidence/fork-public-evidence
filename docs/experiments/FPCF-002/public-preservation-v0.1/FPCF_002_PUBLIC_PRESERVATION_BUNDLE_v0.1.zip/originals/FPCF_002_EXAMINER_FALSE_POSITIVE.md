# FPCF-002 independent audit — Attempt 001 preserved checker defect

Initial local independent ingest check: A 91/92, B 108/108. Failed A assertion `dispatch_zip_entries_exact` treated a legitimate extra byte-integrity sidecar (`input_originals/ORIGINAL_DISPATCH_ARCHIVE.sha256`) as forbidden. This was a **verifier false positive**, not a participant file integrity defect.

Repair: explicitly exclude the sidecar when counting original dispatch entries, then verify its digest value against the separately retained original dispatch archive. Re-run the entire test population; original participant archives remain byte-unchanged.

No forecast content was revised by this correction.
