# Fork PR #91 bounded exterior recomputation

Reviewer: ChatGPT/Codex (OpenAI)  
Independence class: `PRIOR_EXPOSURE_DISCLOSED`  
Disposition: `REPRODUCED_WITH_CORRECTION_REQUIRED`

## Exact target

- Repository: `RecomputableEvidence/fork-public-evidence`
- Pull request: `#91`
- Acquired detached commit:
  `e848ea0825bafc1aa3754d89e719d71b5a9f3982`
- Acquired tree:
  `0b5f11eb6c1cd8c90b4cacce2a747045da917741`

## Core reproduction

- Checker: `LONGITUDINAL_STATE_REPRODUCED`
- Checker findings: `0`
- Independently derived state-vector SHA-256:
  `9ce7d9b07df71481eb3020152084dce6e58b8172d7cea9f11d8bb6ec11f7a496`
- Focused suite: `16 passed`, exit `0`
- Clean-checkout full suite: `726 passed`, `3 skipped`, exit `0`
- Registered adversarial cases: `10/10` rejected with their required
  finding codes

Changed dimensions:

- `artifact_state`
- `review_state`
- `temporal_closure`
- `unresolved_state`
- `verification_state`

Preserved dimensions:

- `admission_state`
- `authority_state`
- `execution_state`

## Corrections retained

1. PR #91's public description claims `776` full-suite passes. The exact-target
   locked run independently collected `726` tests and returned `726 passed,
   3 skipped`.
2. The envelope's in-checkout `.venv-fork-review` location causes the optional
   full suite's line-ending checker to inspect reviewer-created
   `bin/Activate.ps1` and fail on its CRLF bytes. Moving only that environment
   outside the checkout produces the clean full-suite pass above.
3. The initial PR metadata read exposed author-claimed verification values
   before local execution. The envelope's comparison section remained withheld
   until raw observations were recorded, but the review is not represented as
   blind.
4. The concurrency challenge emitted both the required
   `CONCURRENT_SUCCESSOR_UNRECONCILED` and the additional
   `EVENT_REGISTRY_DUPLICATE`; both are preserved.

## Contents

- `EXTERIOR_RECOMPUTATION_RECEIPT_PR91_CHATGPT_20260724_v0_1.json` — completed,
  canonical-JSON integrity-bound receipt
- `raw/` — stdout, stderr, command metadata, exit codes, byte sizes, and
  SHA-256 digests
- `run_adversarial_challenges.py` — exterior challenge harness
- `derive_observations.py` — independent measurement derivation
- `build_receipt.py` — deterministic receipt completion and binding
- `capture_pr91_command.sh` — command-output capture wrapper
- Original PR #91 envelope and uncompleted template

The receipt's `integrity.receipt_payload_sha256` is computed over canonical JSON
after deleting only that field and retaining the empty `integrity` object.

No provider calls, Pair-001 calls or repetitions, admission, merge
authorization, publication, authority transfer, or execution permission
occurred.
