#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any


RECEIPT_NAME = "EXTERIOR_RECOMPUTATION_RECEIPT_PR91_CHATGPT_20260724_v0_1.json"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def canonical_json(value: Any) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("package_root", type=Path)
    args = parser.parse_args()
    root = args.package_root.resolve()
    errors: list[str] = []

    receipt = json.loads((root / RECEIPT_NAME).read_text(encoding="utf-8"))
    recorded_integrity = receipt["integrity"]["receipt_payload_sha256"]
    del receipt["integrity"]["receipt_payload_sha256"]
    derived_integrity = hashlib.sha256(canonical_json(receipt)).hexdigest()
    if recorded_integrity != derived_integrity:
        errors.append("RECEIPT_INTEGRITY_MISMATCH")

    for artifact in receipt["raw_output_artifacts"]:
        path = root / artifact["path"]
        if not path.is_file():
            errors.append(f"RAW_ARTIFACT_MISSING:{artifact['path']}")
            continue
        if path.stat().st_size != artifact["size_bytes"]:
            errors.append(f"RAW_ARTIFACT_SIZE_MISMATCH:{artifact['path']}")
        if sha256_file(path) != artifact["sha256"]:
            errors.append(f"RAW_ARTIFACT_DIGEST_MISMATCH:{artifact['path']}")

    manifest_path = root / "PACKAGE_MANIFEST.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    listed = {entry["path"] for entry in manifest["entries"]}
    actual = {
        path.relative_to(root).as_posix()
        for path in root.rglob("*")
        if path.is_file() and path != manifest_path
    }
    if listed != actual:
        errors.append("PACKAGE_FILE_SET_MISMATCH")
    for entry in manifest["entries"]:
        path = root / entry["path"]
        if not path.is_file():
            errors.append(f"PACKAGE_ENTRY_MISSING:{entry['path']}")
            continue
        if path.stat().st_size != entry["size_bytes"]:
            errors.append(f"PACKAGE_ENTRY_SIZE_MISMATCH:{entry['path']}")
        if sha256_file(path) != entry["sha256"]:
            errors.append(f"PACKAGE_ENTRY_DIGEST_MISMATCH:{entry['path']}")

    if receipt["disposition"] != "REPRODUCED_WITH_CORRECTION_REQUIRED":
        errors.append("DISPOSITION_MISMATCH")
    if receipt["review_target"]["acquired_head_sha"] != (
        "e848ea0825bafc1aa3754d89e719d71b5a9f3982"
    ):
        errors.append("HEAD_SHA_MISMATCH")
    if receipt["review_target"]["acquired_tree_sha"] != (
        "0b5f11eb6c1cd8c90b4cacce2a747045da917741"
    ):
        errors.append("TREE_SHA_MISMATCH")

    result = {
        "status": "DELIVERABLE_VALID" if not errors else "DELIVERABLE_INVALID",
        "error_count": len(errors),
        "errors": errors,
        "receipt_payload_sha256": recorded_integrity,
        "package_manifest_sha256": sha256_file(manifest_path),
        "package_entry_count": manifest["entry_count"],
    }
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if not errors else 1


if __name__ == "__main__":
    raise SystemExit(main())
