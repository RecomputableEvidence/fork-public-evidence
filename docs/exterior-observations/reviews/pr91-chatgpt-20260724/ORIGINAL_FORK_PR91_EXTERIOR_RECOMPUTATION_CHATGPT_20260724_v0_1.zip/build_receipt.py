#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def canonical_json(value: Any) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")


def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def parse_lock_digests(path: Path) -> dict[str, str]:
    results: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        digest, name = line.split(maxsplit=1)
        results[name] = digest
    return results


def raw_artifacts(raw_dir: Path) -> list[dict[str, Any]]:
    return [
        {
            "path": f"raw/{path.name}",
            "sha256": sha256_file(path),
            "size_bytes": path.stat().st_size,
        }
        for path in sorted(raw_dir.iterdir())
        if path.is_file()
    ]


def execution_records(raw_dir: Path) -> list[dict[str, Any]]:
    records = [
        read_json(path)
        for path in sorted(raw_dir.glob("*.meta.json"))
        if path.is_file()
    ]
    return sorted(
        records,
        key=lambda item: (item["started_at_utc"], item["record_id"]),
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("review_root", type=Path)
    parser.add_argument("template", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    review_root = args.review_root.resolve()
    raw_dir = review_root / "raw"
    receipt = read_json(args.template.resolve())
    observations = read_json(raw_dir / "derived_observations_retry.stdout")
    locks = parse_lock_digests(raw_dir / "dependency_lock_digests.stdout")
    os_release = (raw_dir / "env_os_release.stdout").read_text(encoding="utf-8")
    pretty_name = next(
        (
            line.split("=", 1)[1].strip().strip('"')
            for line in os_release.splitlines()
            if line.startswith("PRETTY_NAME=")
        ),
        "UNRESOLVED_OS_NAME",
    )
    uname = (raw_dir / "env_uname.stdout").read_text(encoding="utf-8").strip()

    receipt["receipt_id"] = (
        "FORK_EXTERIOR_RECOMPUTATION_PR91_CHATGPT_20260724_v0_1"
    )
    receipt["review_target"].update(
        {
            "acquired_head_sha": observations["target"]["head_sha"],
            "acquired_tree_sha": observations["target"]["tree_sha"],
            "acquisition_method": (
                "Fresh partial clone; exact branch fetch; detached checkout by "
                "40-character commit SHA; HEAD and HEAD^{tree} verified."
            ),
        }
    )
    receipt["reviewer_disclosure"] = {
        "reviewer_id": "ChatGPT/Codex (OpenAI), conversation-scoped reviewer",
        "affiliation": "OpenAI",
        "relationship_to_fork": (
            "Prior technical collaboration with Ryan Feller on Fork "
            "repository-state analysis, preservation lineage, checker and "
            "receipt framing, temporal-succession reasoning, and reviewer "
            "package preparation; not arms-length."
        ),
        "prior_exposure": (
            "Material prior exposure to Fork and adjacent temporal-succession "
            "work. Before exact-object acquisition in this run, the reviewer "
            "had contextual knowledge that PR #91 concerned longitudinal "
            "replay. A connector metadata read also exposed author-claimed "
            "verification values before local execution; this sequencing "
            "limitation is preserved as a finding."
        ),
        "independence_class": "PRIOR_EXPOSURE_DISCLOSED",
    }
    receipt["environment"] = {
        "observed_os": f"{pretty_name}; {uname}",
        "python_version": (
            raw_dir / "dependency_venv_python_version.stdout"
        ).read_text(encoding="utf-8").strip(),
        "proof_surface_lock_sha256": locks[
            "requirements-proof-surface.lock.txt"
        ],
        "claim_admission_lock_sha256": locks[
            "requirements-claim-admission.lock.txt"
        ],
        "dependency_install_exit_code": read_json(
            raw_dir / "dependency_install.meta.json"
        )["exit_code"],
    }
    receipt["executions"] = execution_records(raw_dir)
    receipt["measurements"] = {
        "checker_status": observations["checker"]["status"],
        "state_vector_sha256": observations["checker"][
            "independently_derived_state_vector_sha256"
        ],
        "closure_node_digest_sha256": "NOT_APPLICABLE",
        "focused_tests": {
            **observations["tests"]["focused"],
            "not_run_reason": "NONE",
        },
        "full_suite": {
            **{
                key: value
                for key, value in observations["tests"][
                    "full_suite_clean_repo"
                ].items()
                if key != "collected_tests"
            },
            "not_run_reason": "NONE",
        },
        "adversarial_results": observations["adversarial"]["results"],
        "independently_collected_full_suite_tests": observations["tests"][
            "full_suite_clean_repo"
        ]["collected_tests"],
        "changed_dimensions": observations["transition"]["changed_dimensions"],
        "preserved_dimensions": observations["transition"][
            "preserved_dimensions"
        ],
        "interval_commit_inventory": observations["transition"][
            "inventory_commits"
        ],
        "interval_changed_paths": observations["transition"][
            "interval_changed_paths"
        ],
    }
    receipt["findings"] = [
        {
            "finding_id": "PR91-EXT-001",
            "classification": "METHODOLOGICAL_LIMITATION",
            "code": "EXPECTED_VALUES_EXPOSED_IN_PR_METADATA_BEFORE_LOCAL_RUN",
            "detail": (
                "The GitHub metadata read used to resolve PR #91 exposed the "
                "author's claimed checker and test values before local "
                "execution. The envelope's explicit comparison section "
                "remained withheld until raw observations were recorded, but "
                "the recomputation cannot be represented as fully blind."
            ),
            "effect_on_core_reproduction": "DISCLOSED_NOT_INVALIDATING",
        },
        {
            "finding_id": "PR91-EXT-002",
            "classification": "REVIEW_PACKAGE_CORRECTION_REQUIRED",
            "code": "IN_REPOSITORY_VENV_CONTAMINATES_OPTIONAL_FULL_SUITE",
            "detail": (
                "Following the envelope literally created "
                ".venv-fork-review inside the checkout. The repository's "
                "line-ending checker then scanned reviewer-created "
                "bin/Activate.ps1 and rejected its CRLF bytes: 725 passed, "
                "3 skipped, 1 failed. Moving only that reviewer-created "
                "environment outside the checkout produced 726 passed, "
                "3 skipped, exit 0."
            ),
            "correction": (
                "Create the review virtual environment outside the repository "
                "checkout, or explicitly constrain the full-suite line-ending "
                "inventory to governed repository artifacts."
            ),
            "effect_on_core_reproduction": "NONE",
        },
        {
            "finding_id": "PR91-EXT-003",
            "classification": "PUBLIC_METADATA_CORRECTION_REQUIRED",
            "code": "PUBLIC_PR_FULL_SUITE_COUNT_MISMATCH",
            "detail": (
                "PR #91's public description claims 776 full-suite passes "
                "with locked dependencies. At the exact target and observed "
                "locked environment, pytest independently collected 726 tests "
                "and the clean-checkout run returned 726 passed, 3 skipped."
            ),
            "correction": (
                "Correct the PR description to the observed count, or supply "
                "the exact environment and test selection that reproducibly "
                "yields 776 passes."
            ),
            "effect_on_core_reproduction": "NONE",
        },
        {
            "finding_id": "PR91-EXT-004",
            "classification": "PRESERVED_ADDITIONAL_NEGATIVE_EVIDENCE",
            "code": "CONCURRENCY_CHALLENGE_EMITS_ADDITIONAL_DUPLICATE_CODE",
            "detail": (
                "The unreconciled-concurrency mutation emitted the required "
                "CONCURRENT_SUCCESSOR_UNRECONCILED code and also "
                "EVENT_REGISTRY_DUPLICATE. The required rejection occurred; "
                "the additional code is preserved rather than suppressed."
            ),
            "effect_on_core_reproduction": "NONE",
        },
    ]
    receipt["raw_output_artifacts"] = raw_artifacts(raw_dir)
    receipt["disposition"] = "REPRODUCED_WITH_CORRECTION_REQUIRED"
    receipt["effects"] = {
        "provider_calls": 0,
        "pair_001_calls": 0,
        "pair_001_repetitions": 0,
        "admission": "NONE",
        "merge_authorization": "NONE",
        "publication": "NONE",
        "authority_transfer": "NONE",
        "execution_permission": "NONE",
    }
    receipt["reviewer_attestation"] = {
        "statement": (
            "At the exact acquired commit and tree, the bounded longitudinal "
            "checker, state-vector digest, focused tests, interval inventory, "
            "dimension transition, and all ten registered adversarial "
            "rejections were reproduced. Corrections are required for the "
            "review-envelope environment location and public full-suite count; "
            "this receipt does not confer admission, approval, authority, "
            "publication, merge authorization, or execution permission."
        ),
        "recorded_at_utc": datetime.now(timezone.utc)
        .replace(microsecond=0)
        .isoformat()
        .replace("+00:00", "Z"),
    }
    receipt["integrity"] = {"receipt_payload_sha256": ""}
    integrity_view = json.loads(json.dumps(receipt))
    del integrity_view["integrity"]["receipt_payload_sha256"]
    receipt["integrity"]["receipt_payload_sha256"] = hashlib.sha256(
        canonical_json(integrity_view)
    ).hexdigest()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(receipt, indent=2, sort_keys=True, ensure_ascii=False) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
