#!/usr/bin/env bash
set -u

if [ "$#" -lt 4 ]; then
  echo "usage: $0 ID OUTPUT_DIR WORKDIR COMMAND [ARG ...]" >&2
  exit 64
fi

record_id=$1
output_dir=$2
command_workdir=$3
shift 3

mkdir -p "$output_dir"

stdout_path="$output_dir/${record_id}.stdout"
stderr_path="$output_dir/${record_id}.stderr"
meta_path="$output_dir/${record_id}.meta.json"

started_at_utc=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
command_display=$(printf '%q ' "$@")
command_display=${command_display% }

set +e
(
  cd "$command_workdir" || exit 125
  "$@"
) >"$stdout_path" 2>"$stderr_path"
exit_code=$?
set -e

finished_at_utc=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
stdout_sha256=$(sha256sum "$stdout_path" | cut -d' ' -f1)
stderr_sha256=$(sha256sum "$stderr_path" | cut -d' ' -f1)
stdout_size_bytes=$(wc -c <"$stdout_path")
stderr_size_bytes=$(wc -c <"$stderr_path")

jq -n \
  --arg record_id "$record_id" \
  --arg started_at_utc "$started_at_utc" \
  --arg finished_at_utc "$finished_at_utc" \
  --arg workdir "$command_workdir" \
  --arg command "$command_display" \
  --argjson exit_code "$exit_code" \
  --arg stdout_path "$(basename "$stdout_path")" \
  --arg stdout_sha256 "$stdout_sha256" \
  --argjson stdout_size_bytes "$stdout_size_bytes" \
  --arg stderr_path "$(basename "$stderr_path")" \
  --arg stderr_sha256 "$stderr_sha256" \
  --argjson stderr_size_bytes "$stderr_size_bytes" \
  '{
    record_id: $record_id,
    started_at_utc: $started_at_utc,
    finished_at_utc: $finished_at_utc,
    workdir: $workdir,
    command: $command,
    exit_code: $exit_code,
    stdout: {
      path: $stdout_path,
      sha256: $stdout_sha256,
      size_bytes: $stdout_size_bytes
    },
    stderr: {
      path: $stderr_path,
      sha256: $stderr_sha256,
      size_bytes: $stderr_size_bytes
    }
  }' >"$meta_path"

printf '%s\n' "$exit_code"
