#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path
from typing import Any


def canonical_json_sha256(value: Any) -> str:
    payload = json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def summary_counts(text: str) -> dict[str, int]:
    passed = re.search(r"(\d+) passed", text)
    failed = re.search(r"(\d+) failed", text)
    skipped = re.search(r"(\d+) skipped", text)
    return {
        "passed": int(passed.group(1)) if passed else 0,
        "failed": int(failed.group(1)) if failed else 0,
        "skipped": int(skipped.group(1)) if skipped else 0,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("review_root", type=Path)
    args = parser.parse_args()
    review_root = args.review_root.resolve()
    raw = review_root / "raw"

    recompute = read_json(raw / "recompute_json.stdout")
    projection = read_json(raw / "derive_projection.stdout")
    diff = read_json(raw / "recompute_diff.stdout")
    adversarial = read_json(raw / "adversarial_challenges.stdout")
    pr_metadata = read_json(raw / "pr_metadata_api.stdout")

    state_hash = canonical_json_sha256(projection["state_vector"])
    focused_text = (raw / "focused_tests.stdout").read_text(encoding="utf-8")
    full_initial_text = (raw / "full_suite.stdout").read_text(encoding="utf-8")
    full_clean_text = (raw / "full_suite_clean_repo.stdout").read_text(
        encoding="utf-8"
    )
    collect_text = (raw / "full_suite_collect_only.stdout").read_text(
        encoding="utf-8"
    )
    collected = re.search(r"(\d+) tests collected", collect_text)
    pr_claim = re.search(
        r"Full repository suite with locked dependencies: \*\*(\d+) passed\*\*",
        pr_metadata["body"],
    )

    observations = {
        "record_kind": "fork_pr91_exterior_derived_observations",
        "target": {
            "head_sha": (
                raw / "acquisition_head_sha.stdout"
            ).read_text(encoding="utf-8").strip(),
            "tree_sha": (
                raw / "acquisition_tree_sha.stdout"
            ).read_text(encoding="utf-8").strip(),
        },
        "checker": {
            "status": recompute["status"],
            "finding_count": recompute["finding_count"],
            "finding_codes": recompute["finding_codes"],
            "reported_state_vector_sha256": projection["state_vector_sha256"],
            "independently_derived_state_vector_sha256": state_hash,
            "state_hash_matches_checker": (
                state_hash == projection["state_vector_sha256"]
            ),
        },
        "transition": {
            "changed_dimensions": diff["changed_dimensions"],
            "preserved_dimensions": diff["preserved_dimensions"],
            "applied_event_ids": projection["applied_event_ids"],
            "inventory_commits": [
                line
                for line in (
                    raw / "inventory_rev_list.stdout"
                ).read_text(encoding="utf-8").splitlines()
                if line
            ],
            "interval_changed_paths": [
                line
                for line in (
                    raw / "inventory_diff_tree.stdout"
                ).read_text(encoding="utf-8").splitlines()
                if line
            ],
        },
        "tests": {
            "focused": {
                **summary_counts(focused_text),
                "exit_code": read_json(raw / "focused_tests.meta.json")["exit_code"],
            },
            "full_suite_initial_in_repo_venv": {
                **summary_counts(full_initial_text),
                "exit_code": read_json(raw / "full_suite.meta.json")["exit_code"],
                "failure_cause": (
                    "REVIEWER_CREATED_IN_REPO_VENV_CRLF_SCANNED_BY_LINE_ENDING_CHECKER"
                ),
            },
            "full_suite_clean_repo": {
                **summary_counts(full_clean_text),
                "exit_code": read_json(raw / "full_suite_clean_repo.meta.json")[
                    "exit_code"
                ],
                "collected_tests": int(collected.group(1)) if collected else None,
            },
        },
        "adversarial": {
            "case_count": adversarial["case_count"],
            "all_rejected_as_required": adversarial["all_rejected_as_required"],
            "results": adversarial["results"],
        },
        "public_pr_metadata_comparison": {
            "claimed_full_suite_passed": int(pr_claim.group(1)) if pr_claim else None,
            "observed_full_suite_passed": summary_counts(full_clean_text)["passed"],
            "counts_match": (
                pr_claim is not None
                and int(pr_claim.group(1)) == summary_counts(full_clean_text)["passed"]
            ),
        },
        "effects": recompute["effects"],
    }
    print(json.dumps(observations, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
