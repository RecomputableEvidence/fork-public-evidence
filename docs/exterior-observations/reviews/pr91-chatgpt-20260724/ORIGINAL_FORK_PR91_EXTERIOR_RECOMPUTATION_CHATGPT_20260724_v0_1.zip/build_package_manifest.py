#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("package_root", type=Path)
    args = parser.parse_args()
    root = args.package_root.resolve()
    manifest_path = root / "PACKAGE_MANIFEST.json"
    entries = []
    for path in sorted(root.rglob("*")):
        if not path.is_file() or path == manifest_path:
            continue
        entries.append(
            {
                "path": path.relative_to(root).as_posix(),
                "sha256": sha256_file(path),
                "size_bytes": path.stat().st_size,
            }
        )
    manifest = {
        "schema_version": "v0.1",
        "record_kind": "fork_pr91_exterior_recomputation_package_manifest",
        "package_id": "FORK_PR91_EXTERIOR_RECOMPUTATION_CHATGPT_20260724_v0_1",
        "entry_count": len(entries),
        "entries": entries,
        "self_exclusion": {
            "path": "PACKAGE_MANIFEST.json",
            "reason": "AVOIDS_CIRCULAR_FULL_FILE_DIGEST",
        },
    }
    manifest_path.write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
