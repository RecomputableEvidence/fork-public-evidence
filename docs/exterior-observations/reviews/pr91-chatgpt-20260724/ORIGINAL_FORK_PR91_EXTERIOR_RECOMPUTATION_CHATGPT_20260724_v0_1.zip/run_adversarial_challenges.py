#!/usr/bin/env python3
from __future__ import annotations

import argparse
import copy
import importlib.util
import json
import tempfile
from pathlib import Path
from typing import Any, Callable


def load_checker(repo_root: Path):
    checker_path = repo_root / "tools/check_longitudinal_recomputation_v0_2.py"
    spec = importlib.util.spec_from_file_location(
        "fork_longitudinal_recomputation_v0_2_exterior_review",
        checker_path,
    )
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load checker: {checker_path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def evaluate_mutation(
    checker: Any,
    repo_root: Path,
    mutate: Callable[[dict[str, Any], dict[str, Any]], None],
) -> dict[str, Any]:
    contract = checker.strict_load(repo_root / checker.CONTRACT)
    registry = checker.strict_load(repo_root / checker.REGISTRY)
    mutate(contract, registry)
    return checker.evaluate(
        repo_root,
        contract_override=contract,
        registry_override=registry,
        verify_committed=False,
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("repo_root", type=Path)
    args = parser.parse_args()
    repo_root = args.repo_root.resolve()
    checker = load_checker(repo_root)

    def remove_interval_event(_: dict[str, Any], registry: dict[str, Any]) -> None:
        registry["events"] = []

    def add_undeclared_dimension(
        _: dict[str, Any], registry: dict[str, Any]
    ) -> None:
        event = registry["events"][0]
        event["affected_dimensions"].append("truth_state")
        event["dimension_effects"]["truth_state"] = {
            "operation": "REPLACE",
            "after": {"standing": "TRUE"},
        }

    def promote_review(_: dict[str, Any], registry: dict[str, Any]) -> None:
        registry["events"][0]["dimension_effects"]["verification_state"]["after"][
            "standing"
        ] = "CURRENT_HEAD_INDEPENDENTLY_RECOMPUTED"

    def promote_admission(_: dict[str, Any], registry: dict[str, Any]) -> None:
        registry["events"][0]["admission_effect"] = "CONFER"

    def promote_execution(_: dict[str, Any], registry: dict[str, Any]) -> None:
        event = registry["events"][0]
        event["affected_dimensions"].append("execution_state")
        event["dimension_effects"]["execution_state"] = {
            "operation": "REPLACE",
            "after": {"standing": "EXECUTION_PERMITTED", "provider_calls": 1},
        }

    def add_concurrent_successor(
        _: dict[str, Any], registry: dict[str, Any]
    ) -> None:
        concurrent = copy.deepcopy(registry["events"][0])
        concurrent["ordinal"] = 2
        concurrent["event_id"] = "FLR-EXTERIOR-CONCURRENT"
        concurrent["predecessor_event_ids"] = []
        registry["events"].append(concurrent)

    def leave_expired_authority(
        _: dict[str, Any], registry: dict[str, Any]
    ) -> None:
        event = registry["events"][0]
        event["affected_dimensions"].append("authority_state")
        event["dimension_effects"]["authority_state"] = {
            "operation": "REPLACE",
            "after": {
                "standing": "ACTIVE",
                "valid_from_utc": "2026-07-22T21:05:49Z",
                "valid_until_utc": "2026-07-23T00:00:00Z",
                "revoked_by_event_id": None,
                "freshness": "EXPIRED_AT_REPLAY_CLOSURE",
            },
        }
        event["authority_effect"] = "CONFER"

    def backdate_event(_: dict[str, Any], registry: dict[str, Any]) -> None:
        registry["events"][0]["occurred_at_utc"] = "2026-07-22T20:00:00Z"

    def mutate_evidence_digest(
        _: dict[str, Any], registry: dict[str, Any]
    ) -> None:
        registry["events"][0]["evidence_refs"][0]["sha256"] = "0" * 64

    cases: list[tuple[str, str, Callable[[dict[str, Any], dict[str, Any]], None]]] = [
        ("FLR-ADV-001", "EVENT_COVERAGE_UNRESOLVED", remove_interval_event),
        ("FLR-ADV-002", "UNDECLARED_DIMENSION_CHANGE", add_undeclared_dimension),
        ("FLR-ADV-003", "CURRENT_HEAD_REVIEW_STALE", promote_review),
        ("FLR-ADV-004", "ADMISSION_EFFECT_MISMATCH", promote_admission),
        ("FLR-ADV-005", "EXECUTION_EFFECT_MISMATCH", promote_execution),
        (
            "FLR-ADV-006",
            "CONCURRENT_SUCCESSOR_UNRECONCILED",
            add_concurrent_successor,
        ),
        ("FLR-ADV-007", "AUTHORITY_EXPIRED_OR_REVOKED", leave_expired_authority),
        ("FLR-ADV-008", "EVENT_TIME_PRECEDES_PARENT", backdate_event),
        ("FLR-ADV-009", "EVIDENCE_DIGEST_MISMATCH", mutate_evidence_digest),
    ]

    results: list[dict[str, Any]] = []
    for case_id, required_code, mutation in cases:
        result = evaluate_mutation(checker, repo_root, mutation)
        finding_codes = sorted(result["finding_codes"])
        results.append(
            {
                "case_id": case_id,
                "required_code": required_code,
                "checker_status": result["status"],
                "finding_codes": finding_codes,
                "rejected_as_required": required_code in finding_codes,
            }
        )

    with tempfile.TemporaryDirectory(prefix="fork-pr91-cache-challenge-") as temp_dir:
        temp_root = Path(temp_dir)
        relative = Path("projection.json")
        (temp_root / relative).write_text('{"changed":true}\n', encoding="utf-8")
        findings: list[dict[str, str]] = []
        checker.compare_cache(
            temp_root,
            relative,
            {"changed": False},
            "PROJECTION_REDUCER_DIVERGENCE",
            findings,
        )
        finding_codes = sorted({item["code"] for item in findings})
        results.append(
            {
                "case_id": "FLR-ADV-010",
                "required_code": "PROJECTION_REDUCER_DIVERGENCE",
                "checker_status": (
                    "LONGITUDINAL_RECOMPUTATION_INVALID"
                    if findings
                    else "LONGITUDINAL_STATE_REPRODUCED"
                ),
                "finding_codes": finding_codes,
                "rejected_as_required": (
                    "PROJECTION_REDUCER_DIVERGENCE" in finding_codes
                ),
            }
        )

    payload = {
        "record_kind": "fork_pr91_exterior_adversarial_challenge_results",
        "target_head_sha": "e848ea0825bafc1aa3754d89e719d71b5a9f3982",
        "case_count": len(results),
        "all_rejected_as_required": all(
            item["rejected_as_required"] for item in results
        ),
        "results": results,
        "effects": {
            "provider_calls": 0,
            "pair_001_calls": 0,
            "pair_001_repetitions": 0,
            "admission": "NONE",
            "execution": "NONE",
        },
    }
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0 if payload["all_rejected_as_required"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
