#!/usr/bin/env python3
"""
Boundary-State Interoperability Checker v0.1.0
Prototype Reference Checker for Boundary-State Interoperability Profile v0.1.4.

Scope:
  Implements the frozen v0.1.4 profile for the seam:
  RUNTIME_ATTESTATION_LAYER -> EVIDENCE_BOUNDARY_LAYER

Non-claims:
  This checker is a prototype reference implementation. It does not establish legal
  sufficiency, operational sufficiency, compliance, safety, truth, or authority.
  It validates structural and semantic boundary conditions defined by the v0.1.4
  private research/design profile.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Set, Tuple

try:
    from jsonschema import Draft202012Validator
except Exception as exc:  # pragma: no cover
    Draft202012Validator = None
    JSONSCHEMA_IMPORT_ERROR = exc
else:
    JSONSCHEMA_IMPORT_ERROR = None

CHECKER_ID = "BOUNDARY_STATE_INTEROPERABILITY_CHECKER_v0_1_0"
PROFILE_REVISION = "v0.1.4"
SUPPORTED_PROFILE = "RUNTIME_ATTESTATION_TO_EVIDENCE_BOUNDARY_HANDOFF_PROFILE_v0_1_4"
SUPPORTED_TABLE_ID = "SEMANTIC_CLASS_TABLE_v0_1_4"

PROTECTED_TEXT_PATTERNS: List[Tuple[str, str]] = [
    (r"\bready\s+for\s+reliance\b", "RELIANCE_SEMANTIC_CLASS"),
    (r"\breliance\b", "RELIANCE_SEMANTIC_CLASS"),
    (r"\breliance[-\s]?ready\b", "RELIANCE_SEMANTIC_CLASS"),
    (r"\bsafe\s+to\s+rely\s+on\b", "RELIANCE_SEMANTIC_CLASS"),
    (r"\bproduction\s+ready\b", "RELIANCE_SEMANTIC_CLASS"),
    (r"\boperationally\s+acceptable\b", "RELIANCE_SEMANTIC_CLASS"),
    (r"\boperational\s+readiness\b", "RELIANCE_SEMANTIC_CLASS"),
    (r"\bapproved\b|\bapproval\b", "AUTHORITY_SEMANTIC_CLASS"),
    (r"\bauthori[sz]ed\b|\bauthority\b", "AUTHORITY_SEMANTIC_CLASS"),
    (r"\bcompliant\b|\bcompliance\b|\bcontrol\s+conformance\b|\bregulatory\s+conformance\b", "COMPLIANCE_SEMANTIC_CLASS"),
    (r"\bcorrect\b|\bcorrectness\b|\bvalidated\b", "CORRECTNESS_SEMANTIC_CLASS"),
    (r"\btruth\b|\btrue\b|\bfactual\s+accuracy\b", "TRUTH_SEMANTIC_CLASS"),
]

@dataclass
class Violation:
    violation_type: str
    details: str
    phase: str = "SEMANTIC"

@dataclass
class Signal:
    semantic_class: str
    source: str
    value: str
    claim_id: Optional[str] = None
    derived_from: Optional[List[str]] = None

@dataclass
class CheckResult:
    checker_id: str
    fixture_file: Optional[str]
    handoff_id: Optional[str]
    profile_revision: Optional[str]
    status: str
    outcome: str
    validation_phase: str
    violations: List[Dict[str, Any]]
    expected_status: Optional[str] = None
    expected_outcome: Optional[str] = None
    status_matches_expected: Optional[bool] = None
    outcome_matches_expected: Optional[bool] = None

class BoundaryStateInteropChecker:
    def __init__(self, schema_path: Path, semantic_table_path: Path) -> None:
        if Draft202012Validator is None:
            raise RuntimeError(
                "jsonschema is required for schema validation. Install with: pip install jsonschema"
            ) from JSONSCHEMA_IMPORT_ERROR
        self.schema_path = schema_path
        self.semantic_table_path = semantic_table_path
        self.schema = self._load_json(schema_path)
        self.table = self._load_json(semantic_table_path)
        self.validator = Draft202012Validator(self.schema)
        self.class_by_claim_type: Dict[str, str] = {}
        self.class_by_scope: Dict[str, str] = {}
        self.class_by_inference: Dict[str, str] = {}
        self.class_by_policy_context: Dict[str, str] = {}
        self.contradicting_nonclaims_by_class: Dict[str, Set[str]] = {}
        self._index_semantic_table()

    @staticmethod
    def _load_json(path: Path) -> Any:
        with path.open("r", encoding="utf-8") as fh:
            return json.load(fh)

    def _index_semantic_table(self) -> None:
        classes = self.table.get("semantic_classes", {})
        for class_name, body in classes.items():
            for value in body.get("claim_types", []):
                self.class_by_claim_type[value] = class_name
            for value in body.get("verification_scopes", []):
                self.class_by_scope[value] = class_name
            for value in body.get("prohibited_inferences", []):
                self.class_by_inference[value] = class_name
            for value in body.get("policy_context_types", []):
                self.class_by_policy_context[value] = class_name
            self.contradicting_nonclaims_by_class[class_name] = set(body.get("contradicts_non_claim_types", []))

    def check_file(self, fixture_path: Path) -> CheckResult:
        payload = self._load_json(fixture_path)
        return self.check_payload(payload, fixture_file=fixture_path.name)

    def check_payload(self, payload: Dict[str, Any], fixture_file: Optional[str] = None) -> CheckResult:
        expected = payload.get("expected_checker_result", {}) if isinstance(payload, dict) else {}
        expected_status = expected.get("status")
        expected_outcome = expected.get("outcome")

        schema_violations = self._schema_violations(payload)
        if schema_violations:
            outcome = self._schema_outcome(schema_violations)
            return self._result(payload, fixture_file, "HANDOFF_REJECTED", outcome, "SCHEMA", schema_violations, expected_status, expected_outcome)

        violations: List[Violation] = []
        violations.extend(self._profile_binding_violations(payload))
        violations.extend(self._semantic_class_field_violations(payload))
        violations.extend(self._consumer_acknowledgement_violations(payload))

        extension_signals, extension_violations = self._extension_scan(payload)
        violations.extend(extension_violations)

        signals: List[Signal] = []
        signals.extend(self._downstream_claim_signals(payload))
        signals.extend(self._downstream_inference_signals(payload, violations))
        signals.extend(self._policy_context_signals(payload, violations))
        signals.extend(extension_signals)

        violations.extend(self._orphaned_context_violations(payload))
        violations.extend(self._semantic_contradiction_violations(payload, signals))

        if violations:
            outcome = self._semantic_outcome(payload, violations)
            return self._result(payload, fixture_file, "HANDOFF_REJECTED", outcome, "SEMANTIC", violations, expected_status, expected_outcome)

        outcome = expected_outcome if expected_status == "HANDOFF_ACCEPTED" and expected_outcome else "HANDOFF_ACCEPTED"
        return self._result(payload, fixture_file, "HANDOFF_ACCEPTED", outcome, "ACCEPT", [], expected_status, expected_outcome)

    def _result(
        self,
        payload: Dict[str, Any],
        fixture_file: Optional[str],
        status: str,
        outcome: str,
        phase: str,
        violations: List[Violation],
        expected_status: Optional[str],
        expected_outcome: Optional[str],
    ) -> CheckResult:
        return CheckResult(
            checker_id=CHECKER_ID,
            fixture_file=fixture_file,
            handoff_id=payload.get("handoff_id") if isinstance(payload, dict) else None,
            profile_revision=payload.get("profile_revision") if isinstance(payload, dict) else None,
            status=status,
            outcome=outcome,
            validation_phase=phase,
            violations=[asdict(v) for v in violations],
            expected_status=expected_status,
            expected_outcome=expected_outcome,
            status_matches_expected=(status == expected_status) if expected_status is not None else None,
            outcome_matches_expected=(outcome == expected_outcome) if expected_outcome is not None else None,
        )

    def _schema_violations(self, payload: Dict[str, Any]) -> List[Violation]:
        errors = sorted(self.validator.iter_errors(payload), key=lambda e: list(e.path))
        out: List[Violation] = []
        for err in errors:
            path = ".".join(str(p) for p in err.absolute_path) or "$"
            vtype = "SCHEMA_VALIDATION_FAILED"
            if err.validator == "additionalProperties":
                vtype = "UNKNOWN_FIELD_PRESENT"
            elif "new_claim_boundary_ref" in path and err.validator in {"required", "minProperties", "type", "oneOf"}:
                vtype = "MALFORMED_NEW_CLAIM_BOUNDARY_REF"
            elif path == "new_claim_boundary_ref" or path.startswith("new_claim_boundary_ref"):
                vtype = "MALFORMED_NEW_CLAIM_BOUNDARY_REF"
            elif err.validator == "enum":
                vtype = "UNKNOWN_OPERATIVE_VALUE"
            out.append(Violation(vtype, f"Schema violation at {path}: {err.message}", phase="SCHEMA"))
        return out

    @staticmethod
    def _schema_outcome(violations: List[Violation]) -> str:
        priority = [
            "MALFORMED_NEW_CLAIM_BOUNDARY_REF",
            "UNKNOWN_FIELD_PRESENT",
            "UNKNOWN_OPERATIVE_VALUE",
            "SCHEMA_VALIDATION_FAILED",
        ]
        types = {v.violation_type for v in violations}
        for item in priority:
            if item in types:
                return item
        return violations[0].violation_type if violations else "SCHEMA_VALIDATION_FAILED"

    def _profile_binding_violations(self, payload: Dict[str, Any]) -> List[Violation]:
        out: List[Violation] = []
        if payload.get("handoff_profile") != SUPPORTED_PROFILE:
            out.append(Violation("UNSUPPORTED_HANDOFF_PROFILE", f"handoff_profile must be {SUPPORTED_PROFILE}."))
        if payload.get("semantic_class_table_ref") != SUPPORTED_TABLE_ID:
            out.append(Violation("SEMANTIC_CLASS_TABLE_REF_MISMATCH", f"semantic_class_table_ref must be {SUPPORTED_TABLE_ID}."))
        return out

    def _semantic_class_field_violations(self, payload: Any, path: str = "$") -> List[Violation]:
        out: List[Violation] = []
        if isinstance(payload, dict):
            for key, value in payload.items():
                child_path = f"{path}.{key}"
                if key == "semantic_class":
                    out.append(Violation("UNDECLARED_SEMANTIC_METADATA_ATTEMPTED", f"Payload-provided semantic_class field at {child_path} is non-operative and rejected."))
                out.extend(self._semantic_class_field_violations(value, child_path))
        elif isinstance(payload, list):
            for idx, item in enumerate(payload):
                out.extend(self._semantic_class_field_violations(item, f"{path}[{idx}]"))
        return out

    def _consumer_acknowledgement_violations(self, payload: Dict[str, Any]) -> List[Violation]:
        out: List[Violation] = []
        acknowledged = set(payload.get("consumer_acknowledgement", {}).get("acknowledged_non_claim_ids", []))
        for nonclaim in payload.get("source_non_claims", []):
            nonclaim_id = nonclaim.get("non_claim_id")
            if nonclaim_id and nonclaim_id not in acknowledged:
                out.append(Violation("SOURCE_NON_CLAIM_NOT_ACKNOWLEDGED", f"consumer_acknowledgement does not include {nonclaim_id}."))
        return out

    def _downstream_claim_signals(self, payload: Dict[str, Any]) -> List[Signal]:
        signals: List[Signal] = []
        for claim in payload.get("downstream_claims", []) or []:
            claim_id = claim.get("claim_id")
            derived_from = claim.get("derived_from") or []
            claim_type = claim.get("claim_type")
            scope = claim.get("verification_scope")
            if claim_type in self.class_by_claim_type:
                signals.append(Signal(self.class_by_claim_type[claim_type], "downstream_claim.claim_type", claim_type, claim_id, derived_from))
            if scope in self.class_by_scope:
                signals.append(Signal(self.class_by_scope[scope], "downstream_claim.verification_scope", scope, claim_id, derived_from))
        return signals

    def _downstream_inference_signals(self, payload: Dict[str, Any], violations: List[Violation]) -> List[Signal]:
        signals: List[Signal] = []
        for inference in payload.get("downstream_inferences", []) or []:
            class_name = self.class_by_inference.get(inference)
            if class_name:
                violations.append(Violation("PROHIBITED_INFERENCE_USED", f"downstream_inferences includes {inference}."))
                signals.append(Signal(class_name, "downstream_inferences", inference))
        return signals

    def _policy_context_signals(self, payload: Dict[str, Any], violations: List[Violation]) -> List[Signal]:
        signals: List[Signal] = []
        contexts = payload.get("policy_context") or []
        downstream_claim_ids = {c.get("claim_id") for c in payload.get("downstream_claims", []) or []}
        for entry in contexts:
            pc_type = entry.get("policy_context_type")
            linked = entry.get("linked_claim_id")
            if linked is None or linked not in downstream_claim_ids:
                violations.append(Violation("UNLINKED_POLICY_CONTEXT", f"policy_context {entry.get('policy_context_id')} is not linked to a downstream claim."))
            class_name = self.class_by_policy_context.get(pc_type)
            if class_name:
                signals.append(Signal(class_name, "policy_context.policy_context_type", pc_type, linked))
        return signals

    def _extension_scan(self, payload: Dict[str, Any]) -> Tuple[List[Signal], List[Violation]]:
        signals: List[Signal] = []
        violations: List[Violation] = []
        enabled = self._enabled_extension_map(payload)
        extensions = payload.get("extensions") or {}
        for namespace, fields in extensions.items():
            ns_decl = enabled.get(namespace)
            if ns_decl is None:
                violations.append(Violation("UNKNOWN_EXTENSION_NAMESPACE", f"extensions.{namespace} is present, but {namespace} is not declared in enabled_extension_namespaces."))
                for field_name, value in self._iter_extension_fields(fields):
                    if self._value_has_protected_semantics(value):
                        violations.append(Violation("UNDECLARED_EXTENSION_SEMANTIC_EXPANSION_ATTEMPTED", f"{namespace}.{field_name} carries protected semantic language/value through an undeclared extension namespace."))
                continue

            allowed = {f.get("field_name"): f for f in ns_decl.get("allowed_fields", []) or []}
            for field_name, value in self._iter_extension_fields(fields):
                field_decl = allowed.get(field_name)
                if field_decl is None:
                    violations.append(Violation("UNDECLARED_EXTENSION_FIELD", f"extensions.{namespace}.{field_name} is not declared in enabled_extension_namespaces[{namespace}].allowed_fields."))
                    if self._value_has_protected_semantics(value):
                        violations.append(Violation("UNDECLARED_EXTENSION_SEMANTIC_EXPANSION_ATTEMPTED", f"extensions.{namespace}.{field_name} carries protected semantics through an undeclared extension field."))
                    continue

                allowed_values = field_decl.get("allowed_values")
                if allowed_values is not None and value not in allowed_values:
                    violations.append(Violation("EXTENSION_VALUE_NOT_ALLOWED", f"extensions.{namespace}.{field_name} value {value!r} is not in allowed_values."))

                operative = bool(field_decl.get("operative"))
                semantic_mapping = field_decl.get("semantic_class_mapping")
                lint_text = bool(field_decl.get("lint_as_consumer_supplied_free_text"))

                if operative:
                    if not semantic_mapping:
                        if self._value_has_protected_semantics(value) or self._value_has_protected_semantics(field_name):
                            violations.append(Violation("UNDECLARED_EXTENSION_SEMANTIC_EXPANSION_ATTEMPTED", f"extensions.{namespace}.{field_name} is operative and carries protected semantics without semantic_class_mapping."))
                        violations.append(Violation("EXTENSION_OPERATIVE_FIELD_REQUIRES_SEMANTIC_MAPPING", f"Declared operative extension field {namespace}.{field_name} must declare semantic_class_mapping or remain non-operative."))
                    else:
                        signals.append(Signal(semantic_mapping, "extension.operative_field", str(value), f"{namespace}.{field_name}", []))
                else:
                    if lint_text and self._value_has_protected_semantics(value):
                        violations.append(Violation("NONOPERATIVE_EXTENSION_FIELD_CONTAINS_PROTECTED_SEMANTICS", f"Non-operative extension field {namespace}.{field_name} contains protected semantic language while lint_as_consumer_supplied_free_text is true."))
                        violations.append(Violation("UNDECLARED_EXTENSION_SEMANTIC_EXPANSION_ATTEMPTED", f"Non-operative extension metadata {namespace}.{field_name} must not imply readiness, approval, compliance, authority, correctness, truth, or reliance sufficiency."))
        return signals, violations

    @staticmethod
    def _enabled_extension_map(payload: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
        return {entry.get("namespace"): entry for entry in payload.get("enabled_extension_namespaces", []) or [] if entry.get("namespace")}

    @staticmethod
    def _iter_extension_fields(fields: Any) -> Iterable[Tuple[str, Any]]:
        if isinstance(fields, dict):
            for key, value in fields.items():
                yield key, value

    def _value_has_protected_semantics(self, value: Any) -> bool:
        if isinstance(value, (list, tuple, set)):
            return any(self._value_has_protected_semantics(item) for item in value)
        if isinstance(value, dict):
            return any(self._value_has_protected_semantics(k) or self._value_has_protected_semantics(v) for k, v in value.items())
        text = str(value).strip()
        if not text:
            return False
        # Exact controlled values first.
        if text in self.class_by_claim_type or text in self.class_by_scope or text in self.class_by_inference or text in self.class_by_policy_context:
            return True
        lowered = text.lower().replace("_", " ").replace("-", " ")
        return any(re.search(pattern, lowered, flags=re.IGNORECASE) for pattern, _ in PROTECTED_TEXT_PATTERNS)

    def _class_for_protected_text(self, text: str) -> Optional[str]:
        for pattern, class_name in PROTECTED_TEXT_PATTERNS:
            if re.search(pattern, text.lower().replace("_", " ").replace("-", " "), flags=re.IGNORECASE):
                return class_name
        return None

    def _orphaned_context_violations(self, payload: Dict[str, Any]) -> List[Violation]:
        out: List[Violation] = []
        effect = payload.get("declared_boundary_effect")
        if effect in {"REFERENCED_ONLY", "PRESERVED"}:
            if payload.get("policy_context") or payload.get("expansion_authority_ref") is not None or payload.get("new_claim_boundary_ref") is not None:
                out.append(Violation("ORPHANED_SEMANTIC_CONTEXT_WITHOUT_EXPANSION", f"Semantic expansion context is present while declared_boundary_effect is {effect}."))
        return out

    def _semantic_contradiction_violations(self, payload: Dict[str, Any], signals: List[Signal]) -> List[Violation]:
        out: List[Violation] = []
        source_nonclaim_types = {n.get("non_claim_type") for n in payload.get("source_non_claims", []) or []}
        contradicted_classes: Set[str] = set()
        contradicted_signals: List[Signal] = []
        for signal in signals:
            contradicted_by = self.contradicting_nonclaims_by_class.get(signal.semantic_class, set())
            if source_nonclaim_types & contradicted_by:
                contradicted_classes.add(signal.semantic_class)
                contradicted_signals.append(signal)

        if not contradicted_classes:
            return out

        expansion_ok, expansion_violations = self._validate_expanded_boundary(payload, contradicted_classes, contradicted_signals)
        if expansion_ok:
            return out

        acknowledged = set(payload.get("consumer_acknowledgement", {}).get("acknowledged_non_claim_ids", []))
        nonclaim_ids_by_type = {n.get("non_claim_type"): n.get("non_claim_id") for n in payload.get("source_non_claims", []) or []}
        for signal in contradicted_signals:
            details = f"{signal.source}={signal.value} maps to {signal.semantic_class}, contradicting source non-claims."
            out.append(Violation("SEMANTIC_CLASS_CONTRADICTS_SOURCE_NON_CLAIM", details))
            for nonclaim_type in self.contradicting_nonclaims_by_class.get(signal.semantic_class, set()):
                nonclaim_id = nonclaim_ids_by_type.get(nonclaim_type)
                if nonclaim_id and nonclaim_id in acknowledged:
                    out.append(Violation("DOWNSTREAM_CLAIM_CONTRADICTS_ACKNOWLEDGED_NON_CLAIM", f"Acknowledged source non-claim {nonclaim_id} is contradicted by {signal.source}={signal.value}."))
        out.extend(expansion_violations)
        # Explicitly document the required global scan behavior when contradiction occurs outside EXPANDED.
        if payload.get("declared_boundary_effect") in {"REFERENCED_ONLY", "PRESERVED"}:
            out.append(Violation("GLOBAL_CONTRADICTION_SCAN_REQUIRED", f"Semantic contradiction detected under {payload.get('declared_boundary_effect')}; scan is independent of declared_boundary_effect."))
        return out

    def _validate_expanded_boundary(self, payload: Dict[str, Any], classes: Set[str], signals: List[Signal]) -> Tuple[bool, List[Violation]]:
        out: List[Violation] = []
        if payload.get("declared_boundary_effect") != "EXPANDED":
            out.append(Violation("VALID_EXPANDED_BOUNDARY_REQUIRED_FOR_SEMANTIC_CLASS", "Semantic promotion requires declared_boundary_effect == EXPANDED."))
            return False, out

        auth = payload.get("expansion_authority_ref")
        boundary = payload.get("new_claim_boundary_ref")
        policy_context = payload.get("policy_context") or []
        downstream_nonclaims = payload.get("downstream_non_claims") or []
        external_evidence_refs = payload.get("external_evidence_refs") or []

        if not auth:
            out.append(Violation("VALID_EXPANDED_BOUNDARY_REQUIRED_FOR_SEMANTIC_CLASS", "expansion_authority_ref is missing."))
        if not boundary:
            out.append(Violation("VALID_EXPANDED_BOUNDARY_REQUIRED_FOR_SEMANTIC_CLASS", "new_claim_boundary_ref is missing."))
        if not policy_context:
            out.append(Violation("VALID_EXPANDED_BOUNDARY_REQUIRED_FOR_SEMANTIC_CLASS", "policy_context is missing."))
        if not downstream_nonclaims:
            out.append(Violation("VALID_EXPANDED_BOUNDARY_REQUIRED_FOR_SEMANTIC_CLASS", "downstream_non_claims are missing."))
        if not external_evidence_refs:
            out.append(Violation("VALID_EXPANDED_BOUNDARY_REQUIRED_FOR_SEMANTIC_CLASS", "external_evidence_refs are missing for promoted semantic claims."))

        if auth:
            out.extend(self._authority_alias_violations(payload, auth))
            authorized = set(auth.get("authorizes_semantic_classes", []) or [])
            missing = classes - authorized
            if missing:
                out.append(Violation("AUTHORITY_DOES_NOT_AUTHORIZE_PROMOTED_CLASS", f"expansion_authority_ref does not authorize promoted semantic classes: {sorted(missing)}."))
            if auth.get("not_derived_from_source_attestation") is not True:
                out.append(Violation("AUTHORITY_DERIVED_FROM_SOURCE_ATTESTATION", "not_derived_from_source_attestation must be true."))

        if boundary:
            authorized = set(boundary.get("authorizes_semantic_classes", []) or [])
            missing = classes - authorized
            if missing:
                out.append(Violation("NEW_CLAIM_BOUNDARY_DOES_NOT_AUTHORIZE_PROMOTED_CLASS", f"new_claim_boundary_ref does not authorize promoted semantic classes: {sorted(missing)}."))

        downstream_claim_ids = {c.get("claim_id") for c in payload.get("downstream_claims", []) or []}
        linked_claim_ids = {p.get("linked_claim_id") for p in policy_context if p.get("linked_claim_id")}
        if classes and downstream_claim_ids and not (linked_claim_ids & downstream_claim_ids):
            out.append(Violation("UNLINKED_POLICY_CONTEXT", "policy_context is not linked to a promoted downstream claim."))

        source_claim_ids = {c.get("claim_id") for c in payload.get("source_claims", []) or []}
        external_refs = {e.get("evidence_ref") for e in external_evidence_refs if e.get("evidence_ref")}
        for signal in signals:
            if signal.source.startswith("downstream_claim"):
                derived = set(signal.derived_from or [])
                if derived and derived <= source_claim_ids:
                    out.append(Violation("PROMOTED_CLAIM_DERIVED_SOLELY_FROM_RUNTIME_ATTESTATION", f"{signal.claim_id} is derived solely from source runtime attestation claims."))
                if external_refs and derived and not (derived & external_refs):
                    out.append(Violation("PROMOTED_CLAIM_LACKS_INDEPENDENT_EVIDENCE_REF", f"{signal.claim_id} does not derive from external_evidence_refs."))

        return len(out) == 0, out

    def _authority_alias_violations(self, payload: Dict[str, Any], auth: Dict[str, Any]) -> List[Violation]:
        out: List[Violation] = []
        authority_id = auth.get("authority_id") or ""
        exact_refs: Set[str] = set()
        fragments: Set[str] = set()
        for ref in payload.get("source_artifact_refs", []) or []:
            for key in ("artifact_ref", "artifact_hash", "signature_ref", "seal_ref"):
                value = ref.get(key)
                if not value:
                    continue
                exact_refs.add(value)
                fragments.update(self._reference_fragments(value))

        if authority_id in exact_refs:
            out.append(Violation("CIRCULAR_AUTHORITY_REFERENCE_ATTEMPTED", "expansion_authority_ref.authority_id equals a source runtime attestation identifier."))
            return out

        normalized_auth = self._normalize_ref(authority_id)
        for frag in fragments:
            if frag and len(frag) >= 6 and frag in normalized_auth:
                out.append(Violation("AUTHORITY_ALIAS_OF_RUNTIME_ATTESTATION_ATTEMPTED", f"expansion_authority_ref.authority_id encodes or aliases source runtime attestation fragment {frag!r}."))
                break
        if "derived-from" in normalized_auth or "seal" in normalized_auth and "authority" in normalized_auth:
            # Conservative: only add if no prior alias found and the id structurally claims derivation from seal evidence.
            if not any(v.violation_type == "AUTHORITY_ALIAS_OF_RUNTIME_ATTESTATION_ATTEMPTED" for v in out):
                out.append(Violation("AUTHORITY_ALIAS_OF_RUNTIME_ATTESTATION_ATTEMPTED", "expansion_authority_ref.authority_id appears derived from runtime attestation evidence."))
        return out

    @classmethod
    def _reference_fragments(cls, value: str) -> Set[str]:
        normalized = cls._normalize_ref(value)
        parts = set(re.split(r"[^a-z0-9]+", normalized))
        parts.discard("")
        # include URI tail and hash body where useful
        if "://" in value:
            parts.add(cls._normalize_ref(value.rsplit("/", 1)[-1]))
        if ":" in value:
            parts.add(cls._normalize_ref(value.split(":", 1)[-1]))
        return {p for p in parts if len(p) >= 6 and not re.fullmatch(r"0+", p)}

    @staticmethod
    def _normalize_ref(value: str) -> str:
        return re.sub(r"[^a-z0-9]+", "-", str(value).lower()).strip("-")

    def _semantic_outcome(self, payload: Dict[str, Any], violations: List[Violation]) -> str:
        types = {v.violation_type for v in violations}
        inferences = set(payload.get("downstream_inferences", []) or [])
        if "UNKNOWN_EXTENSION_NAMESPACE" in types:
            return "UNKNOWN_EXTENSION_NAMESPACE"
        if "NONOPERATIVE_EXTENSION_FIELD_CONTAINS_PROTECTED_SEMANTICS" in types or "UNDECLARED_EXTENSION_SEMANTIC_EXPANSION_ATTEMPTED" in types:
            return "UNDECLARED_EXTENSION_SEMANTIC_EXPANSION_ATTEMPTED"
        if "CIRCULAR_AUTHORITY_REFERENCE_ATTEMPTED" in types:
            return "CIRCULAR_AUTHORITY_REFERENCE_ATTEMPTED"
        if "AUTHORITY_ALIAS_OF_RUNTIME_ATTESTATION_ATTEMPTED" in types:
            return "AUTHORITY_ALIAS_OF_RUNTIME_ATTESTATION_ATTEMPTED"
        if "AUTHORITY_DOES_NOT_AUTHORIZE_PROMOTED_CLASS" in types:
            return "AUTHORITY_SCOPE_DOES_NOT_COVER_DOWNSTREAM_CLAIM"
        if "SEAL_IMPLIES_COMPLIANCE" in inferences:
            return "SEAL_TO_COMPLIANCE_PROMOTION_ATTEMPTED"
        if "ORPHANED_SEMANTIC_CONTEXT_WITHOUT_EXPANSION" in types:
            return "ORPHANED_SEMANTIC_CONTEXT_WITHOUT_EXPANSION"
        # v0.1.4 fixture 03 distinguishes an explicit acknowledged non-claim
        # contradiction using COMPLIANCE_ESTABLISHED under REFERENCED_ONLY from
        # synonym/reliance/PRESERVED promotion fixtures, which use the broader
        # SEMANTIC_CLASS_CONTRADICTS_SOURCE_NON_CLAIM outcome.
        if "DOWNSTREAM_CLAIM_CONTRADICTS_ACKNOWLEDGED_NON_CLAIM" in types:
            if payload.get("declared_boundary_effect") == "REFERENCED_ONLY":
                for claim in payload.get("downstream_claims", []) or []:
                    if claim.get("claim_type") == "COMPLIANCE_ESTABLISHED":
                        return "NON_CLAIM_ACKNOWLEDGED_BUT_CONTRADICTED"
        if "SEMANTIC_CLASS_CONTRADICTS_SOURCE_NON_CLAIM" in types:
            return "SEMANTIC_CLASS_CONTRADICTS_SOURCE_NON_CLAIM"
        if violations:
            return violations[0].violation_type
        return "HANDOFF_ACCEPTED"


def default_paths(packet_dir: Path) -> Tuple[Path, Path, Path]:
    return (
        packet_dir / "schemas" / "boundary_state_handoff_profile_v0_1_4.schema.json",
        packet_dir / "tables" / "semantic_class_table_v0_1_4.json",
        packet_dir / "fixtures",
    )


def run_fixtures(checker: BoundaryStateInteropChecker, fixtures_dir: Path) -> Dict[str, Any]:
    fixture_paths = sorted(fixtures_dir.glob("*.json"))
    results: List[CheckResult] = [checker.check_file(path) for path in fixture_paths]
    mismatches = [r for r in results if r.status_matches_expected is False or r.outcome_matches_expected is False]
    return {
        "checker_id": CHECKER_ID,
        "profile_revision": PROFILE_REVISION,
        "fixture_count": len(results),
        "passed_count": len(results) - len(mismatches),
        "failed_count": len(mismatches),
        "all_passed": len(mismatches) == 0,
        "results": [asdict(r) for r in results],
    }


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="Boundary-State Interoperability Checker v0.1.0")
    parser.add_argument("--packet-dir", type=Path, default=Path("profile_v0_1_4"), help="Path to frozen v0.1.4 profile packet directory.")
    parser.add_argument("--schema", type=Path, default=None, help="Override schema path.")
    parser.add_argument("--table", type=Path, default=None, help="Override semantic class table path.")
    parser.add_argument("--fixtures-dir", type=Path, default=None, help="Override fixtures directory.")
    parser.add_argument("--fixture", type=Path, default=None, help="Check one fixture JSON file.")
    parser.add_argument("--json", action="store_true", help="Emit JSON output.")
    parser.add_argument("--receipt-output", type=Path, default=None, help="Write JSON receipt to this path.")
    args = parser.parse_args(argv)

    schema_default, table_default, fixtures_default = default_paths(args.packet_dir)
    schema_path = args.schema or schema_default
    table_path = args.table or table_default
    fixtures_dir = args.fixtures_dir or fixtures_default

    checker = BoundaryStateInteropChecker(schema_path=schema_path, semantic_table_path=table_path)

    if args.fixture:
        result = checker.check_file(args.fixture)
        output: Any = asdict(result)
        exit_code = 0 if result.status_matches_expected is not False and result.outcome_matches_expected is not False else 1
    else:
        output = run_fixtures(checker, fixtures_dir)
        exit_code = 0 if output["all_passed"] else 1

    if args.receipt_output:
        args.receipt_output.parent.mkdir(parents=True, exist_ok=True)
        args.receipt_output.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    if args.json:
        print(json.dumps(output, indent=2, sort_keys=True))
    else:
        if isinstance(output, dict) and "results" in output:
            print(f"{CHECKER_ID}: {output['passed_count']}/{output['fixture_count']} fixtures matched expected status and outcome")
            for result in output["results"]:
                mark = "PASS" if result["status_matches_expected"] and result["outcome_matches_expected"] else "FAIL"
                print(f"{mark} {result['fixture_file']} actual={result['status']}/{result['outcome']} expected={result['expected_status']}/{result['expected_outcome']}")
        else:
            mark = "PASS" if output.get("status_matches_expected") and output.get("outcome_matches_expected") else "FAIL"
            print(f"{mark} {output.get('fixture_file')} actual={output.get('status')}/{output.get('outcome')} expected={output.get('expected_status')}/{output.get('expected_outcome')}")
            for violation in output.get("violations", []):
                print(f"  - {violation['violation_type']}: {violation['details']}")
    return exit_code


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
