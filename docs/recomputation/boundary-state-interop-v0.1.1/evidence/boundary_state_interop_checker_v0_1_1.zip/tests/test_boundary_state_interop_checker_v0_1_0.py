import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
from check_boundary_state_interop_v0_1_0 import BoundaryStateInteropChecker, run_fixtures


def test_v0_1_4_fixtures_match_expected():
    packet = ROOT / "profile_v0_1_4"
    checker = BoundaryStateInteropChecker(
        schema_path=packet / "schemas" / "boundary_state_handoff_profile_v0_1_4.schema.json",
        semantic_table_path=packet / "tables" / "semantic_class_table_v0_1_4.json",
    )
    receipt = run_fixtures(checker, packet / "fixtures")
    assert receipt["fixture_count"] == 18
    assert receipt["all_passed"], json.dumps(receipt, indent=2)
