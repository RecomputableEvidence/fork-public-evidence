import json
from pathlib import Path

from tools.check_boundary_state_interop_v0_1_1 import BoundaryStateInteropChecker


ROOT = Path(__file__).resolve().parents[1]


def checker():
    return BoundaryStateInteropChecker(
        schema_path=ROOT / "profile_v0_1_4" / "schemas" / "boundary_state_handoff_profile_v0_1_4.schema.json",
        semantic_table_path=ROOT / "profile_v0_1_4" / "tables" / "semantic_class_table_v0_1_4.json",
    )


def test_rwf_adv_a_is_rejected():
    result = checker().check_file(ROOT / "reviewer_regressions" / "fixtures" / "RWF_ADV_A_nonoperative_extension_genuine_paraphrase_no_trigger_tokens.json")
    assert result.status == "HANDOFF_REJECTED"
    assert result.outcome == "UNDECLARED_EXTENSION_SEMANTIC_EXPANSION_ATTEMPTED"
    assert any(v["violation_type"] == "NONOPERATIVE_EXTENSION_FIELD_CONTAINS_PROTECTED_SEMANTICS" for v in result.violations)


def test_accept_path_does_not_echo_expected_outcome():
    result = checker().check_file(ROOT / "reviewer_regressions" / "probes" / "RWF_PROBE_accept_outcome_must_not_echo_expected_v0_1_1.json")
    assert result.status == "HANDOFF_ACCEPTED"
    assert result.outcome == "ATTESTATION_REFERENCED_AS_EXISTENCE_EVIDENCE_ONLY"
    assert result.outcome != "RWF_SHOULD_NOT_BE_ECHOED"
    assert result.outcome_matches_expected is False
