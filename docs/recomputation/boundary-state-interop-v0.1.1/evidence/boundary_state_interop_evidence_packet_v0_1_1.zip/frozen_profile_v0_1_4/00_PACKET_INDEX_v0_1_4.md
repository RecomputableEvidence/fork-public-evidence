# Boundary-State Interoperability Profile v0.1.4

Generated: 2026-07-06T14:37:47Z

## Status

Private research/design packet. Not a public standard, product claim, compliance framework, authority layer, checker certification, or proof of legal or operational sufficiency.

## Purpose

Non-operative extension linting patch for the `RUNTIME_ATTESTATION_LAYER -> EVIDENCE_BOUNDARY_LAYER` seam.

## Patch scope

v0.1.4 adds one regression fixture and one checker clarification: non-operative extension metadata marked for consumer-supplied text linting must be scanned for protected semantic language.

## Included

- `docs/01_PROFILE_SUMMARY_v0_1_4.md`
- `docs/02_NONOPERATIVE_EXTENSION_LINTING_NOTES_v0_1_4.md`
- `docs/03_CHECKER_REQUIREMENTS_v0_1_4.md`
- `docs/04_EIGHTEEN_FIXTURE_LIST_v0_1_4.md`
- `docs/05_ADVERSARIAL_REVIEWER_PROMPT_v0_1_4.md`
- `tables/semantic_class_table_v0_1_4.json`
- `schemas/boundary_state_handoff_profile_v0_1_4.schema.json`
- `fixtures/*.json`
