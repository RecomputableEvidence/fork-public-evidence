# Eighteen Fixture List v0.1.4

1. `01_valid_attestation_referenced_as_existence_evidence_only_v0_1_4.json`
2. `02_invalid_runtime_attestation_to_compliance_combined_v0_1_4.json`
3. `03_invalid_nonclaim_acknowledged_but_contradicted_v0_1_4.json`
4. `04_invalid_orphaned_policy_context_without_expansion_v0_1_4.json`
5. `05_invalid_circular_authority_reference_from_seal_v0_1_4.json`
6. `06_invalid_synonym_compliance_promotion_v0_1_4.json`
7. `07_invalid_unknown_field_semantic_smuggling_v0_1_4.json`
8. `08_invalid_nested_unknown_field_smuggling_v0_1_4.json`
9. `09_invalid_referenced_only_with_downstream_semantic_promotion_v0_1_4.json`
10. `10_valid_expanded_compliance_with_independent_authority_v0_1_4.json`
11. `11_invalid_authority_scope_mismatch_v0_1_4.json`
12. `12_invalid_empty_new_claim_boundary_ref_v0_1_4.json`
13. `13_invalid_authority_alias_reference_v0_1_4.json`
14. `14_invalid_preserved_with_downstream_semantic_promotion_v0_1_4.json`
15. `15_valid_declared_nonoperative_extension_metadata_v0_1_4.json`
16. `16_invalid_undeclared_extension_namespace_v0_1_4.json`
17. `17_invalid_declared_extension_operates_without_semantic_mapping_v0_1_4.json`
18. `18_invalid_nonoperative_extension_with_reliance_language_v0_1_4.json`

## New fixture in v0.1.4

`18_invalid_nonoperative_extension_with_reliance_language_v0_1_4.json` tests a declared non-operative extension field whose text says: `Operationally acceptable and ready for reliance.`

Expected result: reject as `UNDECLARED_EXTENSION_SEMANTIC_EXPANSION_ATTEMPTED`.
