# Checker Requirements v0.1.4

A conforming checker must run the v0.1.3 passes plus the v0.1.4 non-operative extension linting pass.

## Existing required passes

1. Schema validation against `schemas/boundary_state_handoff_profile_v0_1_4.schema.json`.
2. Load `tables/semantic_class_table_v0_1_4.json`.
3. Derive semantic classes from the table, not from consumer-provided fields.
4. Run global semantic scans independent of `declared_boundary_effect`.
5. Compare downstream semantic classes against source non-claims.
6. Validate expanded boundaries when a downstream semantic class contradicts a source non-claim.
7. Verify authority scope covers the promoted semantic class.
8. Verify `new_claim_boundary_ref` is well formed and authorizes the promoted semantic class.
9. Reject authority references that equal, alias, derive from, encode, or point to runtime attestation evidence.
10. Reject undeclared extension namespaces or undeclared operative extension fields.
11. Validate declared extension namespaces against actual `extensions` payload keys.
12. Validate extension fields against declared `allowed_fields`.
13. Apply semantic mapping and contradiction rules to operative extension fields.

## New v0.1.4 pass

14. For any extension field where `operative: false` and `lint_as_consumer_supplied_free_text: true`, scan the field value for protected semantic language.

If protected semantic language is present, reject as:

`UNDECLARED_EXTENSION_SEMANTIC_EXPANSION_ATTEMPTED`

with optional detail:

`NONOPERATIVE_EXTENSION_FIELD_CONTAINS_PROTECTED_SEMANTICS`

This pass ensures a declared non-operative metadata field cannot become an interpretive side channel for readiness, approval, compliance, authority, correctness, truth, or reliance sufficiency.
