# Non-Operative Extension Linting Notes v0.1.4

## Purpose

v0.1.3 closed the extension namespace surface for declared namespaces, undeclared namespaces, and operative extension fields without semantic mapping.

v0.1.4 closes the remaining narrow fixture gap: non-operative extension metadata whose text contains protected semantic language.

## Rule

A field marked `operative: false` is ignored for positive validation. It cannot establish truth, correctness, compliance, authority, approval, readiness, or reliance sufficiency.

However, when that field is also marked `lint_as_consumer_supplied_free_text: true`, the checker must scan the field value for protected semantic language.

If the value implies readiness, approval, compliance, authority, correctness, truth, or reliance sufficiency, reject as:

`UNDECLARED_EXTENSION_SEMANTIC_EXPANSION_ATTEMPTED`

Recommended secondary violation:

`NONOPERATIVE_EXTENSION_FIELD_CONTAINS_PROTECTED_SEMANTICS`

## Protected semantic examples

Examples include, but are not limited to:

- ready for reliance;
- reliance-ready;
- approved;
- compliant;
- compliance confirmed;
- authorized;
- correct;
- truth established;
- production ready;
- safe to rely on.

The linting rule does not make non-operative text operative. It prevents non-operative text from being used as a semantic side channel.
