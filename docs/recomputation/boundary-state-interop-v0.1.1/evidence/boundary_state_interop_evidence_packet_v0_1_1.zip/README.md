# Boundary-State Interoperability Evidence Packet v0.1.1

Private research/design evidence packet rebuilt after Checker v0.1.1 Independent Review Patch.

## Results

- Canonical suite: 18/18 matched expected status/outcome.
- Adversarial suite: 15/15 matched expected status/outcome.
- Reviewer regression suite: 1/1 matched expected status/outcome.
- Accept-outcome echo probe: passed.
- PYTHONHASHSEED alias-detail determinism probe: passed.

## Start here

1. `00_EVIDENCE_PACKET_INDEX_v0_1_1.md`
2. `docs/EVIDENCE_SUMMARY_v0_1_1.md`
3. `docs/INDEPENDENT_REVIEWER_NOTE_v0_1_1.md`
4. `docs/REPRODUCTION_GUIDE_v0_1_1.md`
5. `docs/SHA256_VERIFICATION_NOTE_v0_1_1.md`
