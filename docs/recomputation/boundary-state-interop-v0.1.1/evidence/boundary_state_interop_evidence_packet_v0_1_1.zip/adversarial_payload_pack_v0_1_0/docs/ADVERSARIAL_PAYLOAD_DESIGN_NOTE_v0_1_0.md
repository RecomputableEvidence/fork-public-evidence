# Adversarial Payload Design Note v0.1.0

## Objective

The canonical v0.1.4 profile suite verifies expected behavior across 18 fixtures.

This adversarial payload pack tests whether the checker remains stable under schema-valid but semantically hostile payloads, near-boundary valid cases, and multiple simultaneous violation conditions.

## Design constraints

- Do not revise the frozen v0.1.4 profile.
- Do not revise the checker.
- Use schema-valid payloads where possible.
- Include at least one schema-level adversarial case.
- Include at least one valid near-boundary case to test over-rejection.
- Preserve the profile non-claims.

## Payload coverage

| ID | Attack surface | Purpose |
|---|---|---|
| ADV_001 | Non-operative extension text contains reliance paraphrase | Reject protected semantic text in linted non-operative extension field |
| ADV_002 | Operative extension maps to RELIANCE under REFERENCED_ONLY | Reject extension semantic promotion without expanded boundary |
| ADV_003 | Declared namespace with undeclared protected field | Reject field-level extension smuggling |
| ADV_004 | Payload-provided semantic_class in extension object | Reject consumer-provided semantic_class metadata |
| ADV_005 | Policy context laundering under PRESERVED | Reject semantic context under non-expanded boundary effect |
| ADV_006 | Expanded compliance missing authority | Reject expansion missing authority record |
| ADV_007 | Claim boundary scope mismatch | Reject expansion with wrong claim boundary semantic class |
| ADV_008 | Authority alias via signature identifier | Reject authority derived from runtime attestation signature |
| ADV_009 | Authority alias via artifact identifier tail | Reject authority derived from artifact reference |
| ADV_010 | Multiple simultaneous violations | Confirm deterministic outcome priority under multiple failures |
| ADV_011 | Valid expanded mixed evidence case | Accept near-boundary valid expansion with independent evidence present |
| ADV_012 | External evidence exists but claim does not derive from it | Reject promoted claim lacking linked independent evidence |
| ADV_013 | Nested non-operative object contains protected text | Reject protected semantics hidden in nested extension object |
| ADV_014 | Unknown operative claim_type | Reject schema-level unknown operative value |
| ADV_015 | Expanded claim derives solely from source runtime attestation | Reject expanded claim without independent derivation |

## Interpretation

A passing adversarial pack does not prove the checker is complete.

It demonstrates that the checker handles this specific adversarial payload set consistently with the frozen v0.1.4 boundary rules.
