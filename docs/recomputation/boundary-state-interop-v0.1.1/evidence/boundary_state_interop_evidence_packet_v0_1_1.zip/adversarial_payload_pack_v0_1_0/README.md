# Boundary-State Interoperability Checker Adversarial Payload Pack v0.1.0

Generated: 2026-07-06T15:11:10Z

## Status

Private research/design adversarial payload pack.

This pack does not revise Boundary-State Interoperability Profile v0.1.4 and does not revise Boundary-State Interoperability Checker v0.1.0.

## Purpose

Exercise checker behavior beyond the canonical 18-fixture v0.1.4 suite.

The profile surface remains frozen. Further issues should be demonstrated against checker behavior, not by expanding the profile surface.

## Scope

- Checker: `BOUNDARY_STATE_INTEROPERABILITY_CHECKER_v0_1_0`
- Frozen profile: Boundary-State Interoperability Profile v0.1.4
- Seam: `RUNTIME_ATTESTATION_LAYER -> EVIDENCE_BOUNDARY_LAYER`
- Payload count: 15

## Result

`15/15` adversarial payloads matched expected status and outcome.

See:

- `receipts/ADVERSARIAL_PAYLOAD_RUN_RECEIPT_v0_1_0.md`
- `receipts/adversarial_payload_run_receipt_v0_1_0.json`
- `receipts/adversarial_payload_run_stdout_v0_1_0.txt`

## Run

From the package root:

```bash
python checker_inputs/tools/check_boundary_state_interop_v0_1_0.py \
  --packet-dir checker_inputs/profile_v0_1_4 \
  --fixtures-dir payloads
```

For JSON output:

```bash
python checker_inputs/tools/check_boundary_state_interop_v0_1_0.py \
  --packet-dir checker_inputs/profile_v0_1_4 \
  --fixtures-dir payloads \
  --json
```

## Non-claims

This payload pack does not establish truth, correctness, compliance, authority, approval, safety, production readiness, reliance sufficiency, legal sufficiency, or operational sufficiency.

It only exercises checker behavior against adversarial boundary-state payloads.
