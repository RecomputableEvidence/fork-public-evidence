# Boundary-State Interoperability Checker Adversarial Payload Run Receipt v0.1.0

Generated: 2026-07-06T15:11:10Z

## Scope

This receipt records execution of Boundary-State Interoperability Checker v0.1.0 against the adversarial payload pack v0.1.0.

Profile input remains frozen at Boundary-State Interoperability Profile v0.1.4.

## Summary

- Checker: `BOUNDARY_STATE_INTEROPERABILITY_CHECKER_v0_1_0`
- Profile revision: `v0.1.4`
- Payload count: `15`
- Passed expected status/outcome: `15`
- Failed expected status/outcome: `0`
- All passed: `True`

## Payload Results

- PASS `ADV_001_invalid_nonoperative_extension_reliance_paraphrase_v0_1_0.json` — actual `HANDOFF_REJECTED/UNDECLARED_EXTENSION_SEMANTIC_EXPANSION_ATTEMPTED`, expected `HANDOFF_REJECTED/UNDECLARED_EXTENSION_SEMANTIC_EXPANSION_ATTEMPTED`
- PASS `ADV_002_invalid_operative_extension_reliance_class_under_referenced_only_v0_1_0.json` — actual `HANDOFF_REJECTED/SEMANTIC_CLASS_CONTRADICTS_SOURCE_NON_CLAIM`, expected `HANDOFF_REJECTED/SEMANTIC_CLASS_CONTRADICTS_SOURCE_NON_CLAIM`
- PASS `ADV_003_invalid_declared_namespace_undeclared_field_smuggling_v0_1_0.json` — actual `HANDOFF_REJECTED/UNDECLARED_EXTENSION_SEMANTIC_EXPANSION_ATTEMPTED`, expected `HANDOFF_REJECTED/UNDECLARED_EXTENSION_SEMANTIC_EXPANSION_ATTEMPTED`
- PASS `ADV_004_invalid_payload_semantic_class_field_in_extension_v0_1_0.json` — actual `HANDOFF_REJECTED/UNDECLARED_SEMANTIC_METADATA_ATTEMPTED`, expected `HANDOFF_REJECTED/UNDECLARED_SEMANTIC_METADATA_ATTEMPTED`
- PASS `ADV_005_invalid_policy_context_laundering_under_preserved_v0_1_0.json` — actual `HANDOFF_REJECTED/ORPHANED_SEMANTIC_CONTEXT_WITHOUT_EXPANSION`, expected `HANDOFF_REJECTED/ORPHANED_SEMANTIC_CONTEXT_WITHOUT_EXPANSION`
- PASS `ADV_006_invalid_expanded_compliance_missing_authority_v0_1_0.json` — actual `HANDOFF_REJECTED/SEMANTIC_CLASS_CONTRADICTS_SOURCE_NON_CLAIM`, expected `HANDOFF_REJECTED/SEMANTIC_CLASS_CONTRADICTS_SOURCE_NON_CLAIM`
- PASS `ADV_007_invalid_new_claim_boundary_scope_mismatch_v0_1_0.json` — actual `HANDOFF_REJECTED/SEMANTIC_CLASS_CONTRADICTS_SOURCE_NON_CLAIM`, expected `HANDOFF_REJECTED/SEMANTIC_CLASS_CONTRADICTS_SOURCE_NON_CLAIM`
- PASS `ADV_008_invalid_authority_alias_signature_wrapper_v0_1_0.json` — actual `HANDOFF_REJECTED/AUTHORITY_ALIAS_OF_RUNTIME_ATTESTATION_ATTEMPTED`, expected `HANDOFF_REJECTED/AUTHORITY_ALIAS_OF_RUNTIME_ATTESTATION_ATTEMPTED`
- PASS `ADV_009_invalid_authority_alias_artifact_tail_v0_1_0.json` — actual `HANDOFF_REJECTED/AUTHORITY_ALIAS_OF_RUNTIME_ATTESTATION_ATTEMPTED`, expected `HANDOFF_REJECTED/AUTHORITY_ALIAS_OF_RUNTIME_ATTESTATION_ATTEMPTED`
- PASS `ADV_010_invalid_multiple_simultaneous_violations_v0_1_0.json` — actual `HANDOFF_REJECTED/UNDECLARED_EXTENSION_SEMANTIC_EXPANSION_ATTEMPTED`, expected `HANDOFF_REJECTED/UNDECLARED_EXTENSION_SEMANTIC_EXPANSION_ATTEMPTED`
- PASS `ADV_011_valid_expanded_mixed_independent_and_source_evidence_v0_1_0.json` — actual `HANDOFF_ACCEPTED/AUTHORIZED_EXPANDED_BOUNDARY_RECORDED`, expected `HANDOFF_ACCEPTED/AUTHORIZED_EXPANDED_BOUNDARY_RECORDED`
- PASS `ADV_012_invalid_expanded_claim_lacks_independent_evidence_ref_v0_1_0.json` — actual `HANDOFF_REJECTED/SEMANTIC_CLASS_CONTRADICTS_SOURCE_NON_CLAIM`, expected `HANDOFF_REJECTED/SEMANTIC_CLASS_CONTRADICTS_SOURCE_NON_CLAIM`
- PASS `ADV_013_invalid_nonoperative_extension_nested_dict_protected_semantics_v0_1_0.json` — actual `HANDOFF_REJECTED/UNDECLARED_EXTENSION_SEMANTIC_EXPANSION_ATTEMPTED`, expected `HANDOFF_REJECTED/UNDECLARED_EXTENSION_SEMANTIC_EXPANSION_ATTEMPTED`
- PASS `ADV_014_invalid_unknown_operative_claim_type_v0_1_0.json` — actual `HANDOFF_REJECTED/UNKNOWN_OPERATIVE_VALUE`, expected `HANDOFF_REJECTED/UNKNOWN_OPERATIVE_VALUE`
- PASS `ADV_015_invalid_expanded_claim_derived_solely_from_runtime_attestation_v0_1_0.json` — actual `HANDOFF_REJECTED/SEMANTIC_CLASS_CONTRADICTS_SOURCE_NON_CLAIM`, expected `HANDOFF_REJECTED/SEMANTIC_CLASS_CONTRADICTS_SOURCE_NON_CLAIM`
