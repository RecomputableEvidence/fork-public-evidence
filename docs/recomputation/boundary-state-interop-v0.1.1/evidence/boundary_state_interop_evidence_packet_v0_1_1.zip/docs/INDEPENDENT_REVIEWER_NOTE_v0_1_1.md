# Independent Reviewer Note v0.1.1

## Review posture

Reviewers should evaluate whether Checker v0.1.1 resolves the independent-review findings while preserving the frozen v0.1.4 profile.

## Questions for review

1. Does RWF_ADV_A now reject for the right semantic reason?
2. Are accepted outcomes computed independently of `expected_checker_result.outcome`?
3. Are authority-alias violation details deterministic across `PYTHONHASHSEED` values?
4. Do the canonical and adversarial suites continue to reproduce?
5. Does the stronger paraphrase lint over-reject any legitimate non-operative metadata?
6. Are there additional schema-valid paraphrases that should become reviewer-generated regression payloads?
