# Reproduction Guide v0.1.1

## Requirements

- Python 3
- `jsonschema`

## Extract source artifacts

From the evidence packet root:

```bash
mkdir -p repro/checker_v0_1_1
unzip -q source_artifacts/boundary_state_interop_checker_v0_1_1.zip -d repro/checker_v0_1_1
```

## Canonical suite

```bash
python repro/checker_v0_1_1/tools/check_boundary_state_interop_v0_1_1.py \
  --packet-dir repro/checker_v0_1_1/profile_v0_1_4 \
  --fixtures-dir repro/checker_v0_1_1/profile_v0_1_4/fixtures \
  --json
```

Expected: `18/18` matched expected status/outcome.

## Adversarial suite

```bash
python repro/checker_v0_1_1/tools/check_boundary_state_interop_v0_1_1.py \
  --packet-dir repro/checker_v0_1_1/profile_v0_1_4 \
  --fixtures-dir repro/checker_v0_1_1/adversarial_payload_pack_v0_1_0/payloads \
  --json
```

Expected: `15/15` matched expected status/outcome.

## Reviewer regression suite

```bash
python repro/checker_v0_1_1/tools/check_boundary_state_interop_v0_1_1.py \
  --packet-dir repro/checker_v0_1_1/profile_v0_1_4 \
  --fixtures-dir repro/checker_v0_1_1/reviewer_regressions/fixtures \
  --json
```

Expected: `1/1` matched expected status/outcome.

## SHA verification

See `docs/SHA256_VERIFICATION_NOTE_v0_1_1.md`.
