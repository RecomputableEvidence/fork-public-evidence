# SHA256 Verification Note v0.1.1

The top-level `SHA256SUMS.txt` file is intended to be verified from the root of the unpacked evidence packet.

Nested package SHA files, such as those inside `checker_v0_1_1/` or `adversarial_payload_pack_v0_1_0/`, may reference the complete source package layout. To verify those nested SHA files, first extract the corresponding ZIP under `source_artifacts/`, then run `sha256sum -c SHA256SUMS.txt` from the root of that extracted source package.

The selected expanded directories in the evidence packet are included for reviewer convenience and may not contain every file referenced by nested source-package SHA files.
