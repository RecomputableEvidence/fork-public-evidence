# Boundary-State Interoperability Checker v0.1.1

Independent Review Patch for frozen Boundary-State Interoperability Profile v0.1.4.

Generated: 2026-07-06T18:32:04Z

## Status

Private research/design checker patch.

## Scope

This patch preserves the frozen v0.1.4 profile and patches checker behavior only.

## Findings addressed

1. **RWF_ADV_A paraphrase false accept**  
   A schema-valid non-operative extension field expressed reliance/readiness semantics through paraphrase without using v0.1.0 trigger phrases. v0.1.1 adds the reviewer payload as a regression fixture and strengthens protected semantic linting.

2. **Accepted-outcome echo issue**  
   v0.1.0 could echo `expected_checker_result.outcome` on accepted payloads. v0.1.1 computes accepted outcomes from observed boundary state.

3. **Authority-alias detail nondeterminism**  
   v0.1.0 could emit different alias fragments depending on Python hash seed. v0.1.1 sorts candidate fragments before selecting the emitted violation detail.

## Suites

- Canonical v0.1.4 fixture suite.
- Adversarial Payload Pack v0.1.0.
- Reviewer-generated regression suite v0.1.1.

## Non-claims

This checker does not establish legal sufficiency, operational sufficiency, compliance, safety, truth, correctness, authority, approval, production readiness, reliance sufficiency, or exhaustive adversarial coverage.
