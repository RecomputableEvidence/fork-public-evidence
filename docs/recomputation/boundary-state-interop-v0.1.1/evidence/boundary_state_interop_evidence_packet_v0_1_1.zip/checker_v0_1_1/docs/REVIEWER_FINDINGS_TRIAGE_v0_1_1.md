# Reviewer Findings Triage v0.1.1

| Finding | Classification | Severity | v0.1.1 Action |
|---|---|---:|---|
| RWF_ADV_A paraphrase false accept | Checker false negative | High | Add regression fixture and strengthened semantic linting |
| Accepted-outcome echo | Checker/test methodology issue | High | Compute accepted outcomes independently |
| Alias detail nondeterminism | Receipt determinism issue | Medium | Sort alias fragments deterministically |
| Selected-expanded SHA ambiguity | Evidence-packet documentation issue | Low/Medium | Clarify SHA verification paths in evidence packet v0.1.1 |

## Profile impact

No confirmed profile ambiguity is introduced by these findings. Profile v0.1.4 remains the frozen normative input for this patch.
