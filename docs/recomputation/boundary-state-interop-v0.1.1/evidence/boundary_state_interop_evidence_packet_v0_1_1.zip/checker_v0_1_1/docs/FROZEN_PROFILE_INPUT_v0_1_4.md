# Frozen Profile Input v0.1.4

Boundary-State Interoperability Profile v0.1.4 is preserved unchanged as the normative input for Checker v0.1.1.

v0.1.1 patches checker behavior and evidence packaging only.
