# Boundary-State Interoperability Checker v0.1.1 Independent Review Patch

## Purpose

Patch checker behavior after independent adversarial reproduction of v0.1.0.

## Frozen input

Boundary-State Interoperability Profile v0.1.4 remains frozen.

This patch does not revise the profile, schema, semantic class table, or canonical fixtures except by packaging them as unchanged source inputs for v0.1.1 testing.

## Reviewer findings

### RWF_ADV_A — non-operative extension paraphrase false accept

A reviewer-generated schema-valid payload used the non-operative `x-review.review_note` field to say the handoff was fully vetted, sound, cleared for downstream consumption, and that recipients may proceed on that basis. The v0.1.0 checker accepted the payload because the text avoided the literal protected trigger phrases.

Patch:

- Add the reviewer payload as a regression fixture.
- Expand protected semantic detection to include paraphrases conveying clearance/readiness/reliance semantics.

### ACCEPT_OUTCOME_ECHO — accepted outcome copied from expected value

The v0.1.0 checker could return an arbitrary expected accepted outcome supplied inside the payload. v0.1.1 computes accepted outcomes independently.

Patch:

- Add `_accepted_outcome(payload)`.
- Use payload state, not `expected_checker_result`, to compute accepted outcomes.
- Add a methodology probe showing an arbitrary expected outcome is not echoed.

### PYTHONHASHSEED_ALIAS_DETAIL_NONDETERMINISM — receipt detail instability

Authority alias fragments were selected from an unordered set. v0.1.1 sorts fragments before emitting the violation detail.

Patch:

- Sort alias fragments by descending length, then lexicographically.
- Add a determinism probe across multiple `PYTHONHASHSEED` values.

## Status

v0.1.1 is a checker behavior patch and evidence rebuild input. It does not claim completeness or production readiness.
