#!/usr/bin/env python3
"""
Independent adversarial mutation harness for PROOF-005 CAD v0.2.2 exterior recomputation.
Constructed by the reviewer (not copied from shipped fixtures) per Sections 7-12 of
PROOF005_CAD_v0.2.2_EXECUTABLE_EXTERIOR_RECOMPUTATION_REQUEST.md.

Design:
- SCRATCH is a working copy of the exact candidate tree (git metadata stripped).
- Each test case backs up exactly one target file, writes a mutated version,
  invokes the REAL checker script via subprocess (never a reimplementation),
  captures raw stdout/stderr/exit code, then restores the original file bytes
  before the next case (sequential isolation).
- Every result is written to raw_outputs/mutations/<id>.txt AND aggregated into
  results.json / results.txt.
"""
from __future__ import annotations
import json, subprocess, sys, os, shutil, hashlib
from pathlib import Path

SCRATCH = Path("/home/claude/proof005_work/mutation_scratch")
RAW_DIR = Path("/home/claude/proof005_work/raw_outputs/mutations")
RAW_DIR.mkdir(parents=True, exist_ok=True)

V2 = "docs/meta-evidence/conversational-authority-drift-v0.2"
CASE = f"{V2}/cases/CAD_004_CLAUDE_SOURCE_ROLE_BINDING"
SUPP = f"{V2}/supplements/SUPPLEMENT_001_META_ASSESSMENT"

CONTROL = f"{V2}/CONTROL_EFFECTS_v0_2.json"
LINEAGE = f"{V2}/HISTORICAL_LINEAGE_v0_2.json"
CASE_RECORD = f"{CASE}/CASE_RECORD_v0_2.json"
LEDGER = f"{CASE}/CLAIM_LEDGER_v0_2.json"
EVENTS = f"{CASE}/OBSERVABLE_EVENT_REGISTER_v0_2.json"
FAMILIES = f"{SUPP}/FAMILY_GROUNDING_REGISTER_v0_2.json"
ASSESSOR = f"{SUPP}/ASSESSOR_CORRECTION_EVENT_v0_2.json"

CHECKERS = {
    "v0_2": "tools/check_fork_cad_candidate_v0_2.py",
    "v0_2_1": "tools/check_fork_cad_candidate_v0_2_1.py",
    "v0_2_2": "tools/check_fork_cad_candidate_v0_2_2.py",
}

results = []

def load(rel):
    return json.loads((SCRATCH / rel).read_text(encoding="utf-8"))

def dumps(obj):
    return json.dumps(obj, indent=2, ensure_ascii=False) + "\n"

def run_checker(checker="v0_2_2"):
    script = CHECKERS[checker]
    proc = subprocess.run(
        [sys.executable, script, "--root", "."],
        cwd=SCRATCH, capture_output=True, text=True, timeout=60,
    )
    return proc.returncode, proc.stdout, proc.stderr

EXHIBIT_DIR = Path("/home/claude/proof005_work/raw_outputs/exhibits")
EXHIBIT_DIR.mkdir(parents=True, exist_ok=True)

def case(cid, section, description, target_rel, new_text, expect, checker="v0_2_2", extra_note=""):
    """Backup target_rel, write new_text (raw string), run checker, restore, record result."""
    target = SCRATCH / target_rel
    original = target.read_bytes()
    noop_warning = ""
    if new_text.encode("utf-8") == original:
        noop_warning = "WARNING: mutated text is BYTE-IDENTICAL to pristine original -- this test is a NO-OP and its result is not meaningful."
        print(f"!!!! {cid}: {noop_warning}")
    # Preserve the exact mutated exhibit regardless of outcome.
    ext = ".json" if target_rel.endswith(".json") else ".txt"
    (EXHIBIT_DIR / f"{cid}{ext}").write_text(new_text, encoding="utf-8")
    try:
        target.write_text(new_text, encoding="utf-8")
        rc, out, err = run_checker(checker)
    finally:
        target.write_bytes(original)
    outcome = "ACCEPT" if rc == 0 else "REJECT"
    status = "MATCH" if outcome == expect else "**MISMATCH**"
    rec = {
        "id": cid, "section": section, "description": description,
        "target_file": target_rel, "checker": CHECKERS[checker],
        "expected": expect, "observed": outcome, "status": status,
        "exit_code": rc, "stdout": out.strip(), "stderr": err.strip(),
        "note": extra_note, "noop_warning": noop_warning,
        "exhibit_file": f"exhibits/{cid}{ext}",
    }
    results.append(rec)
    (RAW_DIR / f"{cid}.txt").write_text(
        f"id={cid}\nsection={section}\ndescription={description}\n"
        f"target_file={target_rel}\nchecker={CHECKERS[checker]}\n"
        f"expected={expect}\nobserved={outcome}\nstatus={status}\nexit_code={rc}\n"
        f"exhibit_file=exhibits/{cid}{ext}\nnoop_warning={noop_warning}\n"
        f"--- stdout ---\n{out}\n--- stderr ---\n{err}\nnote={extra_note}\n",
        encoding="utf-8",
    )
    print(f"[{status:12}] {cid:28} exp={expect:6} got={outcome:6} rc={rc}  {description[:70]}")
    return rec

# ============================================================
# SECTION 7 — R003 duplicate-key parsing parity
# ============================================================

# 7.1/7.2 CONTROL_EFFECTS_v0_2.json top-level duplicate "admission"
control_pristine = (SCRATCH / CONTROL).read_text(encoding="utf-8")

dup_a = control_pristine.replace(
    '"admission": false,',
    '"admission": false,\n  "admission": true,'
)
case("R003-01", "S7", 'CONTROL_EFFECTS top-level dup "admission": compliant(false) then non-compliant(true)',
     CONTROL, dup_a, "REJECT")

dup_b = control_pristine.replace(
    '"admission": false,',
    '"admission": true,\n  "admission": false,'
)
case("R003-02", "S7", 'CONTROL_EFFECTS top-level dup "admission": non-compliant(true) then compliant(false) [reverse - rigorous test of last-value-wins bypass]',
     CONTROL, dup_b, "REJECT")

# 7.3/7.4 another top-level governed artifact: HISTORICAL_LINEAGE "status"
lineage_pristine = (SCRATCH / LINEAGE).read_text(encoding="utf-8")
lin_dup_a = lineage_pristine.replace(
    '"status": "CORRECTION_SUCCESSOR_CANDIDATE_NOT_ADMITTED",\n  "construction_base"',
    '"status": "CORRECTION_SUCCESSOR_CANDIDATE_NOT_ADMITTED",\n  "status": "ADMITTED",\n  "construction_base"'
)
case("R003-03", "S7", 'HISTORICAL_LINEAGE top-level dup "status": compliant then non-compliant("ADMITTED")',
     LINEAGE, lin_dup_a, "REJECT")

lin_dup_b = lineage_pristine.replace(
    '"status": "CORRECTION_SUCCESSOR_CANDIDATE_NOT_ADMITTED",\n  "construction_base"',
    '"status": "ADMITTED",\n  "status": "CORRECTION_SUCCESSOR_CANDIDATE_NOT_ADMITTED",\n  "construction_base"'
)
case("R003-04", "S7", 'HISTORICAL_LINEAGE top-level dup "status": non-compliant("ADMITTED") then compliant [reverse]',
     LINEAGE, lin_dup_b, "REJECT")

# 7.5/7.6 nested governed object: lineage.standing.execution_authorized
nest_dup_a = lineage_pristine.replace(
    '"execution_authorized": false',
    '"execution_authorized": false,\n    "execution_authorized": true'
)
case("R003-05", "S7", 'HISTORICAL_LINEAGE nested standing.execution_authorized dup: compliant(false) then non-compliant(true)',
     LINEAGE, nest_dup_a, "REJECT")

nest_dup_b = lineage_pristine.replace(
    '"execution_authorized": false',
    '"execution_authorized": true,\n    "execution_authorized": false'
)
case("R003-06", "S7", 'HISTORICAL_LINEAGE nested standing.execution_authorized dup: non-compliant(true) then compliant(false) [reverse]',
     LINEAGE, nest_dup_b, "REJECT")

# 7.7 Unicode escaped-alias duplicate key (prescribed known pressure - independently reproduced, does NOT count as reviewer-originated challenge)
events_pristine = (SCRATCH / EVENTS).read_text(encoding="utf-8")
uni_dup = events_pristine.replace(
    '"source_refs": ["SRC-018"],',
    '"source_refs": ["SRC-018"],\n      "source\\u005Frefs": ["adversarial"],'
)
assert uni_dup != events_pristine, "substitution failed to match"
case("R003-07", "S7", 'OBSERVABLE_EVENT_REGISTER event dup via JSON \\u005F-escape alias of "source_refs" (decodes to identical string "source_refs")',
     EVENTS, uni_dup, "REJECT")

# 7.8 nested equivalent case: CASE_RECORD.historical_parent.exact\u005Fhead alias
case_pristine = (SCRATCH / CASE_RECORD).read_text(encoding="utf-8")
uni_dup_nested = case_pristine.replace(
    '"exact_head": "46fcd2c2580abd86ffbe215e6c387fee2bcb1b39",',
    '"exact_head": "46fcd2c2580abd86ffbe215e6c387fee2bcb1b39",\n    "exact\\u005Fhead": "FABRICATED0000000000000000000000000000",'
)
assert uni_dup_nested != case_pristine
case("R003-08", "S7", 'CASE_RECORD nested historical_parent dup via \\u005F-escape alias of "exact_head" (nested equivalent case)',
     CASE_RECORD, uni_dup_nested, "REJECT")

print("\n--- Section 7 complete ---\n")

# ============================================================
# SECTION 8 — R004 closed declared schemas
# ============================================================

d = load(CONTROL); d["authority_established"] = True
case("R004-01", "S8", "CONTROL_EFFECTS undeclared key 'authority_established' (authority-looking) injected",
     CONTROL, dumps(d), "REJECT")

d = load(LINEAGE); d["merge_authorized"] = True
case("R004-02", "S8", "HISTORICAL_LINEAGE undeclared top-level key 'merge_authorized' (merge-looking) injected",
     LINEAGE, dumps(d), "REJECT")

d = load(LEDGER)
for c in d["claims"]:
    if c["claim_id"] == "CAD-004-C005":
        c["proof_ready"] = True
case("R004-03", "S8", "CLAIM_LEDGER claim CAD-004-C005 undeclared key 'proof_ready' (proof-looking) injected",
     LEDGER, dumps(d), "REJECT")

d = load(FAMILIES)
d["families"][0]["endorsement_pending"] = True
case("R004-03b", "S8", "FAMILY_GROUNDING_REGISTER family[0] undeclared key 'endorsement_pending' (endorsement-looking) injected",
     FAMILIES, dumps(d), "REJECT")

d = load(LINEAGE); d["standing"]["readiness_authorized"] = True
case("R004-04", "S8", "HISTORICAL_LINEAGE nested standing{} undeclared key 'readiness_authorized' (readiness-looking) injected",
     LINEAGE, dumps(d), "REJECT")

d = load(CONTROL); d["record_id"] = "SOME_OTHER_INFORMATIONAL_LABEL"
case("R004-05", "S8", "CONTROL_EFFECTS record_id VALUE changed (informational field, not fixed/promoted by validator)",
     CONTROL, dumps(d), "ACCEPT",
     extra_note="Confirms record_id is schema-declared-but-value-unconstrained: informational, not one of the 13 governed effects.")

d = load(CONTROL); del d["record_id"]
case("R004-06", "S8", "CONTROL_EFFECTS record_id KEY removed entirely (tests closed-schema requires its presence)",
     CONTROL, dumps(d), "REJECT")

print("\n--- Section 8 complete ---\n")

# ============================================================
# SECTION 9 — R005 event source_refs syntactic validation
# ============================================================

def set_e001_source_refs(value):
    d = load(EVENTS)
    for e in d["events"]:
        if e["event_id"] == "CAD-004-E001":
            e["source_refs"] = value
    return dumps(d)

case("R005-01", "S9", "event source_refs = null", EVENTS, set_e001_source_refs(None), "REJECT")
case("R005-02", "S9", "event source_refs = [42] (integer member)", EVENTS, set_e001_source_refs([42]), "REJECT")
case("R005-03", "S9", 'event source_refs = [{"a":1}] (object member)', EVENTS, set_e001_source_refs([{"a": 1}]), "REJECT")
case("R005-04", "S9", 'event source_refs = [["nested"]] (nested array member)', EVENTS, set_e001_source_refs([["nested"]]), "REJECT")
case("R005-05", "S9", 'event source_refs = [""] (empty string member)', EVENTS, set_e001_source_refs([""]), "REJECT")
case("R005-06", "S9", 'event source_refs = ["   "] (ordinary whitespace-only string member)', EVENTS, set_e001_source_refs(["   "]), "REJECT")
case("R005-07", "S9", 'event source_refs = ["SRC-999"] (valid non-empty list) [POSITIVE CONTROL]', EVENTS, set_e001_source_refs(["SRC-999"]), "ACCEPT")

u200b_text = set_e001_source_refs(["\u200b"])
case("R005-08-FULL-PIPELINE", "S9", 'event source_refs = ["\\u200b"] (U+200B ZWSP) -- FULL v0.2.2 pipeline (includes file-level fingerprint freeze)',
     EVENTS, u200b_text, "REJECT",
     extra_note="Any byte-level change to the events file trips the separate v0.2.1 canonical-fingerprint freeze, independent of the R005 syntactic predicate itself. See R005-08-ISOLATED for the syntactic predicate tested alone.")

print("\n--- Section 9 (pipeline cases) complete ---\n")

isolated_script = r'''
import sys, json
import importlib.util
spec = importlib.util.spec_from_file_location("v022", "tools/check_fork_cad_candidate_v0_2_2.py")
v022 = importlib.util.module_from_spec(spec)
spec.loader.exec_module(v022)
cases = {
    "u200b_zero_width_space": ["\u200b"],
    "ordinary_whitespace_only": ["   "],
    "empty_string": [""],
    "valid_string": ["SRC-999"],
}
report = {}
for name, refs in cases.items():
    event = {"event_id": "ISOLATED-TEST", "source_refs": refs}
    try:
        v022.validate_event_source_refs(event)
        report[name] = "ACCEPTED_BY_PREDICATE"
    except v022.CandidateError as e:
        report[name] = f"REJECTED_BY_PREDICATE: {e}"
print(json.dumps(report, indent=2, ensure_ascii=False))
'''
proc = subprocess.run([sys.executable, "-c", isolated_script], cwd=SCRATCH, capture_output=True, text=True, timeout=30)
(RAW_DIR / "R005-08-ISOLATED.txt").write_text(
    f"Isolated unit-level test of validate_event_source_refs (the DECLARED R005 predicate), "
    f"decoupled from file-level fingerprint freeze and full pipeline.\n"
    f"exit_code={proc.returncode}\n--- stdout ---\n{proc.stdout}\n--- stderr ---\n{proc.stderr}\n",
    encoding="utf-8",
)
isolated_report = json.loads(proc.stdout) if proc.returncode == 0 and proc.stdout.strip().startswith("{") else None
print(f"[ISOLATED PREDICATE] R005-08-ISOLATED  exit={proc.returncode}")
if isolated_report:
    for k, v in isolated_report.items():
        print(f"    {k:28} -> {v}")
results.append({
    "id": "R005-08-ISOLATED", "section": "S9",
    "description": "Isolated call to validate_event_source_refs (declared R005 predicate) on U+200B / whitespace / empty / valid, decoupled from file-fingerprint freeze",
    "target_file": None, "checker": "validate_event_source_refs (direct function call)",
    "expected": "see per-case breakdown", "observed": json.dumps(isolated_report, ensure_ascii=False) if isolated_report else "SCRIPT_ERROR",
    "status": "INFO", "exit_code": proc.returncode, "stdout": proc.stdout.strip(), "stderr": proc.stderr.strip(),
    "note": "Isolates the DECLARED R005 invariant's own behavior from the separate, file-specific v0.2.1 fingerprint mechanism.",
    "noop_warning": "", "exhibit_file": None,
})

print("\n--- Section 9 complete ---\n")

# ============================================================
# SECTION 10 — Previous correction regression
# ============================================================

d = load(EVENTS)
for e in d["events"]:
    if e["event_id"] == "CAD-004-E001":
        e["authority_established"] = True
case("REG-R001", "S10", "R001 regression: undeclared event-level overclaim field 'authority_established' on CAD-004-E001",
     EVENTS, dumps(d), "REJECT")

d = load(EVENTS)
for e in d["events"]:
    if e["event_id"] == "CAD-004-E003":
        e["statement_origin"] = "GEMINI"
        e["causal_standing"] = "ESTABLISHED"
mutated_text = dumps(d)
case("REG-R002-v022", "S10", "R002 regression (v0.2.2, full candidate): MODEL_SELF_REPORT event CAD-004-E003, origin CLAUDE->GEMINI AND causal_standing UNRESOLVED->ESTABLISHED",
     EVENTS, mutated_text, "REJECT",
     extra_note="Tests whether the origin-agnostic v0.2.1/v0.2.2 rule catches promotion even when statement_origin is NOT 'CLAUDE'.")

case("REG-R002-v02-alone", "S10", "R002 regression (v0.2 checker ALONE, historical characterization only): same GEMINI+ESTABLISHED mutation run against the ORIGINAL v0.2 checker script in isolation",
     EVENTS, mutated_text, "ACCEPT", checker="v0_2",
     extra_note="v0.2's own causal-standing check is conditioned on statement_origin=='CLAUDE' specifically. This sub-test runs the historical v0.2 script directly -- NOT the v0.2.2 candidate under review -- for regression characterization only; it does not by itself alter the candidate's disposition.")

d = load(CASE_RECORD); d["admission_effect"] = "PARTIAL"
case("REG-OVERCLAIM-01", "S10", "Allowed-field overclaim substitution: CASE_RECORD.admission_effect 'NONE' -> 'PARTIAL'",
     CASE_RECORD, dumps(d), "REJECT")

d = load(EVENTS)
removed = d["non_claims"].pop()
case("REG-NONCLAIM-01", "S10", f"Historical-register non-claim modification: removed a non_claims entry from OBSERVABLE_EVENT_REGISTER",
     EVENTS, dumps(d), "REJECT",
     extra_note=f"Removed entry text: {removed!r}. Expected to be caught by the v0.2.1 whole-file canonical-fingerprint freeze.")

def mutate_claim(claim_id, key, value):
    d = load(LEDGER)
    for c in d["claims"]:
        if c["claim_id"] == claim_id:
            c[key] = value
    return dumps(d)

case("REG-C001", "S10", "C001 overclaim: dimensions.EARLIER_TURN_ACCESS 'UNRESOLVED' -> 'OBSERVED'",
     LEDGER, mutate_claim("CAD-004-C001", "dimensions", {
         "NOT_SUPPLIED": "CONTRADICTED", "VISIBLE_ATTACHMENT_PRESENCE": "OBSERVED",
         "EARLIER_TURN_ACCESS": "OBSERVED", "LATER_DIRECT_READ": "OBSERVED"}), "REJECT")
case("REG-C002", "S10", "C002 overclaim: verified_execution_receipt_present false -> true",
     LEDGER, mutate_claim("CAD-004-C002", "verified_execution_receipt_present", True), "REJECT")
case("REG-C003", "S10", "C003 overclaim: role_equivalence_established false -> true",
     LEDGER, mutate_claim("CAD-004-C003", "role_equivalence_established", True), "REJECT")
case("REG-C004", "S10", "C004 overclaim: scope_equivalence_established false -> true",
     LEDGER, mutate_claim("CAD-004-C004", "scope_equivalence_established", True), "REJECT")
case("REG-C005", "S10", "C005 overclaim (explicitly required): current_disposition narrowed-support -> 'GLOBALLY_SUPPORTED'",
     LEDGER, mutate_claim("CAD-004-C005", "current_disposition", "GLOBALLY_SUPPORTED"), "REJECT")
case("REG-C006", "S10", "C006 overclaim: behavioral_influence 'UNTESTED' -> 'CONFIRMED'",
     LEDGER, mutate_claim("CAD-004-C006", "behavioral_influence", "CONFIRMED"), "REJECT")
case("REG-C007", "S10", "C007 overclaim: completeness.evidentiary 'UNRESOLVED' -> 'ESTABLISHED'",
     LEDGER, mutate_claim("CAD-004-C007", "completeness", {
         "contextual": "UNRESOLVED", "chronological": "UNRESOLVED",
         "parse_state": "UNRESOLVED", "evidentiary": "ESTABLISHED"}), "REJECT")
case("REG-C008", "S10", "C008 overclaim (explicitly required): automatic_proof_promotion false -> true",
     LEDGER, mutate_claim("CAD-004-C008", "automatic_proof_promotion", True), "REJECT")

d = load(FAMILIES); d["families"][0]["source_refs"] = ["SRC-999-FABRICATED"]
case("REG-FAMILY-01", "S10", "Family-grounding fabrication: families[0].source_refs [] -> ['SRC-999-FABRICATED'] (must remain empty)",
     FAMILIES, dumps(d), "REJECT")
d = load(FAMILIES); d["families"][0]["grounding_status"] = "COMPLETE"
case("REG-FAMILY-02", "S10", "Family-grounding fabrication: families[0].grounding_status 'INCOMPLETE' -> 'COMPLETE'",
     FAMILIES, dumps(d), "REJECT")

d = load(ASSESSOR); d["independent_review_required"] = False
case("REG-ASSESSOR-01", "S10", "Assessor-correction promotion: independent_review_required true -> false",
     ASSESSOR, dumps(d), "REJECT")
d = load(ASSESSOR); d["source_addressable_original_statement_ref"] = "FABRICATED-SRC-999"
case("REG-ASSESSOR-02", "S10", "Assessor-correction promotion: fabricate source_addressable_original_statement_ref (null -> invented ref)",
     ASSESSOR, dumps(d), "REJECT")

THIRTEEN = [
    ("status", "ADMITTED"), ("pull_request_effect", "MERGED"), ("admission", True),
    ("publication", True), ("endorsement", True), ("provider_calls", 1),
    ("pair_001_effect", "EXECUTED"), ("pair_001_execution_authorized", True),
    ("readiness_effect", "PROMOTED"), ("readiness_promoted", True),
    ("proof_admission_effect", "ADMITTED"), ("model_standing_effect", "PROMOTED"),
    ("authority_effect", "GRANTED"),
]
assert len(THIRTEEN) == 13
for i, (key, badval) in enumerate(THIRTEEN, start=1):
    d = load(CONTROL); d[key] = badval
    case(f"REG-CE-{i:02d}-{key}", "S10", f"Governed control-effect field {i}/13: '{key}' overclaimed to {badval!r}",
         CONTROL, dumps(d), "REJECT")

print("\n--- Section 10 complete ---\n")

# ============================================================
# SECTION 11 — Representation characterization
# ============================================================

d = load(CONTROL)
compact = json.dumps(d, separators=(",", ":"), ensure_ascii=False) + "\n"
case("REP-WHITESPACE-01", "S11", "Benign whitespace variation: CONTROL_EFFECTS re-serialized compact (values unchanged)",
     CONTROL, compact, "ACCEPT")

d = load(CONTROL)
reordered = {k: d[k] for k in sorted(d.keys())}
case("REP-KEYORDER-01", "S11", "Object-key ordering: CONTROL_EFFECTS keys resorted alphabetically (values unchanged)",
     CONTROL, dumps(reordered), "ACCEPT")

d = load(EVENTS)
for i, e in enumerate(d["events"]):
    if e["event_id"] == "CAD-004-E001":
        d["events"][i] = {k: e[k] for k in sorted(e.keys())}
        break
case("REP-KEYORDER-02-fingerprinted", "S11", "Object-key ordering on FINGERPRINTED file: event CAD-004-E001 keys resorted alphabetically (values unchanged)",
     EVENTS, dumps(d), "ACCEPT",
     extra_note="Canonical fingerprint uses json.dumps(..., sort_keys=True) on the parsed object, so object-key order is normalized away and does not affect the fingerprint.")

d = load(EVENTS)
d["events"][0], d["events"][1] = d["events"][1], d["events"][0]
case("REP-ARRAYORDER-01-fingerprinted", "S11", "Array ordering on FINGERPRINTED file: top-level events[] order swapped (events[0]<->events[1], same content)",
     EVENTS, dumps(d), "REJECT",
     extra_note="sort_keys=True ordering ONLY affects JSON object keys; it does not reorder arrays, so array-element order is significant to the fingerprint.")

d = load(EVENTS)
for e in d["events"]:
    if e["event_id"] == "CAD-004-E004":
        e["source_refs"] = list(reversed(e["source_refs"]))
case("REP-ARRAYORDER-02-nested", "S11", "Array ordering within nested array: event CAD-004-E004 source_refs ['SRC-020','SRC-021'] reversed",
     EVENTS, dumps(d), "REJECT",
     extra_note="Confirms array-order-sensitivity of the fingerprint extends to nested arrays, not just the top-level events list.")

print("\n--- Section 11 complete ---\n")

# ============================================================
# SECTION 12 — Reviewer-originated adversarial challenge(s)
# NOT prescribed above, NOT U+200B, NOT the \u005F-alias case, NOT copied from shipped tests.
# ============================================================

# Challenge A: generalize the str.strip()-blindness class beyond the ONE prescribed codepoint (U+200B).
# Hypothesis: Python str.strip() only removes characters carrying the Unicode "White_Space" property;
# U+200B lacks that property, which is *why* it survives .strip(). If that is the actual mechanism,
# other codepoints that ALSO lack White_Space but are visually blank should exhibit the same class
# of behavior. Tested here: U+FEFF (ZERO WIDTH NO-BREAK SPACE / BOM) and U+2060 (WORD JOINER) --
# both distinct from U+200B, testing a broader pattern rather than the single prescribed instance.

d = load(EVENTS)
for e in d["events"]:
    if e["event_id"] == "CAD-004-E001":
        e["source_refs"] = ["\ufeff"]
case("CHALLENGE-A1-FEFF", "S12", "Reviewer challenge A1: generalize str.strip()-blindness beyond U+200B to U+FEFF (ZWNBSP/BOM) -- FULL v0.2.2 pipeline",
     EVENTS, dumps(d), "REJECT",
     extra_note="Full-pipeline result is confounded by the unrelated file-level fingerprint freeze; see ISOLATED sub-test for the declared-predicate-only result.")

d = load(EVENTS)
for e in d["events"]:
    if e["event_id"] == "CAD-004-E001":
        e["source_refs"] = ["\u2060"]
case("CHALLENGE-A2-WORDJOINER", "S12", "Reviewer challenge A2: same hypothesis with U+2060 (WORD JOINER) -- FULL v0.2.2 pipeline",
     EVENTS, dumps(d), "REJECT",
     extra_note="Second distinct codepoint testing the same generalized hypothesis; also confounded by the file-level fingerprint freeze in the full pipeline.")

isolated_script_b = r'''
import sys, json
import importlib.util
spec = importlib.util.spec_from_file_location("v022", "tools/check_fork_cad_candidate_v0_2_2.py")
v022 = importlib.util.module_from_spec(spec)
spec.loader.exec_module(v022)
cases = {
    "u_feff_zwnbsp_bom": ["\ufeff"],
    "u_2060_word_joiner": ["\u2060"],
    "u_200c_zwnj": ["\u200c"],
    "u_00a0_nbsp_negative_control": ["\u00a0"],
}
report = {}
for name, refs in cases.items():
    event = {"event_id": "ISOLATED-TEST", "source_refs": refs}
    try:
        v022.validate_event_source_refs(event)
        report[name] = "ACCEPTED_BY_PREDICATE"
    except v022.CandidateError as e:
        report[name] = f"REJECTED_BY_PREDICATE: {e}"
print(json.dumps(report, indent=2, ensure_ascii=False))
'''
proc = subprocess.run([sys.executable, "-c", isolated_script_b], cwd=SCRATCH, capture_output=True, text=True, timeout=30)
(RAW_DIR / "CHALLENGE-A-ISOLATED.txt").write_text(
    f"Isolated unit-level test of validate_event_source_refs for Challenge A generalization.\n"
    f"exit_code={proc.returncode}\n--- stdout ---\n{proc.stdout}\n--- stderr ---\n{proc.stderr}\n",
    encoding="utf-8",
)
challA_report = json.loads(proc.stdout) if proc.returncode == 0 and proc.stdout.strip().startswith("{") else None
print(f"[ISOLATED PREDICATE] CHALLENGE-A-ISOLATED  exit={proc.returncode}")
if challA_report:
    for k, v in challA_report.items():
        print(f"    {k:32} -> {v}")
results.append({
    "id": "CHALLENGE-A-ISOLATED", "section": "S12",
    "description": "Isolated declared-predicate test of Challenge A hypothesis across 4 codepoints (U+FEFF, U+2060, U+200C, and U+00A0 as negative control)",
    "target_file": None, "checker": "validate_event_source_refs (direct function call)",
    "expected": "see per-case breakdown (U+00A0 is a negative control: Python DOES treat it as whitespace)",
    "observed": json.dumps(challA_report, ensure_ascii=False) if challA_report else "SCRIPT_ERROR",
    "status": "INFO", "exit_code": proc.returncode, "stdout": proc.stdout.strip(), "stderr": proc.stderr.strip(),
    "note": "U+00A0 (NBSP) IS in Python's White_Space set, included as negative control expected to be REJECTED_BY_PREDICATE.",
    "noop_warning": "", "exhibit_file": None,
})

# Challenge B: Python bool/int equality confusion on an integer/boolean-typed governed field.
# Hypothesis: require_equal uses `record.get(key) != value`. Python's bool is an int subclass,
# so `False == 0` and `True == 1`. If a JSON value is supplied with the WRONG JSON type but the
# Python-equal value (e.g. JSON boolean `false` where an integer `0` is declared, or JSON integer
# `0` where a boolean `false` is declared), the equality-based check may not distinguish them.
# This is a structurally different attack surface than R003/R004/R005 (value-equality type
# confusion, not duplicate-key / closed-schema / string-content).

d = load(CONTROL)
d["provider_calls"] = False   # JSON boolean false in place of declared integer 0
case("CHALLENGE-B1-BOOL-FOR-INT", "S12",
     "Reviewer challenge B1: CONTROL_EFFECTS.provider_calls set to JSON boolean `false` (not integer 0) -- tests Python bool/int equality (False==0) at the require_equal layer",
     CONTROL, dumps(d), "REJECT",
     extra_note="If ACCEPTED: demonstrates require_equal's `!=` comparison does not distinguish JSON boolean false from JSON integer 0, since Python's bool is an int subclass. Preserved exactly regardless of outcome.")

d = load(CONTROL)
d["admission"] = 0   # JSON integer 0 in place of declared boolean false
case("CHALLENGE-B2-INT-FOR-BOOL", "S12",
     "Reviewer challenge B2 (reverse direction): CONTROL_EFFECTS.admission set to JSON integer 0 (not boolean false) -- same Python equality hypothesis, opposite type direction",
     CONTROL, dumps(d), "REJECT",
     extra_note="If ACCEPTED: confirms the type-confusion class is bidirectional (int-for-bool as well as bool-for-int).")

print("\n--- Section 12 complete ---\n")

# ============================================================
# FINAL: aggregate results
# ============================================================
Path("/home/claude/proof005_work/raw_outputs/results.json").write_text(
    json.dumps(results, indent=2, ensure_ascii=False), encoding="utf-8"
)

total = len(results)
pipeline_cases = [r for r in results if r["status"] in ("MATCH", "**MISMATCH**")]
matches = [r for r in pipeline_cases if r["status"] == "MATCH"]
mismatches = [r for r in pipeline_cases if r["status"] == "**MISMATCH**"]
unexpected_accepts = [r for r in mismatches if r["observed"] == "ACCEPT" and r["expected"] == "REJECT"]
unexpected_rejects = [r for r in mismatches if r["observed"] == "REJECT" and r["expected"] == "ACCEPT"]
info_only = [r for r in results if r["status"] == "INFO"]
noop_flagged = [r for r in results if r.get("noop_warning")]

from collections import Counter
sect_counts = Counter(r["section"] for r in results)

lines = []
lines.append(f"TOTAL RESULT RECORDS: {total}")
lines.append(f"Pipeline pass/fail cases executed: {len(pipeline_cases)}  (MATCH={len(matches)}, MISMATCH={len(mismatches)})")
lines.append(f"Informational isolated-predicate records: {len(info_only)}")
lines.append(f"No-op mutation warnings (should be 0): {len(noop_flagged)}")
lines.append("")
lines.append(f"Unexpectedly ACCEPTED (expected REJECT, observed ACCEPT): {len(unexpected_accepts)}")
for m in unexpected_accepts:
    lines.append(f"  -> {m['id']}: {m['description']}")
lines.append(f"Unexpectedly REJECTED (expected ACCEPT, observed REJECT): {len(unexpected_rejects)}")
for m in unexpected_rejects:
    lines.append(f"  -> {m['id']}: {m['description']}")
lines.append("")
lines.append("=== BY SECTION ===")
for s in sorted(sect_counts):
    lines.append(f"  {s}: {sect_counts[s]} records")
if noop_flagged:
    lines.append("")
    lines.append("=== NO-OP WARNINGS (test setup defect - investigate) ===")
    for r in noop_flagged:
        lines.append(f"  {r['id']}: {r['noop_warning']}")

summary_text = "\n".join(lines)
Path("/home/claude/proof005_work/raw_outputs/results_summary.txt").write_text(summary_text, encoding="utf-8")
print("\n" + "="*70)
print(summary_text)
print("="*70)
