# PROOF-005 CAD v0.2.2 — Independent Exterior Recomputation
## Evidence Return (Section 13 format)

**Exact reviewed SHA:** `9e3cdd2fb6d67f9abd6233ce673341bd817d6338` (`refs/heads/exterior-review/proof005-v0.2.2-candidate`)
**Repository identity:** `RecomputableEvidence/fork-public-evidence`, PR #128
**Review mode:** `EXECUTABLE_EXACT_HEAD_EXTERIOR_RECOMPUTATION`

---

## Section-by-section execution status

| # | Section | Status |
|---|---|---|
| 1 | Exact review coordinates | EXECUTED_AND_RECORDED |
| 2 | Offline package integrity | EXECUTED_AND_RECORDED (see Finding F-1) |
| 3 | Reviewer standing | EXECUTED_AND_RECORDED (`06_environment/`) |
| 4 | Exact detached checkout | EXECUTED_AND_RECORDED (`03_detached_checkout/`) |
| 5 | Historical preservation | EXECUTED_AND_RECORDED (`04_historical_preservation/`) |
| 6 | Baseline exact-head recomputation | EXECUTED_AND_RECORDED (`05_baseline_recomputation/`) |
| 7 | R003 duplicate-key parity | EXECUTED_AND_RECORDED (8/8 cases, `mutations/R003-*`) |
| 8 | R004 closed declared schemas | EXECUTED_AND_RECORDED (7/7 cases, `mutations/R004-*`) |
| 9 | R005 source_refs syntax + U+200B | EXECUTED_AND_RECORDED (9 pipeline + 1 isolated, `mutations/R005-*`) |
| 10 | Previous correction regression | EXECUTED_AND_RECORDED (30 cases: R001, R002 x2, overclaim, non-claim, C001-C008, family x2, assessor x2, 13 control effects) |
| 11 | Representation characterization | EXECUTED_AND_RECORDED (5 cases, `mutations/REP-*`) |
| 12 | Reviewer-originated challenge | EXECUTED_AND_RECORDED (2 distinct challenges, A and B, `mutations/CHALLENGE-*`) |

Nothing in this review was left `NOT_EXECUTED`.

---

## Finding F-1 — Archive/transport-wrapper identity discrepancy (Section 2)

The file actually supplied (`PROOF005_CAD_v0_2_2_EXECUTABLE_EXTERIOR_HANDOFF.zip`, reviewer-computed
SHA-256 `8e6bee262add1a2a3cc03bfc646a5660452cfd77dc043eb5fb93920df60c6d72`, 3,595,861 bytes) is **not**
byte-identical to the archive named in Section 2 (`PROOF005-CAD-v0.2.2-offline-review-package-final.zip`,
expected SHA-256 `542ebc19f18ca0f676030ba3125e7c2fb6905518c929f3bb26dfaa55690393b1`, 3,590,674 bytes).

`HANDOFF_MANIFEST.txt`, itself inside the received zip, discloses and explains this: it labels the
Section-2-matching hash `source_actions_artifact_zip_sha256` (a distinct, named upstream artifact), and
separately declares `git_bundle_sha256`/`git_bundle_size_bytes` and `review_note_sha256`/`review_note_size_bytes`.
The reviewer independently recomputed both of those and both match exactly (see `01_package_and_bundle_integrity/`).

**Disposition of this finding:** treated as a disclosed transport-repackaging difference, not a candidate
substitution — the actual object database used for detached checkout and all mechanical recomputation (the
git bundle) is independently hash-confirmed against the value stated in Section 2 itself, and the review-note
text is confirmed identical to the manifest's declared hash. This is a reviewer judgment call, stated plainly
as a qualification below rather than as a silent pass or an unqualified `REVIEW_INCONCLUSIVE` halt.

---

## Sections 1-6 recap (executed in the originating portion of this same session; re-verified this turn)

- Bundle SHA-256 and size match Section 2 exactly; `git bundle verify` / `list-heads` (reviewer-executed)
  confirm all 4 expected refs and a complete (non-incremental) history.
- `git checkout --detach 9e3cdd2fb6d67f9abd6233ce673341bd817d6338` succeeded; `HEAD` matches exactly;
  worktree clean; both predecessor SHAs confirmed ancestors (exit 0/0); governed preservation tip confirmed
  to exist as a commit object (not required, and not, an ancestor).
- Historical preservation: all 14 files spanning the v0.2 governed artifacts + checker/test and the v0.2.1
  successor artifacts + checker/test are byte-identical to their predecessor commits, confirmed via three
  independent mechanisms (`git diff --name-status`, git blob SHA-1 identity, independent SHA-256 byte hash).
  No rewriting of reviewed predecessor surfaces.
- All six baseline commands (3 checkers + 3 pytest suites) executed with exit code 0: v0.2 (23 tests),
  v0.2.1 (14 tests + 13 subtests), v0.2.2 (17 tests + 30 subtests).

---

## Sections 7-12 — adversarial battery (executed this turn)

**64 result records** (62 real pipeline pass/fail executions against the actual checker scripts via
subprocess + 2 informational isolated-predicate records). **59/62 MATCH** their expected outcome.
Full detail: `07_mutation_harness/results.json`, `results_summary.txt`, `mutations/*.txt`, `exhibits/*`.

### R003 — duplicate-key parsing parity (8/8 REJECT as expected)
Both orderings (compliant-then-noncompliant and the reverse, "last-value-wins" would otherwise mask
duplication) tested on: `CONTROL_EFFECTS_v0_2.json` top level, `HISTORICAL_LINEAGE_v0_2.json` top level,
and `HISTORICAL_LINEAGE_v0_2.json`'s nested `standing` object. The prescribed `\u005F`-escape alias of
`source_refs`/`exact_head` was independently reproduced at both an event-object level and a nested
`historical_parent` level — both correctly rejected with `FAIL: json: duplicate object key ... is not
permitted`, confirming JSON string-escape decoding happens before duplicate-key detection.

### R004 — closed declared schemas (6/6 as expected)
Undeclared authority/merge/proof/endorsement/readiness-looking keys rejected across control effects,
lineage (top-level and nested `standing`), a claim record, and a family record. `record_id` confirmed
schema-declared-but-value-unconstrained (its value may change without failing validation — informational,
not one of the 13 governed effects), while its *removal* is correctly rejected (proving it is a required
member of the closed key set, just not a fixed-value one).

### R005 — event `source_refs` syntactic validation, including U+200B (9 pipeline cases + isolated predicate)
`null`, integer, object, nested-array, empty-string, and whitespace-only members: all correctly REJECTED.
A normal valid string was correctly REJECTED at the **full-pipeline** level (`R005-07`) — this is a reviewer
test-design artifact, not a checker defect: the events file carries an independent, file-specific canonical-JSON
fingerprint freeze (from v0.2.1) that blocks *any* modification to that file, valid or not. The isolated
predicate test (`R005-08-ISOLATED`, calling `validate_event_source_refs` directly) confirms the declared
R005 invariant itself correctly accepts `"SRC-999"` and correctly rejects whitespace-only/empty strings.

**U+200B (prescribed known edge), independently reproduced:** the declared predicate **accepts** it
(`ACCEPTED_BY_PREDICATE`), because Python's `str.strip()` does not remove U+200B (it lacks Unicode's
`White_Space` property). Classified per the four-part framework requested:
1. Mechanically **accepted** at the syntactic-predicate layer (isolated test); at the full-pipeline
   level any change to this specific file is separately caught by the unrelated fingerprint freeze.
2. Yes — representational ambiguity; the value is human-invisible/blank-looking.
3. **No** reachable authority/admission/proof/readiness/execution/model-standing effect: all governed
   effects are validated independently, by fixed-value checks in an entirely separate file
   (`CONTROL_EFFECTS_v0_2.json`), with no dependency on `source_refs` content.
4. This identifies a **stronger optional hardening invariant not declared by v0.2.2**, not an internal
   contradiction of the declared invariant — "non-empty after Python `str.strip()`" is implemented exactly
   as written; its scope is narrower than a full Unicode-aware blank-detector.

### Section 10 — previous correction regression (30/30 as expected)
- **R001** (undeclared event-level overclaim field): REJECTED.
- **R002** (model-self-report causal-standing promotion regardless of model origin): the full v0.2.2
  candidate correctly REJECTS a `GEMINI`-origin `MODEL_SELF_REPORT` event with `causal_standing` promoted
  to `ESTABLISHED`. A parallel sub-test run against the **historical v0.2 checker alone** (not the
  candidate; included for regression characterization only) **accepts** the identical mutation — precisely
  reproducing, at the exact head, why the origin-agnostic v0.2.1/v0.2.2 correction was necessary, and
  confirming it is genuinely present and effective in the reviewed candidate.
- Allowed-field overclaim (`CASE_RECORD.admission_effect` NONE→PARTIAL): REJECTED.
- Historical-register non-claim modification (deleted a `non_claims` entry): REJECTED via the fingerprint freeze.
- **C001–C008, individually, explicitly including C005 and C008:** all 8 REJECTED for their respective overclaim mutations.
- Family-grounding fabrication (fabricated `source_refs`; promoted `grounding_status`): both REJECTED.
- Assessor-correction promotion (waived `independent_review_required`; fabricated a source-addressable ref): both REJECTED.
- **All 13 governed control-effect fields, individually**, overclaimed to an escalated same-typed value
  (e.g. `admission: true`, `provider_calls: 1`, `authority_effect: "GRANTED"`): **all 13 REJECTED**.

### Section 11 — representation characterization (5/5 as expected)
Benign whitespace re-serialization: ACCEPTED. Object-key reordering: ACCEPTED, both on a plain governed
file and on one event object inside the file that additionally carries a whole-file canonical fingerprint —
confirming the fingerprint's `sort_keys=True` canonicalization normalizes object-key order away. Array
reordering (top-level `events` list, and a nested multi-element `source_refs` list): both correctly
REJECTED — `sort_keys=True` does not reorder JSON arrays, so array-element order is fingerprint-significant.
This is structural/fingerprint behavior, not semantic or natural-language interpretation.

### Section 12 — reviewer-originated adversarial challenges (2 distinct, both executed)

**Challenge A — generalizing the U+200B class.** Hypothesis: U+200B survives `.strip()` specifically
because it lacks Unicode's `White_Space` property; the same should hold for *other* codepoints lacking
that property. Tested U+FEFF (ZWNBSP/BOM), U+2060 (WORD JOINER), U+200C (ZWNJ), with U+00A0 (NBSP, which
Python *does* treat as whitespace) as a negative control. **Result: confirmed** — all three additional
codepoints are `ACCEPTED_BY_PREDICATE`; the negative control is correctly rejected. This generalizes the
already-known R005 representational-ambiguity class beyond the single prescribed instance; the same
reachability analysis applies (no governed-effect path).

**Challenge B — Python bool/int equality confusion (genuinely new finding).** Hypothesis: the closed-schema
value checks use `record.get(key) != expected_value`; Python's `bool` is an `int` subclass (`False == 0`,
`True == 1`), so a wrong-JSON-type-but-Python-equal substitution might slip past a `!=`-based check.
Tested both directions on `CONTROL_EFFECTS_v0_2.json`: `provider_calls` set to JSON boolean `false` in
place of declared integer `0` (**B1**), and `admission` set to JSON integer `0` in place of declared
boolean `false` (**B2**). **Result: both unexpectedly ACCEPTED** (checker exit code 0, `PASS`) — this was
not previously known or prescribed. See "Unexpectedly accepted mutations" below for the required
representational-effect / reachability / correction-warranted analysis.

---

## Unexpectedly accepted mutations — required analysis (Section 12/14 requirement)

Two cases were unexpectedly accepted: `CHALLENGE-B1-BOOL-FOR-INT` and `CHALLENGE-B2-INT-FOR-BOOL`
(exact mutated exhibits preserved at `07_mutation_harness/exhibits/CHALLENGE-B1-BOOL-FOR-INT.json` and
`CHALLENGE-B2-INT-FOR-BOOL.json`; raw checker stdout/stderr at the corresponding files under `mutations/`).

- **Representational effect:** the JSON value's literal type (`boolean` vs `integer`) diverges from what
  the field's own governed semantics would suggest, though the file remains syntactically valid, well-formed
  JSON. There is no human-visible ambiguity of the kind U+200B presents — a reader would clearly see `false`
  or `0` in the file; the gap is purely at the type-precision level of the automated check.
- **Governed standing/effect reachability:** traced directly. The bug is confined to **zero/false-equivalence**
  substitutions only. It does **not** provide a path to an actually-escalated value: `admission: 1`,
  `admission: true`, `provider_calls: <nonzero>`, and all analogous escalations on the other 11 control-effect
  fields were independently tested (Section 10's 13-field battery, using genuinely escalated same-typed values)
  and are all correctly rejected by the same mechanism. No authority, admission, publication, endorsement,
  pair-001, readiness, proof-admission, model-standing, or execution effect is reachable through this
  type-confusion; it only ever lets a still-"off"/still-zero value through in the wrong JSON type.
- **Correction warranted before merge:** **not required** for the bounded scope of this candidate, given the
  above reachability finding — the invariant that actually matters for governance (no field can be flipped to
  an escalated value) holds. This is recorded as a genuine, novel, precisely-bounded type-strictness hardening
  opportunity, not a correction-required defect. (Reviewer judgment call, stated plainly for downstream
  governance disposition to weigh independently.)

---

## Narrowest disposition

**`EXTERIOR_RECOMPUTATION_CONFORMING_WITH_QUALIFICATIONS`**

Rationale: package/bundle integrity, exact-head detached checkout, historical preservation, and all six
baseline commands executed cleanly with no deviation from the declared candidate. The full prescribed
adversarial battery (R003, R004, R005, R001/R002 regression, C001–C008 including C005/C008, all 13 governed
control-effect fields, family-grounding fabrication, assessor-correction promotion, representation
characterization) found **no** case where a genuinely escalated value or a masked duplicate/undeclared field
was accepted. Three qualifications are disclosed and do not, on the executed evidence, warrant a stronger
disposition: (F-1) the outer transport-wrapper archive does not match Section 2's named archive by hash,
though the operative object database does; (F-2) the U+200B representational-ambiguity class is confirmed to
extend beyond the single prescribed codepoint to at least three others; (F-3) a novel, precisely-bounded
JSON bool/int type-confusion accepts non-escalating zero/false-equivalent substitutions on `require_equal`
checks. None of these reach any authority, admission, publication, endorsement, pair-001, readiness,
proof-admission, model-standing, or execution effect.

This review record does not merge PR #128, admit PROOF-005, admit proof packaging, complete source
grounding, promote Fork Candidate Model standing, establish global empirical or independent validation,
authorize provider calls or Pair-001, authorize pilot or production deployment, establish compliance or
legal sufficiency, constitute endorsement, transfer authority, or create authority inheritance, per Section 15.
