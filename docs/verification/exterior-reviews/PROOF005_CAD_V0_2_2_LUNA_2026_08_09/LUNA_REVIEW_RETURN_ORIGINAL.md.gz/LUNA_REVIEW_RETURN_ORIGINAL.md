My other ChatGPT account:

I performed the exterior recomputation to the extent the available execution environment permits. The result is **not a conformity determination**, because the environment prevented a clean network clone and therefore prevented execution of the exact frozen checkout's checker/test commands. I did, however, independently verify the exact Git object coordinates, ancestry, preservation boundary, checker source, governed artifacts, CI context, and several adversarial parser behaviors.

## PROOF-005 — Exterior Recomputation v0.2.2

### 1. Reviewer standing

| ItemFinding                                         |                                                                                                               |
| --------------------------------------------------- | ------------------------------------------------------------------------------------------------------------- |
| Reviewer/model                                      | **GPT-5.6 Luna**                                                                                              |
| Execution session                                   | Fresh execution session for this review                                                                       |
| Prior Fork familiarity                              | **Yes** — prior Fork material exists in the conversation context, so this is not a blind first-contact review |
| Prior findings supplied?                            | **Yes** — this request explicitly supplies R003/R004/R005 and the earlier Gemini theoretical challenge        |
| Involvement constructing v0.2.2                     | **None**                                                                                                      |
| Prior access to exact candidate before this request | No evidence of prior access; exact candidate was accessed through GitHub during this review                   |
| Independence characterization                       | **Independent recomputation attempt with prior contextual familiarity; not a fully blind review**             |

I did not treat the PR's stated claims as results.

---

# 2. Exact candidate identity and ancestry

GitHub independently identifies PR #128's head as:

`9e3cdd2fb6d67f9abd6233ce673341bd817d6338`

and the PR's merge-base/base as:

`de3a5165d7828a47d31b5b25a260bfef53094f14`.

The GitHub commit comparison independently establishes:

- `a8b528be8acaa5b69bc928450001a56b4b8335e3` → candidate: **ahead by 4 commits**
- `de3a5165d7828a47d31b5b25a260bfef53094f14` → candidate: **ahead by 8 commits**
- both comparisons have the specified base as their merge base.

Thus the supplied v0.2.1 predecessor and governed basis are both in the candidate ancestry.

### Required local commands

The requested literal detached-checkout commands were **not executable locally**.

Attempted:

```
git clone --no-tags https://github.com/RecomputableEvidence/fork-public-evidence.git

```

Raw result:

```
Cloning into 'repo'...
fatal: unable to access 'https://github.com/RecomputableEvidence/fork-public-evidence.git/':
Could not resolve host: github.com

```

Therefore:

- `git rev-parse HEAD`: **NOT\_EXECUTED\_DUE\_TO\_SESSION\_LIMIT**
- `git status --short`: **NOT\_EXECUTED\_DUE\_TO\_SESSION\_LIMIT**
- `git log -1 ...`: **NOT\_EXECUTED\_DUE\_TO\_SESSION\_LIMIT**
- local `merge-base --is-ancestor`: **NOT\_EXECUTED\_DUE\_TO\_SESSION\_LIMIT**

I am deliberately not substituting the GitHub connector's metadata for the requested raw local Git output.

---

# 3. Historical preservation

This portion **was independently established through Git object/compare mechanisms**.

The comparison:

`a8b528be8acaa5b69bc928450001a56b4b8335e3 → 9e3cdd2fb6d67f9abd6233ce673341bd817d6338`

reports exactly **seven added files and zero modified/deleted predecessor files**. The additions are the v0.2.2 binding/README, the exterior-return records, and the v0.2.2 checker/test.

That is strong evidence that the reviewed v0.2/v0.2.1 surfaces were **not rewritten in the candidate**.

I additionally checked blob identity for representative predecessor surfaces:

- `CONTROL_EFFECTS_v0_2.json`
  - predecessor blob: `1afa86b8c7db183c3541829cc48f0e7b480249ee`
  - candidate blob: `1afa86b8c7db183c3541829cc48f0e7b480249ee`
- `CORRECTION_SUCCESSOR_BINDING_v0_2_1.json`
  - predecessor blob: `2814ebffb66cb47da4e63c9de40cc0d3d9c264f2`
  - candidate blob: `2814ebffb66cb47da4e63c9de40cc0d3d9c264f2`

So the representative byte/object identities are unchanged as well.

**Preservation finding: EXECUTED\_AND\_RECORDED — conforming.**

---

# 4. Candidate implementation inspection

The exact candidate checker blob is:

`27531fc1919dd9b7e809ad140b2280542815e9f7`

and the candidate declares SHA-256:

`ab5fcdc144812307c0cd28862a2c613ce55775fd83027d192d6f696e4617d0bf`.

The checker does, structurally:

1. strict-load all seven governed JSON artifacts;
2. reject duplicate keys using `object_pairs_hook`;
3. apply closed-key schemas;
4. apply `source_refs` validation;
5. invoke v0.2 semantic validation;
6. invoke v0.2.1 event-register fingerprint/origin-independent validation.

That architecture is materially aligned with the three declared residuals.

---

# 5. R003 — duplicate-key handling

### Source inspection

The v0.2.1 loader used by v0.2.2 is:

```
json.loads(
    text,
    object_pairs_hook=reject_duplicate_object_keys
)

```

and the hook rejects a key if it already exists in the object being constructed. v0.2.2 explicitly routes all seven governed artifact classes through that loader **before semantic validation**.

The seven governed classes are explicitly enumerated:

- lineage
- case
- ledger
- events
- effects
- families
- assessor

### Independent parser challenge

I mechanically reproduced the exact loader logic and tested:

```
{
  "source_refs": ["valid"],
  "source\u005Frefs": ["adversarial"]
}

```

Result:

```
REJECT "json: duplicate object key 'source_refs' is not permitted"

```

I also tested a duplicate nested inside an array:

```
{
  "nested": [
    {
      "admission": true,
      "ad\u006dission": false
    }
  ]
}

```

Result:

```
REJECT "json: duplicate object key 'admission' is not permitted"

```

This is important because `object_pairs_hook` receives the decoded key strings, so the Unicode escape does not evade the comparison.

### Gemini theoretical challenge

The preserved hypothesis was:

`THEORETICAL_CONSTRUCT_RECORDED_UNEXECUTED`

It is now **mechanically reproduced** against the candidate's stated parser semantics.

**Result: rejected.**

So the Unicode-escape alias hypothesis is **not reproduced as a defect**.

**R003 status: mechanically supported, but exact candidate checker execution remains outstanding.**

---

# 6. R004 — closed schemas

The v0.2.2 checker explicitly applies `require_exact_keys()` across:

- historical lineage;
- nested lineage construction base/surfaces/standing;
- case record and historical parent;
- claim ledger;
- C001–C008 claim records;
- C001 dimensions;
- C007 completeness;
- event register and event objects;
- control effects;
- family register, parent, family objects, unresolved-artifact object;
- assessor correction event and historical parent.

The function rejects:

```
extras = keys - expected

```

with:

```
undeclared fields are not permitted

```

This is a genuine closed-schema mechanism rather than merely a semantic scan.

The shipped v0.2.2 tests independently enumerate pressure against:

- top-level control-effect fields;
- nested family fields;
- authority-looking lineage fields;
- R001 out-of-band event fields;
- allowed-field substitutions;
- C005/C008;
- all thirteen governed control-effect values.

### Important distinction

`record_id` is explicitly included in `CONTROL_EFFECT_KEYS`, but the v0.2 semantic checker excludes it from the thirteen governed effects. Thus schema membership does **not** automatically create a governance effect.

**R004 status: source-level mechanism supports conformity; exact candidate mutation execution remains outstanding.**

---

# 7. R005 — `source_refs`

The exact candidate implementation requires:

```
source_refs
    → list
    → non-empty
    → every member is str
    → every member satisfies bool(ref.strip())

```

This is explicitly syntactic and does not establish source existence, provenance, chronology, or evidentiary sufficiency.

The shipped tests cover exactly:

- `null`
- integer
- object
- array
- empty string
- ordinary whitespace-only string

and a valid list of strings.

### Reviewer-originated adversarial challenge

I selected an additional case not present in the supplied request or shipped test:

```
{
  "event_id": "REVIEWER-NEW-001",
  "source_refs": ["\u200b"]
}

```

where the member is a **ZERO WIDTH SPACE** (`U+200B`).

Using the exact candidate function semantics:

```
CASE reviewer-originated zero-width-space source_ref
ACCEPT '\u200b' strip= '\u200b'

```

Evidence script SHA-256:

`b5333a8384241fc37e4990967c19ad1b7311359bd01ee60a677951da7898a6e8`

### Interpretation

1. **Genuinely accepted?**
   Yes, by the candidate's exact `isinstance(ref, str) and bool(ref.strip())` rule.
2. **Representational ambiguity?**
   Yes. U+200B is visually invisible/blank-like, while Python's `str.strip()` does not classify it as whitespace.
3. **Does it reach governed standing/effect?**
   No demonstrated standing/effect transition. `source_refs` validation is explicitly syntactic. A mutation of the fixed historical register would additionally encounter the v0.2.1 canonical fingerprint.
4. **Does it warrant correction?**
   **Not necessarily within the declared R005 scope.** The implemented contract is "non-empty string after Python whitespace stripping," not "visibly nonblank Unicode reference." It is nevertheless a legitimate hardening candidate if the intended invariant is human-visible/non-invisible reference content.

This is therefore an **accepted reviewer-originated representational edge**, not a reproduced authority/admission defect.

---

# 8. Previous correction regression

The exact v0.2.2 test surface explicitly contains regression pressure for:

- R001;
- R002;
- allowed-field substitution;
- C005;
- C008;
- all thirteen governed control-effect values;
- family grounding;
- assessor correction.

Static inspection of the candidate implementation confirms:

- model self-report requires `mechanism_verified == False`;
- model self-report requires `causal_standing == UNRESOLVED`;
- those checks are independent of `statement_origin`;
- event objects have an exact allowed-key set;
- v0.2 semantic controls remain invoked after the new schema checks.

However, the requested **fresh execution of the exact regression suite was not possible**.

Therefore:

**R001/R002/C001–C008/regression execution:** **`NOT_EXECUTED_DUE_TO_SESSION_LIMIT`****\*\*\*\*.**

No shipped-test result is being represented as an independent execution result.

---

# 9. Representation behavior

### Structural findings

From the exact implementation:

- ordinary whitespace changes are normalized by parsing;
- object-key ordering is normalized by the v0.2.1 canonical fingerprint;
- array ordering is **not** normalized by canonicalization;
- duplicate keys are rejected before canonicalization;
- undeclared keys are rejected by exact schema closure.

The v0.2.1 canonicalization is:

```
json.dumps(
    value,
    sort_keys=True,
    separators=(",", ":"),
    ensure_ascii=False,
    allow_nan=False
)

```

Thus this is explicitly **structural representation control**, not natural-language semantic interpretation.

---

# 10. Exact checker/test execution status

This is the decisive limitation.

The requested commands:

```
python tools/check_fork_cad_candidate_v0_2.py
python tools/check_fork_cad_candidate_v0_2_1.py
python tools/check_fork_cad_candidate_v0_2_2.py

python -m pytest -q tests/test_fork_cad_candidate_v0_2.py
python -m pytest -q tests/test_fork_cad_candidate_v0_2_1.py
python -m pytest -q tests/test_fork_cad_candidate_v0_2_2.py

```

are:

**`NOT_EXECUTED_DUE_TO_SESSION_LIMIT`**

The practical cause was not elapsed time; it was the execution environment's inability to resolve `github.com`, preventing acquisition of a clean exact-head repository.

I therefore refuse to label the candidate "executed and passing."

---

# 11. CI evidence — explicitly not substituted

There are successful GitHub Actions runs associated with PR #128's candidate activity. However, the available PR workflow log shows the Actions checkout at:

`3f9be59759b4339dd5cf72885774dbdfdfb4a5d8`

—the **PR merge ref**, not the frozen candidate:

`9e3cdd2fb6d67f9abd6233ce673341bd817d6338`.

The log explicitly says:

```
HEAD is now at 3f9be59 Merge 9e3cdd2... into de3a516...

```

Therefore I do **not** use that CI result as an exact-head execution result. This distinction is material and consistent with your instruction not to substitute another coordinate.

---

# 12. Evidence matrix

| Requested itemStatus                |                                                |
| ----------------------------------- | ---------------------------------------------- |
| Exact candidate identity            | **EXECUTED\_AND\_RECORDED**                    |
| PR #128 head verification           | **EXECUTED\_AND\_RECORDED**                    |
| v0.2.1 ancestry                     | **EXECUTED\_AND\_RECORDED via GitHub compare** |
| governed basis ancestry             | **EXECUTED\_AND\_RECORDED via GitHub compare** |
| Later preservation tip required     | **No**                                         |
| Historical v0.2/v0.2.1 preservation | **EXECUTED\_AND\_RECORDED**                    |
| Representative blob identity        | **EXECUTED\_AND\_RECORDED**                    |
| Exact local detached checkout       | **NOT\_EXECUTED\_DUE\_TO\_SESSION\_LIMIT**     |
| Raw local `rev-parse/status/log`    | **NOT\_EXECUTED\_DUE\_TO\_SESSION\_LIMIT**     |
| v0.2 checker                        | **NOT\_EXECUTED\_DUE\_TO\_SESSION\_LIMIT**     |
| v0.2.1 checker                      | **NOT\_EXECUTED\_DUE\_TO\_SESSION\_LIMIT**     |
| v0.2.2 checker                      | **NOT\_EXECUTED\_DUE\_TO\_SESSION\_LIMIT**     |
| v0.2 tests                          | **NOT\_EXECUTED\_DUE\_TO\_SESSION\_LIMIT**     |
| v0.2.1 tests                        | **NOT\_EXECUTED\_DUE\_TO\_SESSION\_LIMIT**     |
| v0.2.2 tests                        | **NOT\_EXECUTED\_DUE\_TO\_SESSION\_LIMIT**     |
| R003 source inspection              | **EXECUTED\_AND\_RECORDED**                    |
| R003 Unicode alias challenge        | **EXECUTED\_AND\_RECORDED — rejected**         |
| R004 source inspection              | **EXECUTED\_AND\_RECORDED**                    |
| R004 exact mutations                | **NOT\_EXECUTED\_DUE\_TO\_SESSION\_LIMIT**     |
| R005 source inspection              | **EXECUTED\_AND\_RECORDED**                    |
| R005 prescribed mutations           | **NOT\_EXECUTED\_DUE\_TO\_SESSION\_LIMIT**     |
| Reviewer-originated challenge       | **EXECUTED\_AND\_RECORDED**                    |
| Reviewer challenge result           | **Accepted U+200B source reference**           |
| Exact candidate end-to-end pass     | **NOT ESTABLISHED**                            |

---

# 13. Narrowest disposition

## `REVIEW_INCONCLUSIVE`

That is narrower and more accurate than a favorable disposition.

The evidence **does support** that v0.2.2 contains substantive mechanisms addressing R003, R004, and R005, that the frozen predecessor surfaces were not rewritten, and that the preserved Gemini Unicode-alias hypothesis does **not** survive mechanical testing of the implemented parser semantics.

It also uncovered one additional representational edge:

> `source_refs: ["\u200b"]` is accepted.

That edge does **not** presently demonstrate authority, admission, proof, readiness, execution, or standing promotion.

But the defining requirement for an exterior recomputation was execution against the **exact frozen candidate checkout**, and that execution did not occur. Consequently, I cannot honestly promote the result to `EXTERIOR_RECOMPUTATION_CONFORMING_WITHIN_DECLARED_CORRECTION_SCOPE` or `...WITH_QUALIFICATIONS`.

### Standing consequence

This review establishes **no new standing** and does not:

- merge PR #128;
- admit PROOF-005;
- admit proof packaging;
- promote Fork Candidate Model standing;
- establish source grounding;
- authorize provider calls or Pair-001;
- authorize pilot/production;
- establish legal/compliance sufficiency;
- endorse an actor;
- transfer or inherit authority.

The correct next gate is a genuinely executable fresh environment against **exactly**:

`9e3cdd2fb6d67f9abd6233ce673341bd817d6338`

followed by the requested raw stdout/stderr, exit codes, mutation exhibits, and evidence hashes.