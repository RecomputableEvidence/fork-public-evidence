# CROSS-ENVIRONMENT-RECOMPUTATION-COMPARISON-001

## Subject binding

**Subject:** `FORK-II-CONSTRUCTIVE-STANDING-LIFECYCLE-KERNEL-001 v0.1.1`  
**Frozen archive SHA-256:** `a9c18311043c505137eaece9db6b72b9b186be33a8970df48d3fe5800d1de760`

This comparison does not modify or supersede the frozen subject.

## Compared recomputations

| Property | ChatGPT recomputation | Claude recomputation |
|---|---|---|
| Source record | `RECOMPUTATION-CHATGPT-001.zip` | `RECOMPUTATION-CLAUDE-001-RAW.md` |
| Subject archive SHA-256 observed | `a9c183…de760` | `a9c183…de760` |
| Manifest verification before execution | 63/63; 0 mismatches | 63/63; 0 mismatches |
| OS | Debian GNU/Linux 13 (13.3) | Ubuntu 24.04.4 LTS |
| Kernel/platform | Linux 6.18.44 x86_64 | Linux 6.18.44-fc-v37 x86_64 |
| Python | CPython 3.13.5 | CPython 3.12.3 |
| Compiler | GCC 14.2.0 (Python build) | GCC 13.3.0 (Python build) |
| glibc | 2.41 | 2.39 |
| Architecture | x86_64 | x86_64 |
| Baseline | PASS — 22/22 | PASS — 22/22 |
| Unit tests | 7/7, OK | 7/7, OK |
| Deliberate mutants | 12/12 detected | 12/12 detected |
| Baseline receipt | byte-identical to packaged receipt | byte-identical to packaged receipt |
| Mutant receipt JSON | all 12 structured-equal | all 12 semantically/JSON-equal |
| Mutant receipt bytes | differ only by packaged terminal LF | differ only by packaged terminal LF |
| Additional pressure | post-execution manifest verification: 63/63 unchanged | baseline rerun with warnings-as-errors: PASS; no stderr |

## Mutant concordance

Both attempts observed the same failed-fixture pattern:

| Mutant | Failed fixture(s) |
|---|---|
| `eligibility_authorization` | FII-01 |
| `scope_globality` | FII-03 |
| `false_negation` | FII-04 |
| `automatic_license` | FII-05, FII-13 |
| `historical_rewrite` | FII-14, FII-16 |
| `authority_infects_evidence` | FII-17 |
| `force_total_order` | FII-18 |
| `stale_reuse` | FII-14, FII-15 |
| `mutable_profile_reference` | FII-19 |
| `historical_disposition_promoted_to_correctness` | FII-20 |
| `unbound_dependency_snapshot` | FII-21 |
| `null_effective_until_promoted_to_indefinite_validity` | FII-22 |

## Comparison disposition

**Disposition:** `CROSS_ENVIRONMENT_REPRODUCTION_OBSERVED`

The two records support this bounded statement:

> The same frozen v0.1.1 executable probe reproduced its declared FII-01–FII-22 baseline behavior and detection of all twelve supplied deliberate mutants in two observed Linux/x86_64 environments, including a recomputation using a different Linux distribution, Python minor version, compiler build, and glibc version.

This is stronger than a single-environment rerun but narrower than platform independence. Both attempts execute the same implementation, fixtures, and schemas; therefore this is **execution reproducibility evidence**, not independent-implementation agreement.

## Environment-pressure interpretation

The ChatGPT recomputation environment materially overlapped the environment recorded by the frozen package itself. It therefore provides a strong independent execution record but weak cross-runtime pressure.

The Claude recomputation adds actual runtime variation:

- Debian 13 -> Ubuntu 24.04.4 LTS;
- CPython 3.13.5 -> CPython 3.12.3;
- glibc 2.41 -> glibc 2.39;
- GCC 14.2.0 -> GCC 13.3.0 for the Python build.

No behavioral divergence was observed on the declared baseline, unit suite, or deliberate-mutant surface under that variation.

## Preserved representation discrepancy

Both recomputations independently found the same receipt asymmetry:

- regenerated baseline receipt == packaged baseline receipt byte-for-byte;
- regenerated mutant receipts == packaged mutant receipts as parsed JSON;
- all twelve packaged mutant receipts contain one extra terminal LF byte relative to current harness `--receipt` output.

This is preserved as `OBSERVATION-RECEIPT-SERIALIZATION-ASYMMETRY-001`.

No semantic effect was observed. Cause is not established by this comparison record.

## Non-claims

This comparison does not establish general correctness, platform independence, production integrity, semantic completeness, failure-surface completeness, independent implementation convergence, truth, authority, compliance, or operational safety.
