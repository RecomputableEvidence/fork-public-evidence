# OBSERVATION-RECEIPT-SERIALIZATION-ASYMMETRY-001

## Observation

Two separate recomputation attempts independently observed the same representation difference between regenerated and packaged result receipts.

### Baseline receipt

`BASELINE_RECEIPT.json`

- parsed JSON: equal;
- bytes: equal.

### Twelve mutant receipts

For each supplied mutant receipt:

- parsed JSON: equal;
- substantive fields, counts, pass/fail states, fixture payloads, and failure details: equal;
- bytes: not equal;
- observed difference: packaged receipt contains one additional terminal LF (`0x0A`) byte relative to the harness's regenerated `--receipt` output.

The ChatGPT recomputation characterized the relation as:

`packaged_bytes == recomputed_bytes + b"\n"`

The Claude recomputation independently characterized the same one-byte terminal-newline difference across all twelve mutant receipts.

## Classification

**Observation class:** `REPRESENTATION_DISCREPANCY`

**Semantic divergence observed:** `NO`

**Cause established:** `NO`

**Normalization performed:** `NO`

## Standing

This observation establishes that byte identity is not currently reproduced for the twelve mutant receipt files under the current harness receipt-writing path, while parsed JSON identity is reproduced.

It does not establish that the difference is harmful, that it affects evaluator semantics, or that the package should be repaired. It is preserved for later analysis rather than silently normalized.
