# DERIVED-CLAUDE-RECOMPUTATION-RECORD

**Status:** Derived record from preserved raw transcript.  
**Raw source:** `sources/RECOMPUTATION-CLAUDE-001-RAW.md`  
**Not represented as:** a byte-for-byte Claude-authored receipt.

## Subject

`FORK-II-CONSTRUCTIVE-STANDING-LIFECYCLE-KERNEL-001 v0.1.1`

Observed subject archive SHA-256:

`a9c18311043c505137eaece9db6b72b9b186be33a8970df48d3fe5800d1de760`

Observed archive size: 70,171 bytes.

## Environment recorded before execution

- UTC observation time shown in transcript: 2026-09-23 15:02:46 UTC
- OS: Ubuntu 24.04.4 LTS (Noble Numbat)
- Kernel: Linux 6.18.44-fc-v37
- Architecture: x86_64
- Python: CPython 3.12.3
- Python build: `main, Mar 3 2026 12:15:18`
- Python compiler: GCC 13.3.0
- glibc: 2.39
- Python platform: `Linux-6.18.44-fc-v37-x86_64-with-glibc2.39`
- locale excerpt included `LC_CTYPE="POSIX"`

## Pre-execution package verification

The transcript reports:

- `MANIFEST.json` listed 63 files;
- 63 files checked;
- no missing files;
- 0 mismatches;
- no extracted files outside manifest coverage other than `MANIFEST.json` itself.

## Execution observations

Baseline:

- exit code 0;
- `RESULT: PASS — 22/22 fixtures passed`;
- FII-01 through FII-22 individually reported PASS;
- stderr empty.

Mutants:

- all 12 supplied deliberate mutants were executed;
- every mutant exited 1 and produced overall FAIL;
- failed-fixture sets matched the frozen expected surface.

Unit tests:

- exit code 0;
- seven tests ran;
- all seven reported `ok`;
- final result `OK`.

Additional pressure:

- no non-empty stderr was observed for baseline or mutant runs;
- rerunning the baseline with Python warnings elevated to errors exited 0 and produced no stderr.

## Structured receipt comparison

The transcript reports thirteen structured comparisons (one baseline plus twelve mutant receipts):

- baseline receipt: byte-identical and parsed-JSON identical;
- all twelve mutant receipts: parsed-JSON identical;
- all twelve mutant receipts: not byte-identical only because the packaged file contains one additional terminal LF byte.

## Bounded disposition

**Reproduced in the observed Ubuntu 24.04.4 / CPython 3.12.3 / glibc 2.39 environment on the declared baseline and supplied mutant surface.**

This does not establish general correctness, platform independence, production suitability, semantic completeness, or independent implementation agreement.
