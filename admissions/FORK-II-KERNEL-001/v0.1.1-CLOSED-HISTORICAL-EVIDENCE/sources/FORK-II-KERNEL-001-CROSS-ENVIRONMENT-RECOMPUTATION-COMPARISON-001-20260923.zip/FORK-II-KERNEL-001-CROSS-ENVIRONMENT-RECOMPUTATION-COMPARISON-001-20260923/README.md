# FORK-II-KERNEL-001 — Cross-Environment Recomputation Comparison 001

**Record ID:** `CROSS-ENVIRONMENT-RECOMPUTATION-COMPARISON-001`  
**Date:** 2026-09-23  
**Subject:** `FORK-II-CONSTRUCTIVE-STANDING-LIFECYCLE-KERNEL-001 v0.1.1`  
**Frozen subject archive:** `FORK-II-KERNEL-001-EXECUTABLE-PROBE-v0.1.1.zip`  
**Subject SHA-256:** `a9c18311043c505137eaece9db6b72b9b186be33a8970df48d3fe5800d1de760`

## Purpose

This is a **derived comparison record**, not a reseal, successor kernel, validation certificate, or modification of the frozen subject. It compares two separate recomputation attempts of the same frozen executable probe and preserves one observed representation discrepancy.

The comparison asks only whether the frozen subject reproduced its declared bounded behavior in the two observed execution environments.

## Source records

- `sources/RECOMPUTATION-CHATGPT-001.zip` — exact copy of the ChatGPT recomputation record supplied for this comparison.
- `sources/RECOMPUTATION-CLAUDE-001-RAW.md` — exact copy of the Claude recomputation transcript supplied for this comparison.
- `sources/SUBJECT_ARCHIVE_SHA256.txt` — exact copy of the detached SHA-256 receipt for the frozen subject archive.

The source records are preserved unchanged. `DERIVED-CLAUDE-RECOMPUTATION-RECORD.md` is a bounded reconstruction from the raw Claude transcript and is explicitly not represented as a byte-for-byte Claude-authored receipt.

## Bounded comparison result

Both recomputation attempts observed the same frozen subject SHA-256 and reproduced the declared reference behavior:

- package identity: same subject archive SHA-256;
- manifest population: 63/63 files verified before execution in both attempts;
- reference baseline: 22/22 fixtures PASS in both attempts;
- unit suite: 7/7 tests PASS in both attempts;
- deliberate mutants: all 12 detected in both attempts with the same failed-fixture pattern;
- structured receipt comparison: baseline receipt byte-identical; all 12 regenerated mutant receipts JSON-equivalent to packaged receipts;
- preserved discrepancy: packaged mutant receipts contain one additional terminal LF byte relative to current regenerated `--receipt` output.

The environments were not identical. The ChatGPT recomputation used Debian 13 / CPython 3.13.5 / glibc 2.41. The Claude recomputation used Ubuntu 24.04.4 LTS / CPython 3.12.3 / glibc 2.39. Both were x86_64 Linux environments.

## Standing of this record

This record supports the bounded observation that the **same frozen implementation** reproduced the same declared synthetic baseline and supplied mutant-detection behavior in these two observed environments, including one materially different Python/glibc/Linux-distribution combination.

It does **not** establish:

- general correctness of Fork II;
- platform independence;
- independent implementation agreement;
- completeness of the fixture or mutant surface;
- semantic completeness of `CANON-v1`;
- production, storage, concurrency, security, or operational suitability;
- truth, compliance, authority, legal sufficiency, or institutional authorization.

## Preserved discrepancy

See `OBSERVATION-RECEIPT-SERIALIZATION-ASYMMETRY-001.md`.

The discrepancy is preserved as a representation observation rather than normalized away. No semantic divergence was observed in parsed JSON content.

## Files

- `CROSS-ENVIRONMENT-RECOMPUTATION-COMPARISON-001.md`
- `CROSS-ENVIRONMENT-RECOMPUTATION-COMPARISON-001.json`
- `DERIVED-CLAUDE-RECOMPUTATION-RECORD.md`
- `OBSERVATION-RECEIPT-SERIALIZATION-ASYMMETRY-001.md`
- `OBSERVATION-RECEIPT-SERIALIZATION-ASYMMETRY-001.json`
- `SOURCE_BINDINGS.json`
- `SHA256SUMS.txt`
- `MANIFEST.json`
- `sources/` — preserved source records and subject hash receipt
