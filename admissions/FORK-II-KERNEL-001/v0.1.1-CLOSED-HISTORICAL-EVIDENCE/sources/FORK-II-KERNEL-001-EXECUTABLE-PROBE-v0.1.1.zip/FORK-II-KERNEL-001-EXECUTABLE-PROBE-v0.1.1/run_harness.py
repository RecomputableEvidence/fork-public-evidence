from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SRC = ROOT / "src"
sys.path.insert(0, str(SRC))

from forkii_kernel.harness import run


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--mutant", default=None)
    ap.add_argument("--receipt", default=None, help="optional output JSON path")
    args = ap.parse_args()

    result = run(ROOT / "fixtures", mutant=args.mutant)
    print(f"MODE: {result['mode']}")
    print(f"RESULT: {result['overall']} — {result['passed']}/{result['fixture_count']} fixtures passed")
    for row in result["results"]:
        marker = "PASS" if row["pass"] else "FAIL"
        print(f"[{marker}] {row['fixture_id']} — {row['title']}")
        for failure in row["failures"]:
            print(f"    {failure}")

    if args.receipt:
        Path(args.receipt).write_text(json.dumps(result, indent=2, sort_keys=True), encoding="utf-8")
    return 0 if result["overall"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
