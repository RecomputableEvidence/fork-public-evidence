from __future__ import annotations

import json
from pathlib import Path
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from forkii_kernel.canonical import (
    CANONICALIZATION_VERSION,
    dependency_snapshot_hash,
    dependency_snapshot_payload_hash,
    profile_content_hash,
    snapshot_binding_issues,
)
from forkii_kernel.harness import run, sha256_file


ORIGINAL_MUTANTS = [
    "eligibility_authorization",
    "scope_globality",
    "false_negation",
    "automatic_license",
    "historical_rewrite",
    "authority_infects_evidence",
    "force_total_order",
    "stale_reuse",
]

NEW_MUTANTS = {
    "mutable_profile_reference": "FII-19",
    "historical_disposition_promoted_to_correctness": "FII-20",
    "unbound_dependency_snapshot": "FII-21",
    "null_effective_until_promoted_to_indefinite_validity": "FII-22",
}


class ForkIIProbeTests(unittest.TestCase):
    def test_baseline_passes_all_frozen_fixtures(self):
        result = run(ROOT / "fixtures")
        self.assertEqual(result["fixture_count"], 22)
        self.assertEqual(result["failed"], 0, result)

    def test_old_fixture_files_are_byte_identical_to_v0_1(self):
        prior_manifest = json.loads((ROOT / "prior_v0_1" / "MANIFEST_v0.1.json").read_text(encoding="utf-8"))
        prior = {row["path"]: row["sha256"] for row in prior_manifest["files"] if row["path"].startswith("fixtures/FII-")}
        self.assertEqual(len(prior), 18)
        for i in range(1, 19):
            rel = f"fixtures/FII-{i:02d}.json"
            with self.subTest(rel=rel):
                self.assertEqual(sha256_file(ROOT / rel), prior[rel])

    def test_original_mutants_remain_detected_by_original_surface(self):
        for mutant in ORIGINAL_MUTANTS:
            with self.subTest(mutant=mutant):
                result = run(ROOT / "fixtures", mutant=mutant)
                failed_old = [r["fixture_id"] for r in result["results"] if not r["pass"] and int(r["fixture_id"].split("-")[1]) <= 18]
                self.assertGreater(len(failed_old), 0, result)

    def test_each_new_mutant_fails_required_fixture(self):
        for mutant, fixture_id in NEW_MUTANTS.items():
            with self.subTest(mutant=mutant):
                result = run(ROOT / "fixtures", mutant=mutant)
                row = next(r for r in result["results"] if r["fixture_id"] == fixture_id)
                self.assertFalse(row["pass"], result)

    def test_profile_hash_changes_when_semantic_content_changes(self):
        fx = json.loads((ROOT / "fixtures" / "FII-19.json").read_text(encoding="utf-8"))
        ref = fx["dependencies"]["referenced_profile"]
        obs = fx["dependencies"]["observed_profile"]
        self.assertNotEqual(profile_content_hash(ref), profile_content_hash(obs))
        self.assertEqual(profile_content_hash(ref), fx["dependencies"]["recorded_content_hash"])

    def test_well_bound_snapshot_is_reproducible(self):
        deps = {
            "standing_profile_id": "SP-001",
            "scope_definition_id": "SD-003",
            "evidence_population_id": "EP-008",
            "source_manifest_id": "AM-004",
        }
        hashes = {k: ("0" * 64 if idx % 2 == 0 else "1" * 64) for idx, k in enumerate(deps.values())}
        snapshot = {
            "dependency_snapshot_id": "DS-POSITIVE-001",
            "snapshot_version": "DS-v1",
            "dependencies": deps,
            "binding": {
                "canonicalization_version": CANONICALIZATION_VERSION,
                "dependency_record_hashes": hashes,
                "canonical_payload_hash": None,
                "snapshot_hash": None,
            },
            "provenance": {"immutable": True},
        }
        snapshot["binding"]["canonical_payload_hash"] = dependency_snapshot_payload_hash(snapshot)
        snapshot["binding"]["snapshot_hash"] = dependency_snapshot_hash(snapshot)
        self.assertEqual(snapshot_binding_issues(snapshot), [])

    def test_canon_v1_is_explicit_and_inspectable(self):
        spec = json.loads((ROOT / "canonicalization" / "CANON-v1.json").read_text(encoding="utf-8"))
        self.assertEqual(spec["canonicalization_version"], CANONICALIZATION_VERSION)
        self.assertIn("/effective_period", spec["standing_profile"]["included_field_paths"])
        self.assertIn("/display", spec["standing_profile"]["excluded_field_paths"])


if __name__ == "__main__":
    unittest.main()
