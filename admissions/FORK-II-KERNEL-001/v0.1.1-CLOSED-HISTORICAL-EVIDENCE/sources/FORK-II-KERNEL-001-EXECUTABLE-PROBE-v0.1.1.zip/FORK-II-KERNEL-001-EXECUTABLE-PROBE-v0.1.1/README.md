# FORK-II-KERNEL-001-EXECUTABLE-PROBE v0.1.1

**Identity / Temporal Non-Vacuity Probe**

A deliberately narrow successor to v0.1. It retains the frozen FII-01 through FII-18 semantic surface and adds only four infrastructure fixtures, FII-19 through FII-22.

## Experimental question

Can the Fork II kernel preserve immutable referents, bounded historical disposition, reproducibly bound dependency state, and explicit temporal validity while retaining every v0.1 semantic protection?

## What v0.1 already established

Within its frozen synthetic fixture population, the reference evaluator passed FII-01 through FII-18 and eight deliberate semantic mutants were rejected by at least one named fixture each. The original receipts and manifest are preserved under `prior_v0_1/`.

## v0.1.1 adds only four controls

- **FII-19 — IMMUTABLE_PROFILE_REFERENT**: stable profile ID is insufficient if canonical semantic content changes.
- **FII-20 — HISTORICAL_DISPOSITION_NOT_CORRECTNESS**: archived disposition is not proof of historical evaluator correctness.
- **FII-21 — REPRODUCIBLY_BOUND_DEPENDENCY_SNAPSHOT**: a named snapshot is not an exact dependency population without canonical binding.
- **FII-22 — EXPLICIT_EFFECTIVE_PERIOD**: a null end does not establish indefinite current validity.

## Non-negotiable regression rule

`new capability != permission to forget old failures`

Admission requires:

1. Baseline FII-01..FII-18 remains 18/18 PASS without changed expectations.
2. All original eight semantic mutants remain detectable.
3. Baseline FII-19..FII-22 is 4/4 PASS.
4. Each new infrastructure mutant fails its named fixture.
5. Prior profiles/transitions/snapshots are not mutated by lifecycle recomputation.
6. Historical disposition remains distinct from historical correctness.
7. Missing effective-period state never becomes open-ended validity.

## New deliberate mutants

- `mutable_profile_reference`
- `historical_disposition_promoted_to_correctness`
- `unbound_dependency_snapshot`
- `null_effective_until_promoted_to_indefinite_validity`

The original eight semantic mutants remain unchanged.

## Canonicalization

`canonicalization/CANON-v1.json` freezes the exact serialization and profile include/exclude rules used in this probe. The canonicalizer is inspectable and version-bound. A stable hash does **not** establish that every meaning-bearing field has been included.

## Run

```bash
python run_harness.py
python run_harness.py --mutant mutable_profile_reference
python -m unittest discover -s tests -v
```

Baseline is expected to exit `0` with 22/22 PASS. A deliberate mutant is expected to exit non-zero when its prohibited behavior is detected.

## Claim boundary

A PASS establishes only that this reference implementation conforms to this frozen synthetic fixture population under these exact code, fixture, schema, and canonicalization versions. It does not establish general correctness, truth, compliance, authority, production safety, real-workflow representativeness, or completeness of the failure surface.
