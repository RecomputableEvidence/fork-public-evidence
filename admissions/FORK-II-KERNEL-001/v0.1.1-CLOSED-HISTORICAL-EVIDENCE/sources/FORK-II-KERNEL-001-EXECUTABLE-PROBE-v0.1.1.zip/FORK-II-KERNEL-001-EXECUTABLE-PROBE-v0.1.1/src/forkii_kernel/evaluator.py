from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from typing import Any, Dict, Optional

from .canonical import profile_content_hash, snapshot_binding_issues

DISPOSITIONS = {
    "LICENSED",
    "NOT_LICENSED",
    "INDETERMINATE",
    "NOT_APPLICABLE",
    "BLOCKED",
    "EXTERNAL_AUTHORITY_REQUIRED",
}

MUTANTS = {
    None,
    # v0.1 semantic mutants
    "eligibility_authorization",
    "scope_globality",
    "false_negation",
    "automatic_license",
    "historical_rewrite",
    "authority_infects_evidence",
    "force_total_order",
    "stale_reuse",
    # v0.1.1 identity / temporal mutants
    "mutable_profile_reference",
    "historical_disposition_promoted_to_correctness",
    "unbound_dependency_snapshot",
    "null_effective_until_promoted_to_indefinite_validity",
}


@dataclass(frozen=True)
class EvalResult:
    fixture_id: str
    kind: str
    payload: Dict[str, Any]


def _base_payload(fx: Dict[str, Any]) -> Dict[str, Any]:
    before = deepcopy(fx.get("profile_before", {}))
    return {
        "transition_disposition": "INDETERMINATE",
        "profile_after": before,
        "target_proposition_truth": "NOT_ADJUDICATED",
        "advancement_state": "NONE",
        "advancement_prescriptive": False,
        "advancement_guarantees_license": False,
        "authority_disposition": "NOT_EVALUATED",
        "historical_transition_preserved": True,
        "historical_transition_error_asserted": False,
        "historical_disposition_status": "PRESERVED",
        "historical_evaluation_correctness": "NOT_EVALUATED",
        "current_use_status": "CURRENT",
        "comparison_relation": None,
        "reevaluation_performed": bool(fx.get("dependencies", {}).get("reevaluation_performed", False)),
        "referent_integrity": "NOT_EVALUATED",
        "historical_reuse_permitted": None,
        "dependency_binding_status": "NOT_EVALUATED",
        "recomputation_permitted": None,
        "effective_period_status": "NOT_EVALUATED",
        "notes": [],
    }


def _evaluate_infrastructure(fx: Dict[str, Any], p: Dict[str, Any], mutant: Optional[str]) -> EvalResult:
    kind = fx["kind"]
    deps = fx.get("dependencies", {})

    if kind == "profile_identity":
        referenced = deps.get("referenced_profile", {})
        observed = deps.get("observed_profile", {})
        recorded_hash = deps.get("recorded_content_hash")
        observed_hash = profile_content_hash(observed)
        referenced_hash = profile_content_hash(referenced)

        # Baseline requires both the original record hash and current observed content
        # to agree with the exact canonical referent.
        if recorded_hash and recorded_hash == referenced_hash == observed_hash:
            p["referent_integrity"] = "ESTABLISHED"
            p["historical_reuse_permitted"] = True
        else:
            p["referent_integrity"] = "CORRUPTED_OR_CHANGED"
            p["historical_reuse_permitted"] = False
            p["current_use_status"] = "REEVALUATION_REQUIRED"

        if mutant == "mutable_profile_reference":
            # Defect: trust identifier equality and ignore changed semantic bytes.
            if referenced.get("standing_profile_id") == observed.get("standing_profile_id"):
                p["referent_integrity"] = "ESTABLISHED"
                p["historical_reuse_permitted"] = True
                p["current_use_status"] = "CURRENT"
        return EvalResult(fx["fixture_id"], kind, p)

    if kind == "historical_disposition":
        hist = deps.get("historical_record", {})
        if hist.get("disposition"):
            p["historical_disposition_status"] = "PRESERVED"
        review = deps.get("historical_correctness_review")
        if review and review.get("performed"):
            p["historical_evaluation_correctness"] = review.get("outcome", "INDETERMINATE")
        else:
            p["historical_evaluation_correctness"] = "NOT_EVALUATED"

        if mutant == "historical_disposition_promoted_to_correctness" and hist.get("disposition") == "LICENSED":
            p["historical_evaluation_correctness"] = "ESTABLISHED_CORRECT_FROM_ARCHIVE"
        return EvalResult(fx["fixture_id"], kind, p)

    if kind == "dependency_snapshot":
        snapshot = deps.get("dependency_snapshot", {})
        issues = snapshot_binding_issues(snapshot)
        if issues:
            p["dependency_binding_status"] = "DEPENDENCY_BINDING_NOT_ESTABLISHED"
            p["recomputation_permitted"] = False
            p["notes"].extend(issues)
        else:
            p["dependency_binding_status"] = "REPRODUCIBLY_BOUND"
            p["recomputation_permitted"] = True

        if mutant == "unbound_dependency_snapshot":
            # Defect: a friendly identifier is treated as sufficient binding.
            if snapshot.get("dependency_snapshot_id"):
                p["dependency_binding_status"] = "REPRODUCIBLY_BOUND"
                p["recomputation_permitted"] = True
                p["notes"] = []
        return EvalResult(fx["fixture_id"], kind, p)

    if kind == "effective_period":
        ep = deps.get("effective_period", {})
        state = ep.get("effective_until_state")
        end = ep.get("effective_until")
        allowed = {"OPEN_UNTIL_DEPENDENCY_CHANGE", "FIXED_TIME", "UNKNOWN", "NOT_APPLICABLE"}
        if state not in allowed:
            p["effective_period_status"] = "EFFECTIVE_PERIOD_NOT_ESTABLISHED"
            p["current_use_status"] = "NOT_ESTABLISHED"
        elif state == "FIXED_TIME" and not end:
            p["effective_period_status"] = "EFFECTIVE_PERIOD_NOT_ESTABLISHED"
            p["current_use_status"] = "NOT_ESTABLISHED"
        elif state == "OPEN_UNTIL_DEPENDENCY_CHANGE" and not ep.get("reevaluation_triggers"):
            p["effective_period_status"] = "EFFECTIVE_PERIOD_NOT_ESTABLISHED"
            p["current_use_status"] = "NOT_ESTABLISHED"
        else:
            p["effective_period_status"] = state

        if mutant == "null_effective_until_promoted_to_indefinite_validity" and end is None:
            p["effective_period_status"] = "INDEFINITELY_VALID"
            p["current_use_status"] = "CURRENT"
        return EvalResult(fx["fixture_id"], kind, p)

    raise ValueError(f"unsupported infrastructure fixture kind: {kind}")


def evaluate_fixture(fx: Dict[str, Any], mutant: Optional[str] = None) -> EvalResult:
    if mutant not in MUTANTS:
        raise ValueError(f"unknown mutant: {mutant}")

    kind = fx["kind"]
    p = _base_payload(fx)
    deps = fx.get("dependencies", {})
    req = fx.get("request", {})
    before = fx.get("profile_before", {})

    if kind in {"profile_identity", "historical_disposition", "dependency_snapshot", "effective_period"}:
        return _evaluate_infrastructure(fx, p, mutant)

    if kind == "comparison":
        if deps.get("declared_order_exists"):
            p["comparison_relation"] = deps.get("declared_relation", "SAME")
        else:
            p["comparison_relation"] = "INCOMPARABLE"
        if mutant == "force_total_order":
            p["comparison_relation"] = "STRONGER"
        return EvalResult(fx["fixture_id"], kind, p)

    if kind == "lifecycle":
        if deps.get("material_dependency_change"):
            p["current_use_status"] = "REEVALUATION_REQUIRED"
            p["transition_disposition"] = "INDETERMINATE"
            p["advancement_state"] = "REEVALUATION_REQUIRED"
        if deps.get("authority_revoked"):
            p["authority_disposition"] = "REVOKED"
            p["profile_after"]["evidence"] = before.get("evidence")
        if mutant == "historical_rewrite" and deps.get("material_dependency_change"):
            p["historical_transition_preserved"] = False
            p["historical_transition_error_asserted"] = True
        if mutant == "authority_infects_evidence" and deps.get("authority_revoked"):
            p["profile_after"]["evidence"] = "DOWNGRADED_BY_AUTHORITY_REVOCATION"
        if mutant == "stale_reuse" and deps.get("material_dependency_change"):
            p["current_use_status"] = "CURRENT"
            p["transition_disposition"] = "LICENSED"
        return EvalResult(fx["fixture_id"], kind, p)

    # v0.1 transition evaluator retained intentionally.
    dim = req.get("dimension")
    target = req.get("target")
    p["transition_disposition"] = "NOT_LICENSED"

    if req.get("requires_external_authority"):
        auth = deps.get("external_authority", {})
        if not auth.get("preserved") or not auth.get("effective") or not auth.get("applicable"):
            p["transition_disposition"] = "EXTERNAL_AUTHORITY_REQUIRED"
            p["authority_disposition"] = "NOT_ESTABLISHED" if auth.get("preserved") else "NONE_PRESERVED"
        else:
            p["authority_disposition"] = "COMPATIBLE"
            if deps.get("standing_prerequisites_satisfied", False):
                p["transition_disposition"] = "LICENSED"
                p["profile_after"][dim] = target

    elif dim == "claim" and target == "GLOBAL_CONSERVATION":
        if deps.get("relevant_surface_population_complete") and deps.get("scope_adequate_for_claim"):
            p["transition_disposition"] = "LICENSED"
            p["profile_after"][dim] = target
        else:
            p["transition_disposition"] = "NOT_LICENSED"
            p["advancement_state"] = "REEVALUATION_REQUIRED"

    elif dim == "execution" and target == "EXECUTED_PASSED":
        needed = (
            deps.get("bound_execution_receipt")
            and deps.get("artifact_run_binding")
            and deps.get("executed_evaluator_record")
        )
        if needed and deps.get("reevaluation_performed"):
            p["transition_disposition"] = "LICENSED"
            p["profile_after"][dim] = target
        else:
            p["transition_disposition"] = "NOT_LICENSED"
            p["advancement_state"] = "REEVALUATION_REQUIRED" if needed else "CONDITIONS_MISSING"

    elif dim == "evidence":
        if deps.get("new_evidentiary_basis"):
            p["transition_disposition"] = "LICENSED"
            p["profile_after"][dim] = target
        else:
            p["transition_disposition"] = "NOT_LICENSED"

    elif dim in {"routing", "eligibility"}:
        p["transition_disposition"] = "NOT_LICENSED"

    elif deps.get("explicit_rule_satisfied"):
        p["transition_disposition"] = "LICENSED"
        p["profile_after"][dim] = target

    # v0.1 semantic mutants intentionally retained.
    if mutant == "eligibility_authorization" and fx["fixture_id"] == "FII-01":
        p["transition_disposition"] = "LICENSED"
        p["authority_disposition"] = "ASSUMED_FROM_ELIGIBILITY"
        p["profile_after"][dim] = target

    if mutant == "scope_globality" and fx["fixture_id"] == "FII-03":
        p["transition_disposition"] = "LICENSED"
        p["profile_after"]["claim"] = "GLOBAL_CONSERVATION"

    if mutant == "false_negation" and fx["fixture_id"] == "FII-04":
        p["target_proposition_truth"] = "FALSE"
        p["profile_after"]["execution"] = "EXECUTION_FAILED"

    if mutant == "automatic_license" and fx["fixture_id"] in {"FII-05", "FII-13"}:
        if deps.get("advancement_conditions_satisfied"):
            p["transition_disposition"] = "LICENSED"
            p["profile_after"][dim] = target
            p["advancement_guarantees_license"] = True

    p["advancement_prescriptive"] = False
    return EvalResult(fx["fixture_id"], kind, p)
