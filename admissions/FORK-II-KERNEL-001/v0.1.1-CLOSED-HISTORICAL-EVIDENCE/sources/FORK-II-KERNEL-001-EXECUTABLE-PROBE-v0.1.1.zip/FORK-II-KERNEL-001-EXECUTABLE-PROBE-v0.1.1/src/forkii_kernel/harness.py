from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

from .evaluator import evaluate_fixture


def load_fixtures(fixtures_dir: Path) -> List[Dict[str, Any]]:
    out = []
    for path in sorted(fixtures_dir.glob("FII-*.json")):
        out.append(json.loads(path.read_text(encoding="utf-8")))
    return out


def _get(obj: Dict[str, Any], dotted: str):
    cur: Any = obj
    for part in dotted.split("."):
        if isinstance(cur, dict) and part in cur:
            cur = cur[part]
        else:
            return None
    return cur


def check_fixture(fx: Dict[str, Any], payload: Dict[str, Any]) -> List[str]:
    failures: List[str] = []
    expect = fx.get("expect", {})

    for key, value in expect.get("equals", {}).items():
        got = _get(payload, key)
        if got != value:
            failures.append(f"{key}: expected {value!r}, got {got!r}")

    for key, value in expect.get("not_equals", {}).items():
        got = _get(payload, key)
        if got == value:
            failures.append(f"{key}: prohibited value {value!r} observed")

    for key, allowed in expect.get("in", {}).items():
        got = _get(payload, key)
        if got not in allowed:
            failures.append(f"{key}: expected one of {allowed!r}, got {got!r}")

    for key in expect.get("unchanged_dimensions", []):
        before = fx.get("profile_before", {}).get(key)
        after = payload.get("profile_after", {}).get(key)
        if before != after:
            failures.append(f"{key}: expected unchanged {before!r}, got {after!r}")

    return failures


def run(fixtures_dir: Path, mutant: Optional[str] = None) -> Dict[str, Any]:
    fixtures = load_fixtures(fixtures_dir)
    results = []
    for fx in fixtures:
        ev = evaluate_fixture(fx, mutant=mutant)
        failures = check_fixture(fx, ev.payload)
        results.append({
            "fixture_id": fx["fixture_id"],
            "title": fx["title"],
            "pass": not failures,
            "failures": failures,
            "payload": ev.payload,
        })
    passed = sum(1 for r in results if r["pass"])
    return {
        "mode": "baseline" if mutant is None else f"mutant:{mutant}",
        "fixture_count": len(results),
        "passed": passed,
        "failed": len(results) - passed,
        "overall": "PASS" if passed == len(results) else "FAIL",
        "results": results,
    }


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()
