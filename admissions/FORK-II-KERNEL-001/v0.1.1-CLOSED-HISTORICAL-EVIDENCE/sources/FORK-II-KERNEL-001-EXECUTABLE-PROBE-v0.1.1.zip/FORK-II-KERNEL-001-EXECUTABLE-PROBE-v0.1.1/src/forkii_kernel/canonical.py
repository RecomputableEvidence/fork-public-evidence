from __future__ import annotations

import hashlib
import json
from copy import deepcopy
from typing import Any, Dict, Iterable

CANONICALIZATION_VERSION = "CANON-v1"

PROFILE_INCLUDED_FIELDS = (
    "standing_profile_id",
    "profile_version",
    "dimensions",
    "scope_definition_id",
    "evidence_population_id",
    "measurement_versions",
    "obligation_map_id",
    "rule_versions",
    "applicability_records",
    "execution_records",
    "authority_reference_ids",
    "effective_period",
)

PROFILE_EXCLUDED_FIELDS = (
    "display",
    "transport_metadata",
)


def canonical_json_bytes(obj: Any) -> bytes:
    """Deterministic JSON serialization for CANON-v1."""
    return json.dumps(
        obj,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def canonical_hash(obj: Any) -> str:
    return sha256_bytes(canonical_json_bytes(obj))


def profile_semantic_payload(profile: Dict[str, Any]) -> Dict[str, Any]:
    """Return only CANON-v1 meaning-bearing profile fields.

    This is an explicitly versioned implementation choice, not a claim that
    excluded fields can never become standing-bearing under a successor canon.
    """
    out: Dict[str, Any] = {}
    for field in PROFILE_INCLUDED_FIELDS:
        if field in profile:
            out[field] = deepcopy(profile[field])
    return out


def profile_content_hash(profile: Dict[str, Any]) -> str:
    return canonical_hash(profile_semantic_payload(profile))


def dependency_snapshot_payload(snapshot: Dict[str, Any]) -> Dict[str, Any]:
    """Canonical payload for a dependency snapshot excluding its own hashes."""
    return {
        "dependency_snapshot_id": snapshot.get("dependency_snapshot_id"),
        "snapshot_version": snapshot.get("snapshot_version"),
        "dependencies": deepcopy(snapshot.get("dependencies", {})),
        "binding": {
            "canonicalization_version": snapshot.get("binding", {}).get("canonicalization_version"),
            "dependency_record_hashes": deepcopy(snapshot.get("binding", {}).get("dependency_record_hashes", {})),
        },
        "provenance": {
            "immutable": snapshot.get("provenance", {}).get("immutable"),
        },
    }


def dependency_snapshot_payload_hash(snapshot: Dict[str, Any]) -> str:
    return canonical_hash(dependency_snapshot_payload(snapshot))


def dependency_snapshot_hash(snapshot: Dict[str, Any]) -> str:
    # Snapshot hash binds the canonical payload hash plus immutable dependency hashes.
    binding = snapshot.get("binding", {})
    record = {
        "canonicalization_version": binding.get("canonicalization_version"),
        "canonical_payload_hash": binding.get("canonical_payload_hash"),
        "dependency_record_hashes": deepcopy(binding.get("dependency_record_hashes", {})),
    }
    return canonical_hash(record)


def snapshot_binding_issues(snapshot: Dict[str, Any]) -> list[str]:
    issues: list[str] = []
    binding = snapshot.get("binding", {})
    deps = snapshot.get("dependencies", {})
    provenance = snapshot.get("provenance", {})

    if not snapshot.get("dependency_snapshot_id"):
        issues.append("missing dependency_snapshot_id")
    if not snapshot.get("snapshot_version"):
        issues.append("missing snapshot_version")
    if binding.get("canonicalization_version") != CANONICALIZATION_VERSION:
        issues.append("canonicalization version missing or unsupported")
    record_hashes = binding.get("dependency_record_hashes")
    if not isinstance(record_hashes, dict) or not record_hashes:
        issues.append("dependency record hashes missing")
    if provenance.get("immutable") is not True:
        issues.append("snapshot immutability not established")

    declared_ids: list[str] = []
    for key, value in deps.items():
        if key.endswith("_id") and isinstance(value, str):
            declared_ids.append(value)
        elif isinstance(value, list):
            declared_ids.extend(v for v in value if isinstance(v, str))
    if record_hashes:
        missing = sorted(set(declared_ids) - set(record_hashes.keys()))
        if missing:
            issues.append("unhashed dependency ids: " + ", ".join(missing))

    expected_payload = dependency_snapshot_payload_hash(snapshot)
    if binding.get("canonical_payload_hash") != expected_payload:
        issues.append("canonical payload hash mismatch")

    expected_snapshot = dependency_snapshot_hash(snapshot)
    if binding.get("snapshot_hash") != expected_snapshot:
        issues.append("snapshot hash mismatch")

    return issues
