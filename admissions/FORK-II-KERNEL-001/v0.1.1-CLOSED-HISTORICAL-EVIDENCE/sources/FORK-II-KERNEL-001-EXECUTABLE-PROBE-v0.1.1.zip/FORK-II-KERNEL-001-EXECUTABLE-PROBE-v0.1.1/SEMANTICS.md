# Frozen semantic boundary — v0.1.1 identity / temporal non-vacuity probe

## Experimental question

Can the Fork II kernel preserve immutable referents, bounded historical disposition, reproducibly bound dependency state, and explicit temporal validity while retaining every v0.1 semantic protection?

## Canonical semantic objects represented by this probe

- `STANDING_PROFILE`
- `TRANSITION_REQUEST_RECORD`
- `STANDING_TRANSITION_RECORD`
- `ADVANCEMENT_PATH_RECORD`
- `EXTERNAL_AUTHORITY_RECORD`
- `STANDING_LIFECYCLE_RECORD`
- supporting `DEPENDENCY_SNAPSHOT`
- derived `STANDING_ENVELOPE`

## v0.1 invariants retained

- Non-inheritance.
- Request neutrality.
- Dimension isolation.
- Cross-dimensional dependency without cross-dimensional promotion.
- Transition-basis preservation.
- No false negation: `NOT_LICENSED` does not imply `FALSE`.
- Advancement restraint.
- Authority separation and authority non-infection.
- Transmission-envelope preservation.
- Temporal non-retroactivity.
- Recomputation after material dependency change.
- Partial-order discipline, including `INCOMPARABLE`.
- Historical record preservation.

## v0.1.1 infrastructure controls

1. A stable identifier does not establish a stable referent; canonical semantic content is immutable under the same profile identifier.
2. A historically recorded disposition does not establish historical evaluator correctness.
3. A named dependency snapshot does not establish reproducible binding; exact versioned dependency hashes and CANON-v1 binding are required.
4. Absence of a recorded end does not establish open-ended validity; effective-period state must be explicit.

## Canonicalization restraint

`CANON-v1` is inspectable and version-bound. It records which fields are included and excluded from the canonical semantic payload. Stable hashes do not establish that every meaning-bearing field has been included.

## Probe-specific limitation

The reference evaluator implements only the minimum synthetic semantics needed to exercise FII-01 through FII-22. Passing the frozen fixtures is a bounded conformance result, not general validation of Fork II or of real institutional workflows.
