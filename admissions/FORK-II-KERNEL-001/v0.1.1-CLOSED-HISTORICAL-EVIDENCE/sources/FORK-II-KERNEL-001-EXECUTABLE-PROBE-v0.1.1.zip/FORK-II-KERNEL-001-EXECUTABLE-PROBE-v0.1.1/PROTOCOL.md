# Frozen v0.1.1 protocol

## Target

**FORK-II-KERNEL-001-EXECUTABLE-PROBE-v0.1.1**  
**Identity / Temporal Non-Vacuity Probe**

## Falsifiable question

Can the Fork II kernel preserve immutable referents, bounded historical disposition, reproducibly bound dependency state, and explicit temporal validity while retaining every v0.1 semantic protection?

## Regression rule

> New capability does not grant permission to forget old failures.

FII-01 through FII-18 and their expected outcomes are preserved byte-for-byte from v0.1.

## New fixtures

- FII-19 `IMMUTABLE_PROFILE_REFERENT`
- FII-20 `HISTORICAL_DISPOSITION_NOT_CORRECTNESS`
- FII-21 `REPRODUCIBLY_BOUND_DEPENDENCY_SNAPSHOT`
- FII-22 `EXPLICIT_EFFECTIVE_PERIOD`

## New deliberate mutants

- `mutable_profile_reference`
- `historical_disposition_promoted_to_correctness`
- `unbound_dependency_snapshot`
- `null_effective_until_promoted_to_indefinite_validity`

## Admission boundary

Admission requires 22/22 baseline PASS, preservation of v0.1 fixture bytes, continued rejection of the original eight semantic mutants, and rejection of all four new infrastructure mutants. Admission is bounded synthetic conformance only; it does not establish truth, general correctness, authority, production safety, completeness, or real-workflow representativeness.

## Canonicalization restraint

CANON-v1 is frozen and inspectable. Its inclusion/exclusion rules are part of the experimental record. A stable canonical hash does not establish that every meaning-bearing field was included.
