# Independent-sketch-first note

This note was written from the recomputation observations before inspecting the packaged result receipts.

## What executed

- The documented baseline command, `python run_harness.py`, executed under Python 3.13.5 and exited 0.
- It reported `RESULT: PASS — 22/22 fixtures passed`, with FII-01 through FII-22 individually marked PASS.
- The documented unittest command, `python -m unittest discover -s tests -v`, executed and exited 0. Seven tests ran and all were reported `ok`; unittest concluded `OK`.
- Twelve deliberate mutant invocations were run using `python run_harness.py --mutant <name>`: the eight original mutants named by the supplied test module and the four v0.1.1 mutants named by README/PROTOCOL/tests.
- Every mutant invocation exited 1 and reported overall FAIL because at least one fixture failed.

## What did not execute / observed incompatibilities

- No documented execution command failed to start.
- No baseline or mutant stderr output was produced.
- The unittest runner wrote its normal verbose progress/result stream to stderr; no warning or exception was observed.
- No dependency installation, code repair, fixture adaptation, schema change, canonicalization change, or retry with altered semantics was performed.

## Mutant detection observed

- eligibility_authorization -> FII-01 failed (21/22)
- scope_globality -> FII-03 failed (21/22)
- false_negation -> FII-04 failed (21/22)
- automatic_license -> FII-05 and FII-13 failed (20/22)
- historical_rewrite -> FII-14 and FII-16 failed (20/22)
- authority_infects_evidence -> FII-17 failed (21/22)
- force_total_order -> FII-18 failed (21/22)
- stale_reuse -> FII-14 and FII-15 failed (20/22)
- mutable_profile_reference -> FII-19 failed (21/22)
- historical_disposition_promoted_to_correctness -> FII-20 failed (21/22)
- unbound_dependency_snapshot -> FII-21 failed (21/22)
- null_effective_until_promoted_to_indefinite_validity -> FII-22 failed (21/22)

## Evidence supported at this stage

In this Debian 13 / CPython 3.13.5 environment, the supplied reference implementation conformed to the frozen FII-01..FII-22 fixture population as exercised by the supplied baseline harness, and the harness detected all twelve supplied deliberate mutants. This observation is bounded to this executable object, fixture population, commands, and environment. It does not establish broader correctness, semantic completeness, authority, production integrity, or completeness of the failure surface.
