# Recomputation record — FORK-II-CONSTRUCTIVE-STANDING-LIFECYCLE-KERNEL-001 v0.1.1

Attempted 2026-09-23 UTC from the uploaded archive `FORK-II-KERNEL-001-EXECUTABLE-PROBE-v0.1.1.zip`.

## Disposition

**Reproduced within this environment, subject to the bounded claim stated by the package.**

The documented reference baseline reported 22/22 PASS. The supplied unittest suite ran 7 tests and concluded OK. Each of the twelve supplied deliberate mutant invocations exited non-zero and was detected by at least one fixture. No repair, dependency installation, semantic adaptation, fixture modification, schema modification, or canonicalization modification was performed before the independent execution phase.

This supports only the bounded observation that the supplied implementation conforms to the frozen FII-01..FII-22 synthetic fixture population in this runtime and that the harness detects the twelve supplied intentional mutations. It does not establish general correctness, semantic completeness, authority, production integrity, real-workflow representativeness, or completeness of the failure surface.

## 1. Environment

- Host/kernel: Linux 49f4c71d806c, kernel 6.18.44, x86_64
- OS: Debian GNU/Linux 13 (trixie), Debian 13.3
- libc: glibc 2.41
- Python: CPython 3.13.5, build string   `3.13.5 (main, Jul 15 2026, 20:25:40) [GCC 14.2.0]`
- Python platform string:   `Linux-6.18.44-x86_64-with-glibc2.41`
- bash: 5.2.37(1)-release

The packaged `receipts/EXECUTION_ENVIRONMENT.json` records the same Python version/build, architecture, kernel/platform string, system, and glibc version. Consequently, this attempt is an independent recomputation but not a materially different runtime-environment probe.

## 2. Archive and manifest verification

Observed uploaded-archive SHA-256:

`a9c18311043c505137eaece9db6b72b9b186be33a8970df48d3fe5800d1de760`

Observed uploaded-archive SHA-512:

`64b9070e7ff9e5d458531b2f6ccdec2e3b9786f7561bf2bf618b117b2c1848e0a26f00be77c306d839c59b19a6df4e6861cd6183f04174e2c98140f262a91683`

`MANIFEST.json` declares 63 package files and states that its scope is all package files except the manifest itself. Before execution, all 63 listed files were present and every SHA-256 matched the manifest. No detached or archive-level expected ZIP digest was found in README.md, PROTOCOL.md, SEMANTICS.md, or MANIFEST.json; therefore the ZIP digest above is an observed fingerprint, not a comparison against a separately supplied ZIP hash.

After execution, all 63 manifest-covered files still matched their declared hashes. The uploaded ZIP itself also retained SHA-256 `a9c18311043c505137eaece9db6b72b9b186be33a8970df48d3fe5800d1de760`.

Normal CPython execution created five `__pycache__/*.pyc` files in the extracted working copy. These were additional unmanifested execution artifacts; no manifest-covered file changed, and the uploaded ZIP was untouched.

## 3. Independent-sketch-first observation

Before inspecting the packaged result receipts, the recomputation recorded:

-   `python run_harness.py` -> exit 0;   `RESULT: PASS — 22/22 fixtures passed`; FII-01..FII-22 all individually PASS.
-   `python -m unittest discover -s tests -v` -> exit 0; 7 tests ran, all   `ok`; final result   `OK`.
- All twelve deliberate mutant commands -> exit 1 and overall FAIL, with the following detected fixture surface.

| Mutant | Recomputed result | Failed fixtures |
|---|---:|---|
| eligibility_authorization | 21/22 | FII-01 |
| scope_globality | 21/22 | FII-03 |
| false_negation | 21/22 | FII-04 |
| automatic_license | 20/22 | FII-05, FII-13 |
| historical_rewrite | 20/22 | FII-14, FII-16 |
| authority_infects_evidence | 21/22 | FII-17 |
| force_total_order | 21/22 | FII-18 |
| stale_reuse | 20/22 | FII-14, FII-15 |
| mutable_profile_reference | 21/22 | FII-19 |
| historical_disposition_promoted_to_correctness | 21/22 | FII-20 |
| unbound_dependency_snapshot | 21/22 | FII-21 |
| null_effective_until_promoted_to_indefinite_validity | 21/22 | FII-22 |

No documented command failed to start. Baseline and mutant stderr streams were empty. The unittest runner used stderr for its normal verbose progress/result stream; no exception or warning was observed.

The separate pre-comparison note is preserved as `INDEPENDENT_SKETCH_FIRST.md` with SHA-256 `0f3e11ffc0f656cdb38bc84e0dd2a69da08b058b95609d6dfe0c87c63af98d23`.

## 4. Comparison against packaged receipts (performed afterward)

After the independent-sketch-first record was frozen, the packaged receipts were inspected.

- Packaged baseline summary: PASS, 22/22. Recomputed structured baseline result is both JSON-equivalent and byte-for-byte identical to   `receipts/BASELINE_RECEIPT.json`.
- Packaged mutant summary: all twelve mutant result counts and failed-fixture sets match the independent recomputation exactly.
- Recomputed structured JSON for each mutant is JSON-equivalent to its packaged mutant receipt. The only byte-level difference is that every packaged mutant receipt has one final LF newline while the harness's current   `--receipt` output omits that final LF. In each case,   `packaged_bytes == recomputed_bytes + b"\n"`.
- Packaged unittest receipt and recomputed unittest output have the same seven test names/statuses and both conclude   `OK`. The elapsed-time line differs: packaged   `0.017s`; recomputed   `0.011s`.
- The packaged execution-environment receipt matches this runtime on the recorded platform/Python fields.

These formatting/timing differences were preserved rather than normalized away.

## 5. Commands executed

The independent execution phase used the documented path:

`python run_harness.py`

`python -m unittest discover -s tests -v`

and one `python run_harness.py --mutant <name>` invocation for each of the twelve supplied mutant names. After receipt comparison, the harness's optional `--receipt` argument was used to produce recomputed structured JSON solely for exact comparison with packaged JSON receipts.

## 6. What this attempt does and does not say

This attempt gives a positive independent recomputation record for the frozen synthetic population in the observed environment. It also finds no change to any manifest-covered input during execution.

It does **not** presently answer the next cross-environment question strongly, because the package's own environment receipt and this sandbox share the same recorded kernel/platform, glibc, architecture, Python version, and Python build. A materially different interpreter, OS/libc, filesystem/storage behavior, locale/timezone, or execution context would be needed to probe for hidden inheritance or implementation dependencies beyond this runtime fingerprint.
