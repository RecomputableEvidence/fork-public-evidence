"""
SE-003 Phase 0: Hash all untracked files before any action.
Outputs: path, size, sha256, first 50 chars of content for classification.
"""
import hashlib, os
from pathlib import Path

WORKTREE = Path(r'C:\N\fork-public-evidence')

# All untracked paths from git ls-files --others --exclude-standard output
untracked_entries = [
    "Downloads - Shortcut.lnk",
    "amend_fork_scoped_endorsement_lf_canonicalization_v0_1.ps1",
    "amend_fork_scoped_endorsement_lf_canonicalization_v0_1_1.ps1",
    "diagnose_step7_pair001_structural_checker_v0_1.ps1",
    "docs/experiments/cross-system-claim-handoff/CSH_POST_REPAIR_EVIDENCE_ARCHITECTURE_v0_1.md",
    "docs/experiments/cross-system-claim-handoff/FORK_JCS_v0_1.md",
    "docs/governance/FORK_CONTRIBUTOR_INTRODUCTION_CADENCE_v0_1.md",
    "docs/governance/FORK_SCOPED_ENDORSEMENT_MODEL_v0_1.md",
    "docs/governance/FORK_SCOPED_ENDORSEMENT_STANDARDS_LINEAGE_v0_1.md",
    "fixtures/scoped-endorsement/README.md",
    "fixtures/scoped-endorsement/invalid/INVALID-001-SOURCE-NOT-VERIFIED_v0_1.json",
    "fixtures/scoped-endorsement/invalid/INVALID-002-MAPPING-LOCATOR-MISMATCH_v0_1.json",
    "fixtures/scoped-endorsement/invalid/INVALID-003-ENDORSEMENT-DIGEST-MISMATCH_v0_1.json",
    "fixtures/scoped-endorsement/invalid/INVALID-004-NON-INFERENCE-MISSING_v0_1.json",
    "fixtures/scoped-endorsement/invalid/INVALID-005-SILENCE-AS-AUTHORIZATION_v0_1.json",
    "fixtures/scoped-endorsement/invalid/INVALID-006-ACKNOWLEDGMENT-PROMOTED_v0_1.json",
    "fixtures/scoped-endorsement/invalid/INVALID-007-PUBLICATION-WORDING-OVERBROAD_v0_1.json",
    "fixtures/scoped-endorsement/invalid/INVALID-008-REVOKED-ENDORSEMENT_v0_1.json",
    "fixtures/scoped-endorsement/invalid/INVALID-009-AUTHORITY-INHERITANCE_v0_1.json",
    "fixtures/scoped-endorsement/invalid/INVALID-010-PUBLICATION-AS-TRUTH_v0_1.json",
    "fixtures/scoped-endorsement/valid/VALID_001_complete_scoped_mapping_endorsement_v0_1.json",
    "install_fork_scoped_endorsement_v0_1.corrupt.ps1",
    "install_fork_scoped_endorsement_v0_1_3_clean.ps1",
    "install_fork_scoped_endorsement_v0_1_4_ps51_fixed.ps1",
    "manifests/FORK_SCOPED_ENDORSEMENT_SURFACE_v0_1.manifest.json",
    "receipts/csh-evidence-architecture/CSH_EVIDENCE_ARCHITECTURE_INSTALLATION_RECEIPT_v0_1_1.json",
    "receipts/csh-evidence-architecture/CSH_EVIDENCE_ARCHITECTURE_INSTALL_TEST_OUTPUT_v0_1_1.log",
    "receipts/local/RECOMPUTATION_RECEIPT_12c2db8_2026-09-19.json",
    "receipts/local/csh-execution-v0.1.1/CSH_DIFF_REVIEW_20260713T013055Z.json",
    "receipts/local/csh-execution-v0.1.1/CSH_DIFF_REVIEW_20260713T031605Z.json",
    "receipts/local/csh-execution-v0.1.1/CSH_DIFF_REVIEW_20260713T033029Z.json",
    "receipts/local/csh-execution-v0.1.1/CSH_DIFF_REVIEW_20260713T033108Z.json",
    "receipts/local/csh-execution-v0.1.1/CSH_DIFF_REVIEW_20260713T041955Z.json",
    "receipts/local/csh-execution-v0.1.1/CSH_DIFF_REVIEW_20260713T041956Z.json",
    "receipts/local/csh-execution-v0.1.1/CSH_LOCAL_VERIFICATION_20260713T013056Z.json",
    "receipts/local/csh-execution-v0.1.1/CSH_LOCAL_VERIFICATION_20260713T031605Z.json",
    "receipts/local/csh-execution-v0.1.1/CSH_LOCAL_VERIFICATION_20260713T033029Z.json",
    "receipts/local/csh-execution-v0.1.1/CSH_LOCAL_VERIFICATION_20260713T033108Z.json",
    "receipts/local/csh-execution-v0.1.1/CSH_LOCAL_VERIFICATION_20260713T041956Z.json",
    "receipts/local/csh-execution-v0.1.1/CSH_STAGED_PUBLICATION_DIFF_20260713T042030Z.patch",
    "receipts/local/csh-execution-v0.1.1/CSH_V0_1_1_CANDIDATE_NAME_STATUS.txt",
    "receipts/local/csh-execution-v0.1.1/CSH_V0_1_1_CANDIDATE_STAT.txt",
    "receipts/local/csh-execution-v0.1.1/CSH_V0_1_1_DIFF_CHECK_FAILURES.txt",
    "receipts/local/csh-execution-v0.1.1/PAIR_001_SEAL.json",
    "receipts/local/scoped-endorsement/FORK_SCOPED_ENDORSEMENT_INSTALL_RECEIPT_20260712T224136Z.json",
    "receipts/local/scoped-endorsement/FORK_SCOPED_ENDORSEMENT_INSTALL_RECEIPT_20260712T224350Z.json",
    "receipts/local/scoped-endorsement/FORK_SCOPED_ENDORSEMENT_INSTALL_RECEIPT_20260712T224743Z.json",
    "receipts/local/scoped-endorsement/FORK_SCOPED_ENDORSEMENT_INSTALL_RECEIPT_20260712T225849Z.json",
    "receipts/local/scoped-endorsement/FORK_SCOPED_ENDORSEMENT_INSTALL_RECEIPT_20260712T231712Z.json",
    "receipts/local/scoped-endorsement/FORK_SCOPED_ENDORSEMENT_LF_CANONICALIZATION_RECEIPT_20260712T233450Z.json",
    "receipts/local/scoped-endorsement/FORK_SCOPED_ENDORSEMENT_LF_CANONICALIZATION_RECEIPT_20260712T233450Z.json.sha256",
    "receipts/local/scoped-endorsement/precanonical/20260712T233450Z/manifests/FORK_SCOPED_ENDORSEMENT_SURFACE_v0_1.manifest.pre-lf.json",
    "registries/conceptual_mapping_registry_v0_1.json",
    "registries/publication_reliance_registry_v0_1.json",
    "registries/scoped_endorsement_registry_v0_1.json",
    "registries/verified_source_registry_v0_1.json",
    "release_packages/FORK_PAIR_001_PILOT_RELEASE_v0_1/EXPERIMENT_MANIFEST_v0_1_1.json",
    "release_packages/FORK_PAIR_001_PILOT_RELEASE_v0_1/FINAL_RELEASE_RECEIPT.json",
    "release_packages/FORK_PAIR_001_PILOT_RELEASE_v0_1/PARTICIPANT_BINDING_001.json",
    "release_packages/FORK_PAIR_001_PILOT_RELEASE_v0_1/README.md",
    "release_packages/FORK_PAIR_001_PILOT_RELEASE_v0_1/verify_release.py",
    "schemas/conceptual_mapping_record_v0_1.schema.json",
    "schemas/publication_reliance_record_v0_1.schema.json",
    "schemas/scoped_endorsement_record_v0_1.schema.json",
    "schemas/verified_source_record_v0_1.schema.json",
    "tests/test_scoped_endorsement_surface_v0_1.py",
    "tools/assemble_pilot_package.py",
    "tools/check_scoped_endorsement_surface_v0_1.py",
    "tools/run_pair_001_packet_seal.py",
]

print(f"{'PATH':<80} {'SIZE':>8}  SHA256")
print("-" * 150)
for rel in untracked_entries:
    p = WORKTREE / rel
    if not p.exists():
        print(f"{rel:<80} {'ABSENT':>8}  (not a file or does not exist)")
        continue
    if not p.is_file():
        print(f"{rel:<80} {'DIR':>8}  (directory)")
        continue
    data = p.read_bytes()
    size = len(data)
    h = hashlib.sha256(data).hexdigest()
    print(f"{rel:<80} {size:>8}  {h}")
