# SUBSTANTIVE-EXAMINATION-003 — REPAIRED RECEIPT

object_id: SUBSTANTIVE-EXAMINATION-003-FREEZE-001
standing: CLOSED_HISTORICAL_EVIDENCE
repair_class: RECEIPT_ONLY__ZERO_NEW_EXPERIMENT

repository: RecomputableEvidence/fork-public-evidence
target_commit: a8323bd89976c78c5ed14b69f90aa33c5230c9c7
target_tree: c9722ef942a6c8b6bd74a5a6cbdfb22a0199937b

## Executed-case arithmetic repair

original_receipt_mutation_cases_executed: 18
repaired_mutation_cases_executed: 19

count_basis:
  A1-A4: 4
  B_across_four_verifiers: 4
  C_across_two_verifiers: 2
  D_across_two_verifiers: 2
  E1-E3: 3
  F1-F4: 4
  total: 19

new_experiments_introduced_by_repair: 0
new_mutation_cases_introduced_by_repair: 0
new_verifier_executions_introduced_by_repair: 0

## Harness identity

executed_harness_original_local_path:
C:\N\SE003-EXAMINER-HARNESS\se003_tests.py

original_local_path_current_state:
PLACEHOLDER_ONLY

original_local_path_current_size_bytes:
18

original_local_path_current_sha256:
6f51d658b38d0c85cca972ed280dd6474234704cf6188b50cb4ea4ab1cac66ef

conversation_preserved_executed_harness:
SE003-CONVERSATION-ARCHIVED-HARNESS.py

conversation_preserved_harness_size_bytes:
23886

conversation_preserved_harness_sha256:
5669d9291799a430398adbae6dd83ad3831572887f2d7375cf7808d50149070c

harness_provenance_class:
CONVERSATION_PRESERVED_COPY__NOT_CLAIMED_AS_ORIGINAL_FILESYSTEM_INSTANCE

## Raw execution log

raw_execution_log_separate_file:
NOT_FOUND_IN_SEARCHED_LOCATIONS

search_evidence:
SE003-EVIDENCE-LOCATOR-OUTPUT.txt

search_evidence_sha256:
0df0657eed4263da716ed7b1b9dd84a7c5666d04d6d2927aa3b736d677e67f4a

raw_execution_log_sha256:
NOT_AVAILABLE

raw_execution_log_bytes:
NOT_PRESERVED_AS_SEPARATE_DISCOVERED_FILE

important_boundary:
The narrative examination report is not relabeled or substituted as a raw execution log.

absence_scope:
The locator searched the declared local roots and execution-time window.
This establishes non-discovery within that bounded search, not universal proof that no copy exists elsewhere.

## Narrative report

narrative_report_sha256:
452133af9d2b40a22d6a4c539f7a94eadeb38f0f07d0fa860cefe9ef2953ce2a

narrative_report_size_bytes:
40637

## Phase-0 instrumentation

phase0_hash_py_sha256:
0f09c3bd66059db58b1178e8fe50d9308fdc3c6a86956ee9e5d5d05b569a1364

## Admission-surface boundary

discovered_executable_admission_verifier_count:
4

global_admission_mechanism_count_proven:
NO

## Baseline execution boundary

baseline_verifiers_passed:
4

baseline_meaning:
The four discovered verifier programs returned exit code 0 against their then-current package bytes at the target coordinate.

baseline_does_not_establish:
  - fresh reproduction of predecessor experiments
  - historical authenticity
  - historical authorship
  - independent review
  - originating-event validity

## Byte-closure boundary

selected_declared_byte_bindings_checked_at_R2:
YES

complete_package_byte_closure:
NOT_ESTABLISHED

actual_filesystem_population_closure:
NOT_ESTABLISHED

## Test-C boundary

unknown_field_acceptance_executed_scope:
LENS-SHIFT_TEST_C; UEM-CRII_TEST_C

general_schema_conformance_enforcement:
NOT_ESTABLISHED

## Test-D boundary

duplicate_key_acceptance_executed_scope:
LENS-SHIFT_TEST_D; UEM-CRII_TEST_D

duplicate_key_behavior_other_verifiers:
NOT_EXECUTED

first_last_ordering_consequences_beyond_executed_cases:
UNRESOLVED

## Test-E boundary

path_traversal_acceptance_executed_scope:
LENS-SHIFT_TEST_E1; UEM-CRII_TEST_E2; STACKED_TEST_E3

vos_equivalent_path_traversal_test:
NOT_EXECUTED

deployment_exploitability:
NOT_ESTABLISHED

## Test-F boundary

selected_state_or_boundary_predicates_executed:
  VOS-E002: execution_state
  LENS-SHIFT: semantic_repair_warranted
  UEM-CRII: disposition
  STACKED: admission_state

literal_admission_state_enforcement_directly_executed:
STACKED_ONLY

general_semantic_nonpromotion_enforcement:
NOT_ESTABLISHED

## Historical/current distinction

historical_results_recomputed:
NO

historical_results_independently_reproduced:
NO

predecessor_mechanisms_reexecuted:
NO

independent_reimplementation_performed:
NO

highest_recomputation_depth:
R2

FREEZE-002:
CLOSED_HISTORICAL_EVIDENCE__NOT_TOUCHED__NOT_REEXECUTED__NOT_EXTENDED