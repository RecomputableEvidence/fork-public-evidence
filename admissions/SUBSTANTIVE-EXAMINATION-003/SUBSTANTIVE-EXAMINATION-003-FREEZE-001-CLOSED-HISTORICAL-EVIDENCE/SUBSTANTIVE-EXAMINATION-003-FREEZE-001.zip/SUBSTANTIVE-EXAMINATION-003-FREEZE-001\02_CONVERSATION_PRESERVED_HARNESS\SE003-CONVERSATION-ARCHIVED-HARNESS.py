"""
SE-003 Phase 5: Discriminating tests A-F.
All mutations in TemporaryDirectory copies.
Control worktree is NEVER modified.
"""
import hashlib, json, re, shutil, subprocess, sys, tempfile
from pathlib import Path
from collections import Counter

BASE = Path(r'C:\N\fork-public-evidence-recompute-control')
HARNESS = Path(r'C:\N\SE003-EXAMINER-HARNESS')

VERIFIERS = {
    'VOS-E002': BASE / 'scripts' / 'check_vos_e002_admission_001.py',
    'LENS-SHIFT': BASE / 'admissions' / 'LENS-SHIFT-v0.1' / 'BLIND-EPOCH-003' / 'verify_admission.py',
    'UEM-CRII': BASE / 'admissions' / 'UEM-v0.1' / 'EPOCH-010-CRII' / 'verify_admission.py',
    'STACKED': BASE / 'admissions' / 'FORK-STACKED-CADENCE-BOUNDED-R&D-001' / 'v0.1.5-QUALIFIED-FREEZE' / 'verify_admission.py',
}

ADMISSION_DIRS = {
    'VOS-E002': BASE / 'admissions' / 'FORK-VOS-001' / 'E002',
    'LENS-SHIFT': BASE / 'admissions' / 'LENS-SHIFT-v0.1' / 'BLIND-EPOCH-003',
    'UEM-CRII': BASE / 'admissions' / 'UEM-v0.1' / 'EPOCH-010-CRII',
    'STACKED': BASE / 'admissions' / 'FORK-STACKED-CADENCE-BOUNDED-R&D-001' / 'v0.1.5-QUALIFIED-FREEZE',
}

SCRIPTS_DIR = {
    'VOS-E002': BASE / 'scripts',
    'LENS-SHIFT': BASE / 'admissions' / 'LENS-SHIFT-v0.1' / 'BLIND-EPOCH-003',
    'UEM-CRII': BASE / 'admissions' / 'UEM-v0.1' / 'EPOCH-010-CRII',
    'STACKED': BASE / 'admissions' / 'FORK-STACKED-CADENCE-BOUNDED-R&D-001' / 'v0.1.5-QUALIFIED-FREEZE',
}


def sha256(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def run_verifier(verifier_path: Path, cwd: Path) -> tuple[int, str, str]:
    r = subprocess.run([sys.executable, str(verifier_path)],
                       capture_output=True, text=True, cwd=str(cwd))
    return r.returncode, r.stdout, r.stderr


def print_result(test_id: str, verifier: str, rc: int, stdout: str, stderr: str, note: str = '') -> None:
    result = 'PASS' if rc == 0 else ('FAIL' if rc == 1 else f'EXIT_{rc}')
    detected = 'DETECTED(FAIL/ERR)' if rc != 0 else 'NOT_DETECTED(PASS)'
    print(f'[{test_id}][{verifier}] EXIT:{rc} -> {result} -> {detected}')
    if note:
        print(f'  NOTE: {note}')
    for line in (stdout + stderr).strip().splitlines():
        print(f'  {line}')
    print()


# ── TEST A: Missing checksum-only file ─────────────────────────────────────────
# VOS-E002 uses verify_sums(d) where: if p.is_file() and sha(p)!=h: fail(...)
# If p does NOT exist → p.is_file() is False → condition skips → NO FAIL
# This is the critical predicate: missing files silently skip in VOS-E002
# LENS-SHIFT / UEM use: if not path.is_file(): fail(...)
# STACKED uses: if not p.is_file() or sha(p)!=d: fail(...)
# So VOS-E002 has the silent-skip pattern; others have explicit missing-file check

print("=" * 70)
print("TEST A: MISSING FILE — CHECKSUM SKIP vs EXPLICIT CHECK")
print("=" * 70)

# Test A1: VOS-E002 — delete a checksum-listed file from confirmatory-closeout-001
with tempfile.TemporaryDirectory() as td:
    # Copy whole BASE tree minimally needed
    repo_copy = Path(td) / 'repo'
    shutil.copytree(str(BASE / 'admissions' / 'FORK-VOS-001'), str(repo_copy / 'admissions' / 'FORK-VOS-001'))
    shutil.copy(str(VERIFIERS['VOS-E002']), str(repo_copy / 'check_vos_e002_admission_001.py'))
    # Also copy the admission candidate files needed by the verifier
    for f in ['FORK-VOS-001-E002-REPOSITORY-ADMISSION-CANDIDATE-001.json',
              'FORK-VOS-001-E002-REPOSITORY-BYTE-BINDINGS-001.json']:
        src = BASE / 'admissions' / 'FORK-VOS-001' / 'E002' / f
        if src.exists():
            pass  # already copied via copytree

    e002_dir = repo_copy / 'admissions' / 'FORK-VOS-001' / 'E002'
    # Delete a non-critical file from confirmatory-closeout-001 that IS in SHA256SUMS
    closeout_sums = e002_dir / 'confirmatory-closeout-001' / 'SHA256SUMS'
    sums_content = closeout_sums.read_text()
    print('VOS-E002 confirmatory-closeout SHA256SUMS entries:')
    for line in sums_content.splitlines():
        if line.strip():
            print(f'  {line}')
    # Delete first listed file
    first_file_name = None
    for line in sums_content.splitlines():
        if line.strip() and re.match(r'^[0-9a-f]{64}', line.strip()):
            _, first_file_name = line.strip().split(None, 1)
            break
    if first_file_name:
        target_file = e002_dir / 'confirmatory-closeout-001' / first_file_name
        print(f'\nDeleting: {first_file_name} (exists: {target_file.exists()})')
        target_file.unlink()

        # Run verifier from the scripts directory equivalent
        verifier_copy = repo_copy / 'check_vos_e002_admission_001.py'
        # The verifier uses ROOT=Path(__file__).resolve().parents[1] relative to scripts/
        # We need to put it in the right place. Copy to repo_copy/scripts/
        scripts_copy = repo_copy / 'scripts'
        scripts_copy.mkdir(exist_ok=True)
        verifier_path = scripts_copy / 'check_vos_e002_admission_001.py'
        shutil.copy(str(VERIFIERS['VOS-E002']), str(verifier_path))

        rc, out, err = run_verifier(verifier_path, scripts_copy)
        print_result('A1', 'VOS-E002', rc, out, err,
                     f'Deleted {first_file_name} from confirmatory-closeout-001 (still in SHA256SUMS)')
        print(f'  PREDICATE ANALYSIS: VOS verify_sums: "if p.is_file() and sha(p)!=h: fail"')
        print(f'  Missing file -> is_file()=False -> CONDITION SKIPPED -> NO FAIL TRIGGERED')
        print()

# Test A2: LENS-SHIFT — delete a checksum-listed file  
with tempfile.TemporaryDirectory() as td:
    pkg = Path(td) / 'BLIND-EPOCH-003'
    shutil.copytree(str(ADMISSION_DIRS['LENS-SHIFT']), str(pkg))
    sums = {}
    for line in (pkg / 'SHA256SUMS.txt').read_text(encoding='utf-8').splitlines():
        d, n = line.split('  ', 1)
        sums[n] = d
    # Delete first non-verifier file
    del_name = None
    for n in sums:
        if 'verify_admission' not in n:
            del_name = n
            break
    if del_name:
        (pkg / del_name).unlink()
        rc, out, err = run_verifier(pkg / 'verify_admission.py', pkg)
        print_result('A2', 'LENS-SHIFT', rc, out, err,
                     f'Deleted {del_name} (explicit fail: "if not path.is_file(): fail")')

# Test A3: UEM-CRII — delete a checksum-listed file
with tempfile.TemporaryDirectory() as td:
    pkg = Path(td) / 'EPOCH-010-CRII'
    shutil.copytree(str(ADMISSION_DIRS['UEM-CRII']), str(pkg))
    sums = {}
    for line in (pkg / 'SHA256SUMS.txt').read_text(encoding='utf-8').splitlines():
        d, n = line.split('  ', 1)
        sums[n] = d
    del_name = None
    for n in sums:
        if 'verify_admission' not in n:
            del_name = n
            break
    if del_name:
        (pkg / del_name).unlink()
        rc, out, err = run_verifier(pkg / 'verify_admission.py', pkg)
        print_result('A3', 'UEM-CRII', rc, out, err,
                     f'Deleted {del_name} (explicit fail on is_file())')

# Test A4: STACKED — delete a checksum-listed file
with tempfile.TemporaryDirectory() as td:
    pkg = Path(td) / 'STACKED'
    shutil.copytree(str(ADMISSION_DIRS['STACKED']), str(pkg))
    sums = {}
    for line in (pkg / 'SHA256SUMS.txt').read_text(encoding='utf-8').splitlines():
        if line.strip():
            d, n = line.split('  ', 1)
            sums[n] = d
    del_name = None
    for n in sums:
        if 'verify_admission' not in n and 'SHA256SUMS' not in n:
            del_name = n
            break
    if del_name:
        target = pkg / del_name
        if target.exists():
            target.unlink()
        rc, out, err = run_verifier(pkg / 'verify_admission.py', pkg)
        print_result('A4', 'STACKED', rc, out, err,
                     f'Deleted {del_name} (STACKED: "if not p.is_file() or sha(p)!=d: fail")')


# ── TEST B: Extra undeclared file ──────────────────────────────────────────────
print("=" * 70)
print("TEST B: EXTRA UNDECLARED FILE")
print("=" * 70)

for vname in ['LENS-SHIFT', 'UEM-CRII', 'STACKED']:
    with tempfile.TemporaryDirectory() as td:
        pkg = Path(td) / vname
        shutil.copytree(str(ADMISSION_DIRS[vname]), str(pkg))
        extra = pkg / 'undeclared_examiner_artifact.txt'
        extra.write_text('harmless extra file for SE-003 test B', encoding='utf-8')
        rc, out, err = run_verifier(pkg / 'verify_admission.py', pkg)
        print_result(f'B_{vname}', vname, rc, out, err,
                     'undeclared_examiner_artifact.txt added; no change to declared files')

# VOS-E002 special: extra file in subdirectory
with tempfile.TemporaryDirectory() as td:
    repo_copy = Path(td) / 'repo'
    shutil.copytree(str(BASE / 'admissions' / 'FORK-VOS-001'), str(repo_copy / 'admissions' / 'FORK-VOS-001'))
    e002_dir = repo_copy / 'admissions' / 'FORK-VOS-001' / 'E002'
    extra = e002_dir / 'confirmatory-closeout-001' / 'undeclared_extra.txt'
    extra.write_text('harmless extra file')
    scripts_copy = repo_copy / 'scripts'
    scripts_copy.mkdir(exist_ok=True)
    verifier_path = scripts_copy / 'check_vos_e002_admission_001.py'
    shutil.copy(str(VERIFIERS['VOS-E002']), str(verifier_path))
    rc, out, err = run_verifier(verifier_path, scripts_copy)
    print_result('B_VOS-E002', 'VOS-E002', rc, out, err,
                 'undeclared_extra.txt added to confirmatory-closeout-001')


# ── TEST C: Unknown semantic field ─────────────────────────────────────────────
print("=" * 70)
print("TEST C: UNKNOWN JSON FIELD IN CONSUMED OBJECT")
print("=" * 70)

# LENS-SHIFT: BLIND-EPOCH-003-CLOSURE-VERIFICATION.json is consumed
with tempfile.TemporaryDirectory() as td:
    pkg = Path(td) / 'BLIND-EPOCH-003'
    shutil.copytree(str(ADMISSION_DIRS['LENS-SHIFT']), str(pkg))
    closure_path = pkg / 'BLIND-EPOCH-003-CLOSURE-VERIFICATION.json'
    closure = json.loads(closure_path.read_text(encoding='utf-8'))
    closure['UNKNOWN_EXAMINER_FIELD_XYZ'] = 'SE-003 test injection'
    closure_path.write_text(json.dumps(closure, indent=2, ensure_ascii=False), encoding='utf-8')
    # Reseal: update SHA256SUMS.txt for this file
    sums_path = pkg / 'SHA256SUMS.txt'
    sums = {}
    for line in sums_path.read_text(encoding='utf-8').splitlines():
        d, n = line.split('  ', 1)
        sums[n] = d
    sums['BLIND-EPOCH-003-CLOSURE-VERIFICATION.json'] = sha256(closure_path)
    sums_path.write_text('\n'.join(f'{v}  {k}' for k, v in sums.items()) + '\n', encoding='utf-8')
    rc, out, err = run_verifier(pkg / 'verify_admission.py', pkg)
    print_result('C_LENS', 'LENS-SHIFT', rc, out, err,
                 'UNKNOWN_EXAMINER_FIELD_XYZ added to closure JSON (resealed SHA256SUMS)')

# UEM-CRII: EXECUTOR_RESULTS.json consumed
with tempfile.TemporaryDirectory() as td:
    pkg = Path(td) / 'EPOCH-010-CRII'
    shutil.copytree(str(ADMISSION_DIRS['UEM-CRII']), str(pkg))
    exec_path = pkg / 'EXECUTOR_RESULTS.json'
    er = json.loads(exec_path.read_text(encoding='utf-8'))
    er['UNKNOWN_EXAMINER_FIELD'] = 'SE-003 test C injection'
    exec_path.write_text(json.dumps(er, indent=2, ensure_ascii=False), encoding='utf-8')
    # Reseal SHA256SUMS.txt and REPRODUCED_VERIFICATION_RECEIPT.json
    sums_path = pkg / 'SHA256SUMS.txt'
    sums = {}
    for line in sums_path.read_text(encoding='utf-8').splitlines():
        d, n = line.split('  ', 1)
        sums[n] = d
    sums['EXECUTOR_RESULTS.json'] = sha256(exec_path)
    sums_path.write_text('\n'.join(f'{v}  {k}' for k, v in sums.items()) + '\n', encoding='utf-8')
    # Also update the receipt's binding hash for executor_results
    receipt_path = pkg / 'REPRODUCED_VERIFICATION_RECEIPT.json'
    receipt = json.loads(receipt_path.read_text(encoding='utf-8'))
    receipt['binding']['executor_results_sha256'] = sha256(exec_path)
    receipt_path.write_text(json.dumps(receipt, indent=2, ensure_ascii=False), encoding='utf-8')
    sums['REPRODUCED_VERIFICATION_RECEIPT.json'] = sha256(receipt_path)
    sums_path.write_text('\n'.join(f'{v}  {k}' for k, v in sums.items()) + '\n', encoding='utf-8')
    rc, out, err = run_verifier(pkg / 'verify_admission.py', pkg)
    print_result('C_UEM', 'UEM-CRII', rc, out, err,
                 'UNKNOWN_EXAMINER_FIELD added to EXECUTOR_RESULTS.json (resealed)')


# ── TEST D: Duplicate JSON key ──────────────────────────────────────────────────
print("=" * 70)
print("TEST D: DUPLICATE JSON KEY")
print("=" * 70)

# UEM-CRII: duplicate "epoch" key in EXECUTOR_RESULTS.json
with tempfile.TemporaryDirectory() as td:
    pkg = Path(td) / 'EPOCH-010-CRII'
    shutil.copytree(str(ADMISSION_DIRS['UEM-CRII']), str(pkg))
    exec_path = pkg / 'EXECUTOR_RESULTS.json'
    raw = exec_path.read_text(encoding='utf-8')
    # Parse original epoch value
    er = json.loads(raw)
    orig_epoch = er.get('epoch')
    # Inject duplicate key with wrong value BEFORE the real one
    dup_raw = raw.replace('{', '{"epoch": "INJECTED_WRONG_EPOCH_VALUE", ', 1)
    exec_path.write_text(dup_raw, encoding='utf-8')
    # What does Python parse?
    parsed = json.loads(dup_raw)
    # Reseal
    sums_path = pkg / 'SHA256SUMS.txt'
    sums = {}
    for line in sums_path.read_text(encoding='utf-8').splitlines():
        d, n = line.split('  ', 1)
        sums[n] = d
    sums['EXECUTOR_RESULTS.json'] = sha256(exec_path)
    sums_path.write_text('\n'.join(f'{v}  {k}' for k, v in sums.items()) + '\n', encoding='utf-8')
    # Also update receipt binding
    receipt_path = pkg / 'REPRODUCED_VERIFICATION_RECEIPT.json'
    receipt = json.loads(receipt_path.read_text(encoding='utf-8'))
    receipt['binding']['executor_results_sha256'] = sha256(exec_path)
    receipt_path.write_text(json.dumps(receipt, indent=2, ensure_ascii=False), encoding='utf-8')
    sums['REPRODUCED_VERIFICATION_RECEIPT.json'] = sha256(receipt_path)
    sums_path.write_text('\n'.join(f'{v}  {k}' for k, v in sums.items()) + '\n', encoding='utf-8')
    rc, out, err = run_verifier(pkg / 'verify_admission.py', pkg)
    print_result('D_UEM', 'UEM-CRII', rc, out, err,
                 f'Duplicate "epoch" key: first="INJECTED_WRONG_EPOCH_VALUE", second="{orig_epoch}"; Python parsed: "{parsed.get("epoch")}"')
    print(f'  DUPLICATE_KEY_BEHAVIOR: first_wins={parsed.get("epoch") == "INJECTED_WRONG_EPOCH_VALUE"}')
    print(f'  last_wins={parsed.get("epoch") == orig_epoch}')
    print()

# LENS-SHIFT: duplicate key in closure JSON
with tempfile.TemporaryDirectory() as td:
    pkg = Path(td) / 'BLIND-EPOCH-003'
    shutil.copytree(str(ADMISSION_DIRS['LENS-SHIFT']), str(pkg))
    closure_path = pkg / 'BLIND-EPOCH-003-CLOSURE-VERIFICATION.json'
    raw = closure_path.read_text(encoding='utf-8')
    closure = json.loads(raw)
    orig_standing = closure.get('standing', {})
    # Inject wrong "standing" FIRST, real one stays (last-wins expected)
    dup_raw = raw.replace('{', '{"standing": "WRONG_VALUE_FIRST", ', 1)
    closure_path.write_text(dup_raw, encoding='utf-8')
    parsed = json.loads(dup_raw)
    sums_path = pkg / 'SHA256SUMS.txt'
    sums = {}
    for line in sums_path.read_text(encoding='utf-8').splitlines():
        d, n = line.split('  ', 1)
        sums[n] = d
    sums['BLIND-EPOCH-003-CLOSURE-VERIFICATION.json'] = sha256(closure_path)
    sums_path.write_text('\n'.join(f'{v}  {k}' for k, v in sums.items()) + '\n', encoding='utf-8')
    rc, out, err = run_verifier(pkg / 'verify_admission.py', pkg)
    print_result('D_LENS', 'LENS-SHIFT', rc, out, err,
                 f'Duplicate "standing" key in closure JSON; Python parsed standing: {type(parsed.get("standing")).__name__}={repr(str(parsed.get("standing"))[:50])}')


# ── TEST E: Path containment ───────────────────────────────────────────────────
print("=" * 70)
print("TEST E: PATH CONTAINMENT")
print("=" * 70)

# LENS-SHIFT SHA256SUMS.txt: inject ../traversal path
with tempfile.TemporaryDirectory() as outer:
    outer_path = Path(outer)
    outside = outer_path / 'harmless_outside.txt'
    outside.write_text('harmless content outside admission dir')
    outside_hash = sha256(outside)

    pkg = outer_path / 'BLIND-EPOCH-003'
    shutil.copytree(str(ADMISSION_DIRS['LENS-SHIFT']), str(pkg))
    sums_path = pkg / 'SHA256SUMS.txt'
    existing = sums_path.read_text(encoding='utf-8').strip()
    sums_path.write_text(existing + f'\n{outside_hash}  ../harmless_outside.txt\n', encoding='utf-8')
    rc, out, err = run_verifier(pkg / 'verify_admission.py', pkg)
    print_result('E1_LENS_TRAVERSAL', 'LENS-SHIFT', rc, out, err,
                 '../harmless_outside.txt with correct hash injected into SHA256SUMS.txt')

# UEM-CRII SHA256SUMS.txt: inject ../traversal path
with tempfile.TemporaryDirectory() as outer:
    outer_path = Path(outer)
    outside = outer_path / 'harmless_uem_outside.txt'
    outside.write_text('harmless content outside UEM admission dir')
    outside_hash = sha256(outside)

    pkg = outer_path / 'EPOCH-010-CRII'
    shutil.copytree(str(ADMISSION_DIRS['UEM-CRII']), str(pkg))
    sums_path = pkg / 'SHA256SUMS.txt'
    existing = sums_path.read_text(encoding='utf-8').strip()
    sums_path.write_text(existing + f'\n{outside_hash}  ../harmless_uem_outside.txt\n', encoding='utf-8')
    rc, out, err = run_verifier(pkg / 'verify_admission.py', pkg)
    print_result('E2_UEM_TRAVERSAL', 'UEM-CRII', rc, out, err,
                 '../harmless_uem_outside.txt with correct hash injected into SHA256SUMS.txt')

# STACKED SHA256SUMS.txt: inject ../traversal
with tempfile.TemporaryDirectory() as outer:
    outer_path = Path(outer)
    outside = outer_path / 'harmless_stacked_outside.txt'
    outside.write_text('harmless content outside STACKED admission dir')
    outside_hash = sha256(outside)

    pkg = outer_path / 'STACKED'
    shutil.copytree(str(ADMISSION_DIRS['STACKED']), str(pkg))
    sums_path = pkg / 'SHA256SUMS.txt'
    existing = sums_path.read_text(encoding='utf-8').strip()
    sums_path.write_text(existing + f'\n{outside_hash}  ../harmless_stacked_outside.txt\n', encoding='utf-8')
    rc, out, err = run_verifier(pkg / 'verify_admission.py', pkg)
    print_result('E3_STACKED_TRAVERSAL', 'STACKED', rc, out, err,
                 '../harmless_stacked_outside.txt with correct hash injected into SHA256SUMS.txt')


# ── TEST F: Admission-state field enforcement ───────────────────────────────────
print("=" * 70)
print("TEST F: ADMISSION-STATE FIELD ENFORCEMENT")
print("=" * 70)

# VOS-E002: execution_state field
with tempfile.TemporaryDirectory() as td:
    repo_copy = Path(td) / 'repo'
    shutil.copytree(str(BASE / 'admissions' / 'FORK-VOS-001'), str(repo_copy / 'admissions' / 'FORK-VOS-001'))
    e002_dir = repo_copy / 'admissions' / 'FORK-VOS-001' / 'E002'
    cand_path = e002_dir / 'FORK-VOS-001-E002-REPOSITORY-ADMISSION-CANDIDATE-001.json'
    cand = json.loads(cand_path.read_text(encoding='utf-8'))
    orig_exec_state = cand.get('execution_state')
    cand['execution_state'] = 'SOME_OTHER_STATE'
    cand_path.write_text(json.dumps(cand, indent=2, ensure_ascii=False), encoding='utf-8')
    # The VOS verifier does NOT verify SHA256SUMS on the top-level E002 dir files
    # (only on subdirs). So no reseal needed.
    scripts_copy = repo_copy / 'scripts'
    scripts_copy.mkdir(exist_ok=True)
    vpath = scripts_copy / 'check_vos_e002_admission_001.py'
    shutil.copy(str(VERIFIERS['VOS-E002']), str(vpath))
    rc, out, err = run_verifier(vpath, scripts_copy)
    print_result('F1_VOS_EXECSTATE', 'VOS-E002', rc, out, err,
                 f'execution_state: {repr(orig_exec_state)} -> "SOME_OTHER_STATE" (no reseal needed - not in subdirectory SHA256SUMS)')

# LENS-SHIFT: candidate semantic_repair_warranted field
with tempfile.TemporaryDirectory() as td:
    pkg = Path(td) / 'BLIND-EPOCH-003'
    shutil.copytree(str(ADMISSION_DIRS['LENS-SHIFT']), str(pkg))
    cand_path = pkg / 'LENS-SHIFT-v0.1-BLIND-EPOCH-003-REPOSITORY-ADMISSION-CANDIDATE-001.json'
    cand = json.loads(cand_path.read_text(encoding='utf-8'))
    orig_val = cand.get('semantic_repair_warranted')
    cand['semantic_repair_warranted'] = True  # change False -> True
    cand_path.write_text(json.dumps(cand, indent=2, ensure_ascii=False), encoding='utf-8')
    sums_path = pkg / 'SHA256SUMS.txt'
    sums = {}
    for line in sums_path.read_text(encoding='utf-8').splitlines():
        d, n = line.split('  ', 1)
        sums[n] = d
    sums[cand_path.name] = sha256(cand_path)
    sums_path.write_text('\n'.join(f'{v}  {k}' for k, v in sums.items()) + '\n', encoding='utf-8')
    rc, out, err = run_verifier(pkg / 'verify_admission.py', pkg)
    print_result('F2_LENS_REPAIR_FLAG', 'LENS-SHIFT', rc, out, err,
                 f'semantic_repair_warranted: {orig_val} -> True (resealed)')

# UEM-CRII: candidate disposition field
with tempfile.TemporaryDirectory() as td:
    pkg = Path(td) / 'EPOCH-010-CRII'
    shutil.copytree(str(ADMISSION_DIRS['UEM-CRII']), str(pkg))
    cand_path = pkg / 'UEM-v0.1-EPOCH-010-CRII-REPOSITORY-ADMISSION-CANDIDATE-001.json'
    cand = json.loads(cand_path.read_text(encoding='utf-8'))
    orig_disp = cand.get('disposition')
    cand['disposition'] = 'SOME_OTHER_DISPOSITION'
    cand_path.write_text(json.dumps(cand, indent=2, ensure_ascii=False), encoding='utf-8')
    sums_path = pkg / 'SHA256SUMS.txt'
    sums = {}
    for line in sums_path.read_text(encoding='utf-8').splitlines():
        d, n = line.split('  ', 1)
        sums[n] = d
    sums[cand_path.name] = sha256(cand_path)
    sums_path.write_text('\n'.join(f'{v}  {k}' for k, v in sums.items()) + '\n', encoding='utf-8')
    rc, out, err = run_verifier(pkg / 'verify_admission.py', pkg)
    print_result('F3_UEM_DISPOSITION', 'UEM-CRII', rc, out, err,
                 f'disposition: {repr(orig_disp)} -> "SOME_OTHER_DISPOSITION" (resealed)')

# STACKED: candidate admission_state field
with tempfile.TemporaryDirectory() as td:
    pkg = Path(td) / 'STACKED'
    shutil.copytree(str(ADMISSION_DIRS['STACKED']), str(pkg))
    cand_path = pkg / 'FORK-STACKED-CADENCE-v0.1.5-REPOSITORY-ADMISSION-CANDIDATE-001.json'
    cand = json.loads(cand_path.read_text(encoding='utf-8'))
    orig_state = cand.get('admission_state')
    cand['admission_state'] = 'FULLY_ADMITTED_AND_AUTHORIZED'
    cand_path.write_text(json.dumps(cand, indent=2, ensure_ascii=False), encoding='utf-8')
    sums_path = pkg / 'SHA256SUMS.txt'
    sums = {}
    for line in sums_path.read_text(encoding='utf-8').splitlines():
        if line.strip():
            d, n = line.split('  ', 1)
            sums[n] = d
    sums[cand_path.name] = sha256(cand_path)
    sums_path.write_text('\n'.join(f'{v}  {k}' for k, v in sums.items()) + '\n', encoding='utf-8')
    rc, out, err = run_verifier(pkg / 'verify_admission.py', pkg)
    print_result('F4_STACKED_ADMSTATE', 'STACKED', rc, out, err,
                 f'admission_state: {repr(orig_state)} -> "FULLY_ADMITTED_AND_AUTHORIZED" (resealed)')

print("=" * 70)
print("HARNESS COMPLETE")
print("=" * 70)
