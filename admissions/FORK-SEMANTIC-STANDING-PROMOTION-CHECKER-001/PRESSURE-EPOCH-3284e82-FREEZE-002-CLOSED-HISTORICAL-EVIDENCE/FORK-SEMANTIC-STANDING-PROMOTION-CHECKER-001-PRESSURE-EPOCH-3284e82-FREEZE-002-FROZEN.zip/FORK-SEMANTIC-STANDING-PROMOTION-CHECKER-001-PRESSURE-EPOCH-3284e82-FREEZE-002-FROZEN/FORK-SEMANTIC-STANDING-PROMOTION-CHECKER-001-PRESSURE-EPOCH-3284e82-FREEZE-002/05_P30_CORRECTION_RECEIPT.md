# P-30 Correction Receipt

## Corrected condition

The source contains the same fragment twice:

```python
repeated = "G01-G09 passed; v0.1.5 is now qualified."
source_text = repeated + "\n" + repeated
```

The sidecar `exact_text` is then overridden to `repeated` only, so the same assertion fragment genuinely occurs at two source offsets.

Observed bounded result:

- `overall_action = PASS`
- exactly one finding for one supplied assertion
- no fabricated second assertion binding

Establishes:

`SAME_EXACT_TEXT_PRESENT_MULTIPLE_TIMES -> CHECKER_DOES_NOT_FABRICATE_MULTIPLE_ASSERTION_BINDINGS`

Does not establish:

- `OCCURRENCE_IDENTITY_ESTABLISHED`
- `DUPLICATE_OCCURRENCE_AMBIGUITY_RESOLVED`

Open boundary:

`TEXT_OCCURRENCE_FOUND != OCCURRENCE_IDENTITY_BOUND`
