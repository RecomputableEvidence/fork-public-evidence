import argparse
import hashlib
import json
import platform
import subprocess
import sys
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path


RULESET_ID = "FORK-RRD-001-AG4-EVAL-v0.1"

STATUSES = [
    "SUPPORTED",
    "CONTRADICTED",
    "UNRESOLVED",
    "INSUFFICIENT_EVIDENCE",
    "NOT_EVALUATED",
    "OUT_OF_SCOPE",
]


def load_json(path):
    with path.open("r", encoding="utf-8-sig") as f:
        return json.load(f)


def sha256_file(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def local_git_blob_sha1(path):
    data = path.read_bytes()
    header = f"blob {len(data)}\0".encode("ascii")
    return hashlib.sha1(header + data).hexdigest()


def git(repo, *args):
    return subprocess.check_output(
        ["git", "-C", str(repo), *args],
        text=True,
        encoding="utf-8",
    ).strip()


p = argparse.ArgumentParser()

p.add_argument("--repo", required=True)
p.add_argument("--packet-root", required=True)
p.add_argument("--artifact", required=True)
p.add_argument("--ag4-commit", required=True)
p.add_argument("--ag3-commit", required=True)
p.add_argument("--out", required=True)

a = p.parse_args()

repo = Path(a.repo).resolve()
packet_root = Path(a.packet_root).resolve()
artifact = Path(a.artifact).resolve()
out = Path(a.out).resolve()

base_rel = Path("research/fork-relational-resolution-demonstration-001")
obj = packet_root / base_rel

ag0_path = obj / "AG0_QUESTION_FREEZE.md"
ag1_path = obj / "CAPTURE_001_AG1_ARTIFACT_IDENTITY_ATTEMPT_002.json"
ag2_path = obj / "CAPTURE_001_AG2_SOURCE_OBSERVATION_SET.json"
ag3_path = obj / "CAPTURE_001_AG3_RELATION_EDGE_OBJECTS.json"
ag4_path = obj / "CAPTURE_001_AG4_DIMENSIONAL_EVALUATION.json"

for path in (ag0_path, ag1_path, ag2_path, ag3_path, ag4_path):
    if not path.is_file():
        raise RuntimeError(f"Missing packet file: {path}")


# ============================================================
# PHASE A
#
# Load AG0–AG3 evidence.
# DO NOT read AG4 recorded results yet.
# ============================================================

ag0_text = ag0_path.read_text(encoding="utf-8-sig")
ag1 = load_json(ag1_path)
ag2 = load_json(ag2_path)
ag3 = load_json(ag3_path)

obs = {
    x["observation_id"]: x
    for x in ag2["source_observations"]
}

edges = {
    x["edge_id"]: x
    for x in ag3["edge_objects"]
}

required_edges = [f"AG3-E{i:02d}" for i in range(1, 10)]

if sorted(edges) != required_edges:
    raise RuntimeError(
        f"Unexpected AG3 edge population: {sorted(edges)}"
    )


# ============================================================
# Recompute target artifact identity from local bytes
# ============================================================

artifact_name = artifact.name
artifact_size = artifact.stat().st_size
artifact_sha = sha256_file(artifact)

expected_name = ag1["acquisition"]["observed_filename"]
expected_size = ag1["locally_observed_identity"]["byte_length"]
expected_sha = ag1["locally_observed_identity"]["sha256"]

artifact_identity_match = (
    artifact_name == expected_name
    and artifact_size == expected_size
    and artifact_sha == expected_sha
)


# ============================================================
# Derive all nine edge statuses without reading AG4 result file
# ============================================================

computed = {}


def assign(edge_id, status, basis):
    if status not in STATUSES:
        raise RuntimeError(f"Illegal status: {status}")

    computed[edge_id] = {
        "edge_id": edge_id,
        "edge_type": edges[edge_id]["edge_type"],
        "status": status,
        "recomputation_basis": basis,
    }


# E01 --------------------------------------------------------

so1 = obs["AG2-SO-001"]
so2 = obs["AG2-SO-002"]["observed_fields"]

release_lists_asset = (
    so1["release_body_observation"]["target_asset_listed"] is True
)

release_asset_matches = (
    so2["name"] == artifact_name
    and so2["size"] == artifact_size
    and so2["digest"] == "sha256:" + artifact_sha
)

if artifact_identity_match and release_lists_asset and release_asset_matches:
    assign(
        "AG3-E01",
        "SUPPORTED",
        "Locally recomputed artifact identity matches the AG2 release-asset filename, byte length, and SHA-256, and the release observation lists the target asset.",
    )
elif release_lists_asset and not release_asset_matches:
    assign(
        "AG3-E01",
        "CONTRADICTED",
        "Present release-asset identity fields conflict with the exact locally recomputed artifact identity.",
    )
else:
    assign(
        "AG3-E01",
        "INSUFFICIENT_EVIDENCE",
        "Required artifact/release association evidence is absent.",
    )


# E02 --------------------------------------------------------

so3 = obs["AG2-SO-003"]

if so3["capture_status"] == "METADATA_OBSERVED_CONTENT_NOT_CAPTURED":
    assign(
        "AG3-E02",
        "INSUFFICIENT_EVIDENCE",
        "Checksum asset metadata was observed but its proposition-level 115-byte checksum assertion content was not captured.",
    )
else:
    assign(
        "AG3-E02",
        "UNRESOLVED",
        "Checksum content availability differs from the frozen AG2 missingness state and no additional evaluation rule is admitted here.",
    )


# E03 / E04 / E05 / E07 ------------------------------------

so10 = obs["AG2-SO-010"]

attestation_bundle_captured = (
    so10["capture_status"] != "NOT_CAPTURED"
)

for eid in ("AG3-E03", "AG3-E04", "AG3-E05", "AG3-E07"):
    if not attestation_bundle_captured:
        assign(
            eid,
            "INSUFFICIENT_EVIDENCE",
            "No captured attestation bundle or decoded predicate exists in the AG2 evidence boundary sufficient to bind the required endpoint.",
        )
    else:
        assign(
            eid,
            "UNRESOLVED",
            "Attestation material appears present, but no additional parsing/evaluation rule is admitted by this recomputation.",
        )


# E06 --------------------------------------------------------

so4 = obs["AG2-SO-004"]["observed_fields"]
so5 = obs["AG2-SO-005"]["observed_fields"]
so6 = obs["AG2-SO-006"]["observed_fields"]
so7 = obs["AG2-SO-007"]["observed_fields"]
so8 = obs["AG2-SO-008"]["observed_fields"]

commit_values = [
    so4["object_sha"],
    so5["sha"],
    so7["head_sha"],
    so8["head_sha"],
]

commit_fields_present = all(bool(v) for v in commit_values)

commit_consistent = (
    commit_fields_present
    and len(set(commit_values)) == 1
)

workflow_consistent = (
    so6["path"] == ".github/workflows/release.yml"
    and so7["workflow_path"] == so6["path"]
)

if commit_consistent and workflow_consistent:
    assign(
        "AG3-E06",
        "SUPPORTED",
        "Tag ref, source commit, workflow text coordinate, workflow run, and target-platform job resolve consistently to the named commit/workflow reference.",
    )
elif commit_fields_present:
    assign(
        "AG3-E06",
        "CONTRADICTED",
        "Present source-commit/workflow-reference fields conflict.",
    )
else:
    assign(
        "AG3-E06",
        "INSUFFICIENT_EVIDENCE",
        "Required source-commit/workflow-reference evidence is absent.",
    )


# E08 --------------------------------------------------------

window = ag2.get("observation_window_utc", {})

ag0_coordinate_rule = (
    "Every status must remain bound to named evidence, ruleset/method, source boundary, and coordinate."
    in ag0_text
)

capture_consistent = (
    ag1.get("capture_id") == "CAPTURE_001"
    and ag2.get("capture_id") == "CAPTURE_001"
    and ag3.get("capture_id") == "CAPTURE_001"
)

window_bound = (
    bool(window.get("start"))
    and bool(window.get("end"))
)

edge_set_routed_to_ag4 = all(
    e.get("evaluation_status") == "NOT_EVALUATED"
    and e.get("evaluation_gate") == "AG4"
    for e in ag3["edge_objects"]
)

if (
    ag0_coordinate_rule
    and capture_consistent
    and window_bound
    and edge_set_routed_to_ag4
):
    assign(
        "AG3-E08",
        "SUPPORTED",
        "AG0 requires coordinate-bound status; AG1–AG3 are bound to CAPTURE_001; AG2 supplies the observation window; and the complete AG3 edge set is routed to AG4.",
    )
else:
    assign(
        "AG3-E08",
        "INSUFFICIENT_EVIDENCE",
        "Required record-coordinate binding is incomplete.",
    )


# E09 --------------------------------------------------------

supersession_sources = [
    x for x in ag2["source_observations"]
    if "supersession" in x.get("surface", "").lower()
]

if not supersession_sources:
    assign(
        "AG3-E09",
        "INSUFFICIENT_EVIDENCE",
        "No independently bounded supersession source is present in the admitted AG2 observation set.",
    )
else:
    assign(
        "AG3-E09",
        "UNRESOLVED",
        "A supersession surface exists but requires a separately admitted interpretation rule.",
    )


if sorted(computed) != required_edges:
    raise RuntimeError("Not all nine edge statuses were recomputed.")


recomputed_counter = Counter(
    x["status"] for x in computed.values()
)

recomputed_counts = {
    status: recomputed_counter.get(status, 0)
    for status in STATUSES
}


# ============================================================
# PHASE A COMPLETE.
#
# Only now read the recorded AG4 result for comparison.
# ============================================================

ag4 = load_json(ag4_path)

recorded = {
    x["edge_id"]: x["status"]
    for x in ag4["evaluations"]
}

comparison = []

for eid in required_edges:

    recomputed_status = computed[eid]["status"]
    recorded_status = recorded.get(eid)

    comparison.append({
        "edge_id": eid,
        "edge_type": computed[eid]["edge_type"],
        "recomputed_status": recomputed_status,
        "recorded_ag4_status": recorded_status,
        "match": recomputed_status == recorded_status,
    })


all_edge_statuses_match = all(
    x["match"] for x in comparison
)

recorded_counts = ag4["summary_counts"]

summary_counts_match = (
    recomputed_counts == recorded_counts
)


# ============================================================
# Verify extracted packet bytes against Git blob identities
# ============================================================

packet_paths = [
    ag0_path,
    ag1_path,
    ag2_path,
    ag3_path,
    ag4_path,
]

packet_identities = []

for path in packet_paths:

    rel = path.relative_to(packet_root).as_posix()

    repository_blob_sha = git(
        repo,
        "rev-parse",
        f"{a.ag4_commit}:{rel}",
    )

    local_blob_sha = local_git_blob_sha1(path)

    packet_identities.append({
        "path": rel,
        "byte_length": path.stat().st_size,
        "sha256": sha256_file(path),
        "repository_git_blob_sha": repository_blob_sha,
        "local_reconstructed_git_blob_sha": local_blob_sha,
        "match": repository_blob_sha == local_blob_sha,
    })

packet_bytes_match_git = all(
    x["match"] for x in packet_identities
)


# ============================================================
# Verify repository coordinate without a worktree checkout
# ============================================================

observed_ag4 = git(repo, "rev-parse", a.ag4_commit)
observed_parent = git(repo, "rev-parse", f"{a.ag4_commit}^")

coordinate_match = (
    observed_ag4 == a.ag4_commit
    and observed_parent == a.ag3_commit
)


overall_match = all([
    coordinate_match,
    packet_bytes_match_git,
    artifact_identity_match,
    all_edge_statuses_match,
    summary_counts_match,
])


receipt = {
    "object_id": "FORK-RELATIONAL-RESOLUTION-DEMONSTRATION-001",
    "operation": "LOCAL_AG4_RECOMPUTATION_FOR_AG5_CANDIDATE",
    "attempt_id": "AG5_LOCAL_RECOMPUTATION_ATTEMPT_002",
    "standing": "LOCAL_RECOMPUTATION_RESULT_ONLY_NOT_REPOSITORY_ADMITTED",
    "recomputed_at_utc": datetime.now(timezone.utc).isoformat(),

    "implementation": {
        "ruleset_id": RULESET_ID,
        "implementation_id": "LOCAL-AG4-RECOMPUTE-v0.2",
        "python_version": sys.version,
        "platform": platform.platform(),
        "ag4_result_file_opened_only_after_status_derivation": True,
        "full_worktree_checkout_required": False,
    },

    "repository_coordinate": {
        "expected_ag4_commit": a.ag4_commit,
        "observed_ag4_commit": observed_ag4,
        "expected_ag3_parent": a.ag3_commit,
        "observed_ag3_parent": observed_parent,
        "match": coordinate_match,
    },

    "artifact_recomputation": {
        "filename": artifact_name,
        "observed_byte_length": artifact_size,
        "observed_sha256": artifact_sha,
        "expected_filename_from_ag1": expected_name,
        "expected_byte_length_from_ag1": expected_size,
        "expected_sha256_from_ag1": expected_sha,
        "match": artifact_identity_match,
    },

    "packet_file_identities": packet_identities,
    "packet_bytes_match_git": packet_bytes_match_git,

    "recomputed_evaluations": [
        computed[eid]
        for eid in required_edges
    ],

    "comparison_to_recorded_ag4": comparison,

    "recomputed_summary_counts": recomputed_counts,
    "recorded_ag4_summary_counts": recorded_counts,

    "summary_counts_match": summary_counts_match,
    "all_edge_statuses_match": all_edge_statuses_match,
    "overall_match": overall_match,

    "boundaries": [
        "LOCAL_RECOMPUTATION_MATCH != AG5_REPOSITORY_ADMISSION",
        "STATUS_REPRODUCED != GLOBAL_VERIFICATION",
        "SUPPORTED_UNDER_BOUND_EVIDENCE != UNIVERSALLY_TRUE",
        "INSUFFICIENT_EVIDENCE != CONTRADICTED",
        "RECOMPUTED_ARTIFACT_IDENTITY != SOFTWARE_SAFETY",
        "ATTEMPT_001_PROCEDURAL_FAILURE != AG4_STATUS_MISMATCH",
    ],
}

out.write_text(
    json.dumps(
        receipt,
        indent=2,
        ensure_ascii=False,
    ) + "\n",
    encoding="utf-8",
)


print("")
print("=== RECOMPUTED EDGE RESULTS ===")

for item in comparison:

    marker = "MATCH" if item["match"] else "MISMATCH"

    print(
        f'{item["edge_id"]}  '
        f'{item["recomputed_status"]:<22} '
        f'{marker}'
    )


print("")
print("=== RECOMPUTED DISTRIBUTION ===")

for status in STATUSES:
    print(
        f"{status:<24} "
        f"{recomputed_counts[status]}"
    )


print("")
print("Coordinate match        :", coordinate_match)
print("Packet bytes match Git  :", packet_bytes_match_git)
print("Artifact identity match :", artifact_identity_match)
print("9/9 edge status match   :", all_edge_statuses_match)
print("Summary counts match    :", summary_counts_match)
print("OVERALL MATCH           :", overall_match)
print("Receipt                 :", out)


sys.exit(0 if overall_match else 2)