# Blind Field Correspondence Protocol v0.1 — FROZEN

**Status:** PREREGISTERED / NOT YET EXECUTED  
**Version:** v0.1  
**Freeze time:** 2026-08-25T04:51:00-07:00

## Objective

Compare the already-frozen Fork record shape against Marvin Percival's independently produced FORAY/GRANTHA record shape and three native trajectory records without modifying either side to improve fit.

## Intake order

1. Freeze and hash Fork shape and comparison rules.
2. Transmit frozen Fork package to Marvin.
3. Receive Marvin's independently produced native record shape and the three proposed records:
   - authority grant with validity window;
   - change to that grant;
   - execution referencing that grant.
4. Preserve every received byte unchanged.
5. Hash each received artifact before analysis.
6. Create working copies only after immutable intake hashes are recorded.
7. Perform field correspondence without redesigning either schema.
8. Discuss the architectural seam only after correspondence classification is complete.

## Unit of comparison

Each Fork field is evaluated against the external native representation at the smallest semantically meaningful field or field-group level. Name similarity alone is insufficient.

## Allowed classifications

### EXACT
The external field or field-group represents materially the same proposition, scope, temporal role, provenance role, and uncertainty semantics as the Fork field without reinterpretation.

### PARTIAL
There is meaningful overlap, but one or more dimensions differ or are absent, including scope, granularity, temporal semantics, provenance, verification semantics, cardinality, or authority meaning.

### ABSENT
No external field or reconstructable field-group represents the Fork proposition without introducing new information or unsupported inference.

### SEMANTIC_CONFLICT
An apparent correspondence exists, but using it as a mapping would invert, collapse, or improperly inherit meaning—for example treating historical grant reference as current standing, `not established` as failure, sequence as causation, or artifact identity as proposition validity.

## Blindness constraints

- No Fork field may be renamed, split, merged, deleted, or added after external materials are received for this comparison epoch.
- No external field may be rewritten into Fork terminology before classification.
- Mapping shall cite original field names and source-native definitions where supplied.
- Ambiguity is classified as PARTIAL or ABSENT, not repaired by inference.
- Source-native authority conclusions are preserved as source assertions unless separately evidenced.
- The three external records remain historical objects with independent identities; predecessor/reference relations do not merge them into one continuing authority object.

## Required output columns

- `fork_field`
- `external_field_or_group`
- `classification` (`EXACT | PARTIAL | ABSENT | SEMANTIC_CONFLICT`)
- `semantic_basis`
- `temporal_basis`
- `provenance_basis`
- `uncertainty_or_verification_basis`
- `inference_required` (`NONE | MINOR | MATERIAL`)
- `evidence_reference`
- `examiner_note`

## Stop rule

Do not interpret the FORAY↔GRANTHA↔Fork architectural seam until:

1. all Fork fields have a classification;
2. all apparent authority/standing mappings have been pressure-checked for non-inheritance;
3. intake hashes and untouched originals are preserved; and
4. unresolved mappings are explicitly retained rather than normalized away.
