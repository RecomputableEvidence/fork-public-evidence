# Fork Record Semantic Boundaries v0.1 — FROZEN

**Status:** FROZEN RECIPROCAL-COMPARISON CANDIDATE  
**Version:** v0.1  
**Freeze time:** 2026-08-25T04:51:00-07:00  
**Purpose:** Preserve a neutral Fork-native record shape before inspecting FORAY/GRANTHA native records.

## Non-inheritance rules

1. `REFERENCE_TO_GRANT ≠ VALID_GRANT_AT_EXECUTION`
2. `PREDECESSOR ≠ CONTINUING_STANDING`
3. `SOURCE_ARTIFACT_PRESENT ≠ PROPOSITION_VERIFIED`
4. `VERIFICATION_NOT_ESTABLISHED ≠ FAILED`
5. `OBSERVED_AUTHORITY_ARTIFACT ≠ AUTHORITY_DETERMINATION`
6. `SEQUENCE_ORDER ≠ CAUSAL_OR_AUTHORITY_INHERITANCE`
7. `HASH_MATCH ≠ SEMANTIC_CORRECTNESS`
8. `SOURCE_ASSERTION ≠ FORK_CONCLUSION`
9. `EXECUTION_REFERENCE ≠ EXECUTION_AUTHORIZED`
10. `ADJACENCY_OR_DERIVATION ≠ STRONGER_MEANING`

## Temporal invariant

Any event or historical object preserved by this record shape is treated as having three distinct temporal phases:

1. it begins;
2. it persists for a bounded interval, however brief; and
3. it ends.

Historical persistence does not establish continuing standing after the end of that interval. A later reference to the historical object does not reopen, extend, or strengthen its prior authority state.

## Preservation boundary

Fork records may preserve source-native claims such as `grant valid`, `authorized`, or `standing`, but only as attributed source assertions with provenance. The neutral Fork record does not silently adopt those claims as Fork determinations.

## Frozen comparison rule

This schema and these semantic boundaries MUST NOT be altered after receipt of FORAY/GRANTHA materials for the purpose of improving correspondence. Any discovered defect is preserved as a finding and repaired only in a successor version.
